import express from "express";
import http from "http";
import path from "path";
import dotenv from "dotenv";
import { WebSocketServer, WebSocket } from "ws";
import { GoogleGenAI, Modality, LiveServerMessage } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy initialization of GoogleGenAI client with required user agent telemetry
let aiClient: GoogleGenAI | null = null;
function getAi(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY environment variable is not set. Gemini features may fail.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey || "",
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
  });
});

// Chat models metadata
app.get("/api/chat/models", (_req, res) => {
  res.json({
    models: [
      {
        id: "gemini-3.8-flash",
        name: "Gemini 3.8 Flash",
        tag: "General Tasks",
        recommendedFor: "General fitness coaching, balanced nutrition and workout advice",
        isDefault: true,
      },
      {
        id: "gemini-3.1-flash-lite",
        name: "Gemini 3.1 Flash Lite",
        tag: "Fast",
        recommendedFor: "Rapid quick answers, fast macro and calorie lookups",
        isDefault: false,
      },
      {
        id: "gemini-3.1-pro-preview",
        name: "Gemini 3.1 Pro Preview",
        tag: "Complex Tasks",
        recommendedFor: "Advanced training periodization, deep biomechanics & macro science",
        isDefault: false,
      },
    ],
  });
});

// Multi-turn Chat API endpoint
app.post("/api/chat", async (req, res) => {
  try {
    const {
      messages,
      model = "gemini-3.8-flash",
      systemInstruction = "You are FitTrack AI Coach, an expert fitness trainer, sports nutritionist, and wellness companion. Provide motivating, actionable, safe, and precise fitness advice.",
      userContext,
    } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "Missing or invalid 'messages' array" });
    }

    const ai = getAi();

    // Prepare conversation contents for Gemini
    // Formulate system instruction enriched with user context if provided
    let fullSystemInstruction = systemInstruction;
    if (userContext) {
      fullSystemInstruction += `\n\n[USER CURRENT FITNESS SNAPSHOT]:\n${JSON.stringify(userContext, null, 2)}`;
    }

    // Format history for generateContent
    // Messages format: [{ role: 'user' | 'model', text: string }]
    const contents = messages.map((m: { role: 'user' | 'model'; text: string }) => ({
      role: m.role,
      parts: [{ text: m.text }],
    }));

    // Define model attempt list (requested model first, then fallback to resilient models if 503/high demand)
    const primaryModel = model || "gemini-3.8-flash";
    const modelsToTry = [primaryModel];
    if (primaryModel !== "gemini-3.8-flash") {
      modelsToTry.push("gemini-3.8-flash");
    }
    if (primaryModel !== "gemini-3.1-flash-lite") {
      modelsToTry.push("gemini-3.1-flash-lite");
    }

    let response: any = null;
    let successfulModel = primaryModel;
    let lastError: any = null;

    for (const tryModel of modelsToTry) {
      try {
        response = await ai.models.generateContent({
          model: tryModel,
          contents,
          config: {
            systemInstruction: fullSystemInstruction,
            temperature: 0.7,
          },
        });
        successfulModel = tryModel;
        break; // Success!
      } catch (err: any) {
        lastError = err;
        console.warn(`[Chat API] Model ${tryModel} failed with error:`, err?.message || err);
        const errMsg = String(err?.message || "");
        const isUnavailableOrHighDemand =
          errMsg.includes("503") ||
          errMsg.includes("UNAVAILABLE") ||
          errMsg.includes("high demand") ||
          errMsg.includes("429") ||
          errMsg.includes("RESOURCE_EXHAUSTED");

        if (!isUnavailableOrHighDemand) {
          // If it's not a capacity/demand issue, rethrow immediately
          throw err;
        }
        // Otherwise continue to next model in loop
      }
    }

    if (!response) {
      throw lastError || new Error("All model options are currently experiencing high demand. Please try again shortly.");
    }

    const reply = response.text || "I couldn't generate a response. Please try again.";

    return res.json({
      text: reply,
      modelUsed: successfulModel,
    });
  } catch (error: any) {
    console.error("Error in /api/chat:", error);
    const errorMsg = error?.message || "Failed to process chat with Gemini";
    return res.status(500).json({
      error: errorMsg.includes("high demand")
        ? "AI servers are currently experiencing high demand. Please try again in a few moments."
        : errorMsg,
    });
  }
});

async function startServer() {
  const server = http.createServer(app);

  // Setup WebSocket Server for Gemini Live API voice conversation
  const wss = new WebSocketServer({ server, path: "/live" });

  wss.on("connection", async (clientWs: WebSocket, req) => {
    console.log("[Live API] Client connected to WebSocket /live", req?.url);

    // Extract preferred language from query params (e.g. /live?lang=hi or /live?lang=ur)
    const urlObj = new URL(req?.url || "/live", "http://localhost:3000");
    const langParam = urlObj.searchParams.get("lang") || "en";

    let languageDirective = "Default to clear, energetic English. You also fully understand and can converse in Urdu and Hindi.";
    if (langParam === "hi") {
      languageDirective = "The user has selected HINDI. You MUST speak, listen, and converse fluently in Hindi (using natural conversational Hindi/Hinglish terms for fitness when appropriate). Answer spoken fitness, workout, calorie, and nutrition queries concisely and warmly in Hindi.";
    } else if (langParam === "ur") {
      languageDirective = "The user has selected URDU / ROMAN URDU. You MUST speak, listen, and converse fluently in Urdu/Roman Urdu. Answer spoken fitness, workout, calorie, and nutrition queries concisely and warmly in Urdu.";
    } else {
      languageDirective = "You are a trilingual assistant fluent in English, Hindi, and Urdu. Respond in the language spoken by the user, defaulting to English. Answer spoken fitness, workout, calorie, and nutrition queries concisely and warmly.";
    }

    let liveSession: any = null;

    try {
      const ai = getAi();

      liveSession = await ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: "Zephyr" },
            },
          },
          systemInstruction:
            `You are FitTrack Live Voice Coach, a friendly, encouraging, real-time audio fitness and diet assistant. You specialize in three languages: English, Urdu, and Hindi. ${languageDirective} Keep spoken responses concise, enthusiastic, and easy to follow during workouts.`,
          outputAudioTranscription: {},
          inputAudioTranscription: {},
        },
        callbacks: {
          onmessage: (message: LiveServerMessage) => {
            try {
              if (clientWs.readyState !== WebSocket.OPEN) return;

              // Check for model audio turn
              const parts = message.serverContent?.modelTurn?.parts;
              if (parts && parts.length > 0) {
                for (const part of parts) {
                  if (part.inlineData?.data) {
                    clientWs.send(
                      JSON.stringify({
                        type: "audio",
                        audio: part.inlineData.data,
                      })
                    );
                  }
                  if (part.text) {
                    clientWs.send(
                      JSON.stringify({
                        type: "text",
                        text: part.text,
                      })
                    );
                  }
                }
              }

              // Check for model transcription if available
              const outputTranscription = (message.serverContent as any)?.outputAudioTranscription?.text;
              if (outputTranscription) {
                clientWs.send(
                  JSON.stringify({
                    type: "transcript_model",
                    text: outputTranscription,
                  })
                );
              }

              // Check for user speech transcription if available
              const inputTranscription = (message.serverContent as any)?.inputAudioTranscription?.text;
              if (inputTranscription) {
                clientWs.send(
                  JSON.stringify({
                    type: "transcript_user",
                    text: inputTranscription,
                  })
                );
              }

              // Interrupted flag (user started speaking while model was playing)
              if (message.serverContent?.interrupted) {
                clientWs.send(JSON.stringify({ type: "interrupted", interrupted: true }));
              }

              // Turn complete flag
              if (message.serverContent?.turnComplete) {
                clientWs.send(JSON.stringify({ type: "turnComplete", turnComplete: true }));
              }
            } catch (err) {
              console.error("[Live API] Error in onmessage handler:", err);
            }
          },
          onerror: (err: any) => {
            console.error("[Live API] Session error:", err);
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(
                JSON.stringify({
                  type: "error",
                  error: err?.message || "Live API session encountered an error",
                })
              );
            }
          },
          onclose: () => {
            console.log("[Live API] Live session closed");
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ type: "closed" }));
            }
          },
        },
      });

      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(JSON.stringify({ type: "connected", message: "Live API session ready" }));
      }
    } catch (err: any) {
      console.error("[Live API] Failed to connect to Gemini Live session:", err);
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(
          JSON.stringify({
            type: "error",
            error: err?.message || "Could not initialize Gemini Live session",
          })
        );
      }
      return;
    }

    clientWs.on("message", (raw: any) => {
      try {
        const data = JSON.parse(raw.toString());

        // Audio streaming packet from browser mic (16kHz PCM linear)
        if (data.audio && liveSession) {
          liveSession.sendRealtimeInput({
            audio: {
              data: data.audio,
              mimeType: "audio/pcm;rate=16000",
            },
          });
        }

        // Text input into live session if client sends text
        if (data.text && liveSession) {
          liveSession.sendRealtimeInput({
            text: data.text,
          });
        }
      } catch (err) {
        console.error("[Live API] Error processing client message:", err);
      }
    });

    clientWs.on("close", () => {
      console.log("[Live API] Client WebSocket closed");
      try {
        if (liveSession && typeof liveSession.close === "function") {
          liveSession.close();
        }
      } catch (e) {
        // ignore cleanup error
      }
    });
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`FitTrack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
