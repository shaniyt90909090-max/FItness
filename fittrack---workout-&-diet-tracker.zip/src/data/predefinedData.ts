import { FoodPreset, ExercisePreset, UserGoals, DailyLog } from '../types';

export const DEFAULT_GOALS: UserGoals = {
  dailyCalories: 2100,
  dailyProteinG: 140,
  dailyCarbsG: 220,
  dailyFatG: 65,
  dailyWaterMl: 3000,
  currentWeightKg: 74,
  targetWeightKg: 70,
  fitnessGoal: 'lose_weight',
};

export const FOOD_PRESETS: FoodPreset[] = [
  // Desi staples & popular fitness foods
  {
    name: 'Whole Wheat Roti / Chapati',
    nameUrdu: 'Gandum ki Roti',
    calories: 120,
    protein: 3.5,
    carbs: 22,
    fat: 0.8,
    servingSize: '1 medium (40g)',
    category: 'desi_staple',
  },
  {
    name: 'Grilled / Cooked Chicken Breast',
    nameUrdu: 'Chicken Breast (Pakka hua)',
    calories: 165,
    protein: 31,
    carbs: 0,
    fat: 3.6,
    servingSize: '100g',
    category: 'protein',
  },
  {
    name: 'Boiled Egg (Large)',
    nameUrdu: 'Ubla hua Anda',
    calories: 78,
    protein: 6.3,
    carbs: 0.6,
    fat: 5.3,
    servingSize: '1 large egg',
    category: 'protein',
  },
  {
    name: 'Egg Whites (Boiled)',
    nameUrdu: 'Ande ki Safedi',
    calories: 17,
    protein: 3.6,
    carbs: 0.2,
    fat: 0.1,
    servingSize: '1 white',
    category: 'protein',
  },
  {
    name: 'Cooked White Rice / Chawal',
    nameUrdu: 'Ubray Chawal',
    calories: 130,
    protein: 2.7,
    carbs: 28,
    fat: 0.3,
    servingSize: '1 cup (158g)',
    category: 'carbs',
  },
  {
    name: 'Daal (Lentil Soup / Chana/Masoor)',
    nameUrdu: 'Daal Masoor / Chana',
    calories: 150,
    protein: 9,
    carbs: 22,
    fat: 2.5,
    servingSize: '1 small bowl (150g)',
    category: 'desi_staple',
  },
  {
    name: 'Plain Dahi / Yogurt',
    nameUrdu: 'Sada Dahi',
    calories: 100,
    protein: 6,
    carbs: 8,
    fat: 4.5,
    servingSize: '1 cup (150g)',
    category: 'dairy_nuts',
  },
  {
    name: 'Oats with Milk & Honey',
    nameUrdu: 'Doodh wale Daliya / Oats',
    calories: 250,
    protein: 11,
    carbs: 42,
    fat: 5,
    servingSize: '1 bowl (200g)',
    category: 'carbs',
  },
  {
    name: 'Whey Protein Shake (with water)',
    nameUrdu: 'Whey Protein Shake',
    calories: 120,
    protein: 24,
    carbs: 3,
    fat: 1.5,
    servingSize: '1 scoop (30g)',
    category: 'protein',
  },
  {
    name: 'Banana',
    nameUrdu: 'Kela',
    calories: 105,
    protein: 1.3,
    carbs: 27,
    fat: 0.3,
    servingSize: '1 medium',
    category: 'fruits_veggies',
  },
  {
    name: 'Apple',
    nameUrdu: 'Saib',
    calories: 80,
    protein: 0.5,
    carbs: 21,
    fat: 0.3,
    servingSize: '1 medium',
    category: 'fruits_veggies',
  },
  {
    name: 'Almonds (Badam)',
    nameUrdu: 'Badam',
    calories: 140,
    protein: 5,
    carbs: 5,
    fat: 12,
    servingSize: '15-18 pieces (25g)',
    category: 'dairy_nuts',
  },
  {
    name: 'Chicken Biryani (Moderate portion)',
    nameUrdu: 'Chicken Biryani (1 plate)',
    calories: 420,
    protein: 22,
    carbs: 55,
    fat: 12,
    servingSize: '1 standard plate',
    category: 'desi_staple',
  },
  {
    name: 'Fresh Green Salad (Cucumber, Tomato)',
    nameUrdu: 'Kachumar Salad',
    calories: 35,
    protein: 1.2,
    carbs: 7,
    fat: 0.2,
    servingSize: '1 bowl',
    category: 'fruits_veggies',
  },
  {
    name: 'Paneer / Cottage Cheese',
    nameUrdu: 'Paneer',
    calories: 180,
    protein: 14,
    carbs: 3,
    fat: 12,
    servingSize: '100g',
    category: 'protein',
  },
  {
    name: 'Peanut Butter',
    nameUrdu: 'Peanut Butter',
    calories: 190,
    protein: 8,
    carbs: 7,
    fat: 16,
    servingSize: '2 tbsp (32g)',
    category: 'dairy_nuts',
  }
];

export const EXERCISE_PRESETS: ExercisePreset[] = [
  {
    name: 'Barbell Flat Bench Press',
    nameUrdu: 'Bench Press (Seena)',
    category: 'strength',
    muscleGroup: 'chest',
    defaultSets: 4,
    defaultReps: 10,
    defaultWeightKg: 60,
    estCaloriesPerMinute: 7,
  },
  {
    name: 'Barbell Back Squats',
    nameUrdu: 'Barbell Squats (Taangain)',
    category: 'strength',
    muscleGroup: 'legs',
    defaultSets: 4,
    defaultReps: 10,
    defaultWeightKg: 75,
    estCaloriesPerMinute: 8.5,
  },
  {
    name: 'Conventional Deadlift',
    nameUrdu: 'Deadlift (Pusht & Taangain)',
    category: 'strength',
    muscleGroup: 'back',
    defaultSets: 3,
    defaultReps: 8,
    defaultWeightKg: 90,
    estCaloriesPerMinute: 9,
  },
  {
    name: 'Incline Dumbbell Press',
    nameUrdu: 'Incline Dumbbell Press',
    category: 'strength',
    muscleGroup: 'chest',
    defaultSets: 3,
    defaultReps: 12,
    defaultWeightKg: 20,
    estCaloriesPerMinute: 6.5,
  },
  {
    name: 'Overhead Shoulder Dumbbell Press',
    nameUrdu: 'Shoulder Press (Kandhey)',
    category: 'strength',
    muscleGroup: 'shoulders',
    defaultSets: 3,
    defaultReps: 10,
    defaultWeightKg: 16,
    estCaloriesPerMinute: 6,
  },
  {
    name: 'Lat Pulldown / Pull-ups',
    nameUrdu: 'Pull-ups / Lat Pulldown',
    category: 'strength',
    muscleGroup: 'back',
    defaultSets: 4,
    defaultReps: 10,
    defaultWeightKg: 50,
    estCaloriesPerMinute: 7,
  },
  {
    name: 'Dumbbell Bicep Curls',
    nameUrdu: 'Bicep Curls (Bazu)',
    category: 'strength',
    muscleGroup: 'arms',
    defaultSets: 3,
    defaultReps: 12,
    defaultWeightKg: 12,
    estCaloriesPerMinute: 5.5,
  },
  {
    name: 'Tricep Rope Pushdown',
    nameUrdu: 'Tricep Rope Pushdown',
    category: 'strength',
    muscleGroup: 'arms',
    defaultSets: 3,
    defaultReps: 12,
    defaultWeightKg: 25,
    estCaloriesPerMinute: 5,
  },
  {
    name: 'Push-ups',
    nameUrdu: 'Desi Dand / Push-ups',
    category: 'hiit',
    muscleGroup: 'chest',
    defaultSets: 3,
    defaultReps: 20,
    defaultWeightKg: 0,
    estCaloriesPerMinute: 8,
  },
  {
    name: 'Bodyweight Squats',
    nameUrdu: 'Desi Baithak / Squats',
    category: 'hiit',
    muscleGroup: 'legs',
    defaultSets: 3,
    defaultReps: 25,
    defaultWeightKg: 0,
    estCaloriesPerMinute: 7.5,
  },
  {
    name: 'Treadmill Running',
    nameUrdu: 'Jogging / Daur',
    category: 'cardio',
    muscleGroup: 'full_body',
    defaultSets: 1,
    defaultReps: 1,
    defaultWeightKg: 0,
    estCaloriesPerMinute: 11,
  },
  {
    name: 'Jump Rope',
    nameUrdu: 'Skipping Rope / Rassi Koodna',
    category: 'cardio',
    muscleGroup: 'full_body',
    defaultSets: 3,
    defaultReps: 100,
    defaultWeightKg: 0,
    estCaloriesPerMinute: 12,
  },
  {
    name: 'Abdominal Plank',
    nameUrdu: 'Plank (Pet ki Warzish)',
    category: 'strength',
    muscleGroup: 'core',
    defaultSets: 3,
    defaultReps: 60, // seconds
    defaultWeightKg: 0,
    estCaloriesPerMinute: 5,
  },
  {
    name: 'Stationary Cycling',
    nameUrdu: 'Cycling',
    category: 'cardio',
    muscleGroup: 'legs',
    defaultSets: 1,
    defaultReps: 1,
    defaultWeightKg: 0,
    estCaloriesPerMinute: 8.5,
  }
];

export const WORKOUT_ROUTINE_PRESETS = [
  {
    id: 'push_day',
    title: 'Push Day (Chest, Shoulders, Triceps)',
    titleUrdu: 'Push Day (Seena, Kandhey, Triceps)',
    exercises: [
      'Barbell Flat Bench Press',
      'Incline Dumbbell Press',
      'Overhead Shoulder Dumbbell Press',
      'Tricep Rope Pushdown',
      'Push-ups'
    ]
  },
  {
    id: 'pull_day',
    title: 'Pull Day (Back, Biceps)',
    titleUrdu: 'Pull Day (Kamar, Biceps)',
    exercises: [
      'Conventional Deadlift',
      'Lat Pulldown / Pull-ups',
      'Dumbbell Bicep Curls'
    ]
  },
  {
    id: 'leg_day',
    title: 'Leg Day & Core (Quads, Calves, Abs)',
    titleUrdu: 'Leg Day (Taangain & Abs)',
    exercises: [
      'Barbell Back Squats',
      'Bodyweight Squats',
      'Abdominal Plank'
    ]
  },
  {
    id: 'desi_cardio',
    title: 'Cardio & Fat Burn Session',
    titleUrdu: 'Cardio & Charbi Pighlane ki Routine',
    exercises: [
      'Treadmill Running',
      'Jump Rope',
      'Push-ups',
      'Abdominal Plank'
    ]
  }
];

export const getTodayDateString = (): string => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const getInitialDemoLog = (dateStr: string): DailyLog => ({
  date: dateStr,
  meals: {
    breakfast: [
      {
        id: 'b1',
        name: 'Boiled Egg (Large)',
        nameUrdu: 'Ubla hua Anda',
        calories: 156,
        protein: 12.6,
        carbs: 1.2,
        fat: 10.6,
        servingSize: '2 eggs',
        quantity: 2,
        category: 'protein'
      },
      {
        id: 'b2',
        name: 'Oats with Milk & Honey',
        nameUrdu: 'Doodh wale Daliya / Oats',
        calories: 250,
        protein: 11,
        carbs: 42,
        fat: 5,
        servingSize: '1 bowl',
        quantity: 1,
        category: 'carbs'
      }
    ],
    lunch: [
      {
        id: 'l1',
        name: 'Whole Wheat Roti / Chapati',
        nameUrdu: 'Gandum ki Roti',
        calories: 240,
        protein: 7,
        carbs: 44,
        fat: 1.6,
        servingSize: '2 rotis',
        quantity: 2,
        category: 'desi_staple'
      },
      {
        id: 'l2',
        name: 'Cooked Chicken Breast',
        nameUrdu: 'Chicken Breast (Pakka)',
        calories: 248,
        protein: 46.5,
        carbs: 0,
        fat: 5.4,
        servingSize: '150g',
        quantity: 1.5,
        category: 'protein'
      },
      {
        id: 'l3',
        name: 'Fresh Green Salad',
        nameUrdu: 'Salad',
        calories: 35,
        protein: 1.2,
        carbs: 7,
        fat: 0.2,
        servingSize: '1 bowl',
        quantity: 1,
        category: 'fruits_veggies'
      }
    ],
    dinner: [
      {
        id: 'd1',
        name: 'Cooked White Rice / Chawal',
        nameUrdu: 'Ubray Chawal',
        calories: 195,
        protein: 4,
        carbs: 42,
        fat: 0.5,
        servingSize: '1.5 cup',
        quantity: 1.5,
        category: 'carbs'
      },
      {
        id: 'd2',
        name: 'Daal (Lentil Soup)',
        nameUrdu: 'Daal Chana',
        calories: 150,
        protein: 9,
        carbs: 22,
        fat: 2.5,
        servingSize: '1 bowl',
        quantity: 1,
        category: 'desi_staple'
      }
    ],
    snack: [
      {
        id: 's1',
        name: 'Banana',
        nameUrdu: 'Kela',
        calories: 105,
        protein: 1.3,
        carbs: 27,
        fat: 0.3,
        servingSize: '1 medium',
        quantity: 1,
        category: 'fruits_veggies'
      },
      {
        id: 's2',
        name: 'Almonds',
        nameUrdu: 'Badam',
        calories: 140,
        protein: 5,
        carbs: 5,
        fat: 12,
        servingSize: '15 pieces',
        quantity: 1,
        category: 'dairy_nuts'
      }
    ]
  },
  workouts: [
    {
      id: 'w1',
      name: 'Barbell Flat Bench Press',
      nameUrdu: 'Bench Press (Seena)',
      category: 'strength',
      muscleGroup: 'chest',
      durationMinutes: 20,
      caloriesBurned: 140,
      sets: [
        { id: 's1_1', setNumber: 1, weightKg: 50, reps: 12, completed: true },
        { id: 's1_2', setNumber: 2, weightKg: 60, reps: 10, completed: true },
        { id: 's1_3', setNumber: 3, weightKg: 65, reps: 8, completed: true },
        { id: 's1_4', setNumber: 4, weightKg: 70, reps: 6, completed: true }
      ],
      notes: 'Form was solid, ready to increase weight next week'
    },
    {
      id: 'w2',
      name: 'Push-ups',
      nameUrdu: 'Desi Dand / Push-ups',
      category: 'hiit',
      muscleGroup: 'chest',
      durationMinutes: 10,
      caloriesBurned: 80,
      sets: [
        { id: 's2_1', setNumber: 1, weightKg: 0, reps: 25, completed: true },
        { id: 's2_2', setNumber: 2, weightKg: 0, reps: 20, completed: true },
        { id: 's2_3', setNumber: 3, weightKg: 0, reps: 20, completed: true }
      ]
    },
    {
      id: 'w3',
      name: 'Treadmill Running',
      nameUrdu: 'Jogging / Daur',
      category: 'cardio',
      muscleGroup: 'full_body',
      durationMinutes: 15,
      caloriesBurned: 165,
      sets: [
        { id: 's3_1', setNumber: 1, weightKg: 0, reps: 1, completed: true }
      ],
      notes: 'Pace: 8.5 km/h'
    }
  ],
  waterIntakeMl: 2250,
  bodyWeightKg: 73.8,
  notes: 'Felt energetic throughout the day. Kept protein high!'
});
