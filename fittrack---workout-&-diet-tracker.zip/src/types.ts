export type Language = 'en' | 'ur' | 'hi';

export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export interface FoodItem {
  id: string;
  name: string;
  nameUrdu?: string;
  calories: number;
  protein: number; // in grams
  carbs: number;   // in grams
  fat: number;     // in grams
  servingSize: string;
  quantity: number;
  category?: string;
}

export type ExerciseCategory = 'strength' | 'cardio' | 'hiit' | 'flexibility';

export type MuscleGroup = 
  | 'chest' 
  | 'back' 
  | 'legs' 
  | 'shoulders' 
  | 'arms' 
  | 'core' 
  | 'full_body';

export interface ExerciseSet {
  id: string;
  setNumber: number;
  reps: number;
  weightKg: number;
  completed: boolean;
}

export interface ExerciseEntry {
  id: string;
  name: string;
  nameUrdu?: string;
  category: ExerciseCategory;
  muscleGroup: MuscleGroup;
  sets: ExerciseSet[];
  durationMinutes?: number;
  caloriesBurned: number;
  notes?: string;
}

export interface DailyLog {
  date: string; // ISO 'YYYY-MM-DD'
  meals: {
    breakfast: FoodItem[];
    lunch: FoodItem[];
    dinner: FoodItem[];
    snack: FoodItem[];
  };
  workouts: ExerciseEntry[];
  waterIntakeMl: number;
  bodyWeightKg?: number;
  notes?: string;
}

export interface UserGoals {
  dailyCalories: number;
  dailyProteinG: number;
  dailyCarbsG: number;
  dailyFatG: number;
  dailyWaterMl: number;
  targetWeightKg: number;
  currentWeightKg: number;
  fitnessGoal: 'lose_weight' | 'build_muscle' | 'maintain' | 'endurance';
}

export interface FoodPreset {
  name: string;
  nameUrdu: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  servingSize: string;
  category: 'desi_staple' | 'protein' | 'dairy_nuts' | 'fruits_veggies' | 'carbs';
}

export interface ExercisePreset {
  name: string;
  nameUrdu: string;
  category: ExerciseCategory;
  muscleGroup: MuscleGroup;
  defaultSets: number;
  defaultReps: number;
  defaultWeightKg: number;
  estCaloriesPerMinute: number;
}

export interface GoogleAuthUser {
  uid: string;
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
}

export interface ConnectedSpreadsheet {
  id: string;
  name: string;
  url: string;
  lastSynced?: string;
  webViewLink?: string;
}

export interface SheetFileSummary {
  id: string;
  name: string;
  modifiedTime?: string;
  webViewLink?: string;
}
