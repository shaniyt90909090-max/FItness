import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { DailyLog, UserGoals, Language } from './types';
import { getTodayDateString } from './data/predefinedData';
import {
  getStoredDailyLog,
  saveDailyLog,
  getStoredGoals,
  saveStoredGoals,
  resetToDemoData,
} from './utils/storage';
import Navbar from './components/Navbar';
import DailyOverview from './components/DailyOverview';
import DietTracker from './components/DietTracker';
import WorkoutTracker from './components/WorkoutTracker';
import WeeklyAnalytics from './components/WeeklyAnalytics';
import GoalsModal from './components/GoalsModal';
import RestTimer from './components/RestTimer';
import GoogleSheetsModal from './components/GoogleSheetsModal';
import LogoModal from './components/LogoModal';
import GeminiChatModal from './components/GeminiChatModal';
import GeminiLiveVoiceModal from './components/GeminiLiveVoiceModal';
import { Bot, Mic, Sparkles } from 'lucide-react';

export default function App() {
  const [currentDate, setCurrentDate] = useState<string>(() => getTodayDateString());
  const [goals, setGoals] = useState<UserGoals>(() => getStoredGoals());
  const [log, setLog] = useState<DailyLog>(() => getStoredDailyLog(getTodayDateString()));
  const [activeTab, setActiveTab] = useState<'overview' | 'diet' | 'workouts' | 'analytics'>('overview');
  const [lang, setLang] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('fittrack_lang');
      if (saved === 'en' || saved === 'ur' || saved === 'hi') return saved as Language;
    }
    return 'en';
  });
  const [isGoalsModalOpen, setIsGoalsModalOpen] = useState(false);
  const [isRestTimerOpen, setIsRestTimerOpen] = useState(false);
  const [isGoogleSheetsModalOpen, setIsGoogleSheetsModalOpen] = useState(false);
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);
  const [isGeminiChatOpen, setIsGeminiChatOpen] = useState(false);
  const [isLiveVoiceOpen, setIsLiveVoiceOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('fittrack_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // Sync dark class on document element and persist in localStorage
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('fittrack_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('fittrack_theme', 'light');
    }
  }, [isDarkMode]);

  const handleToggleDarkMode = () => {
    setIsDarkMode((prev) => !prev);
  };

  // When date changes, load that date's log
  useEffect(() => {
    const loadedLog = getStoredDailyLog(currentDate);
    setLog(loadedLog);
  }, [currentDate]);

  // Persist daily log whenever it is updated
  const handleUpdateLog = (updatedLog: DailyLog) => {
    setLog(updatedLog);
    saveDailyLog(updatedLog);
  };

  // Persist user goals
  const handleSaveGoals = (newGoals: UserGoals) => {
    setGoals(newGoals);
    saveStoredGoals(newGoals);
  };

  // Cycle English -> Roman Urdu -> Hindi
  const handleToggleLang = () => {
    setLang((prev) => {
      let next: Language = 'en';
      if (prev === 'en') next = 'ur';
      else if (prev === 'ur') next = 'hi';
      else next = 'en';

      if (typeof window !== 'undefined') {
        localStorage.setItem('fittrack_lang', next);
      }
      return next;
    });
  };

  // Reset demo data
  const handleResetDemo = () => {
    const freshLog = resetToDemoData();
    setLog(freshLog);
    const freshGoals = getStoredGoals();
    setGoals(freshGoals);
    setCurrentDate(getTodayDateString());
  };

  return (
    <div className={`min-h-screen flex flex-col antialiased transition-colors duration-200 ${isDarkMode ? 'dark bg-stone-950 text-stone-100' : 'bg-stone-50/70 text-stone-900'}`}>
      {/* Navbar & Navigation */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        currentDate={currentDate}
        onChangeDate={setCurrentDate}
        lang={lang}
        onToggleLang={handleToggleLang}
        isDarkMode={isDarkMode}
        onToggleDarkMode={handleToggleDarkMode}
        onOpenGoalsModal={() => setIsGoalsModalOpen(true)}
        onOpenRestTimer={() => setIsRestTimerOpen(true)}
        onOpenGoogleSheetsModal={() => setIsGoogleSheetsModalOpen(true)}
        onOpenLogoModal={() => setIsLogoModalOpen(true)}
        onOpenGeminiChat={() => setIsGeminiChatOpen(true)}
        onOpenLiveVoice={() => setIsLiveVoiceOpen(true)}
        onResetDemo={handleResetDemo}
      />

      {/* Main Viewport Content with Smooth Motion Entrance Animations */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.22, ease: [0.25, 1, 0.5, 1] }}
            className="w-full"
          >
            {activeTab === 'overview' && (
              <DailyOverview
                log={log}
                goals={goals}
                onUpdateLog={handleUpdateLog}
                onNavigateTab={setActiveTab}
                onOpenGoalsModal={() => setIsGoalsModalOpen(true)}
                onOpenRestTimer={() => setIsRestTimerOpen(true)}
                onOpenGoogleSheetsModal={() => setIsGoogleSheetsModalOpen(true)}
                lang={lang}
              />
            )}

            {activeTab === 'diet' && (
              <DietTracker
                log={log}
                onUpdateLog={handleUpdateLog}
                lang={lang}
              />
            )}

            {activeTab === 'workouts' && (
              <WorkoutTracker
                log={log}
                onUpdateLog={handleUpdateLog}
                lang={lang}
                onOpenRestTimer={() => setIsRestTimerOpen(true)}
              />
            )}

            {activeTab === 'analytics' && (
              <WeeklyAnalytics
                currentLog={log}
                goals={goals}
                lang={lang}
                onOpenGoogleSheetsModal={() => setIsGoogleSheetsModalOpen(true)}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Floating Workout Rest Timer */}
      <RestTimer
        isOpen={isRestTimerOpen}
        onClose={() => setIsRestTimerOpen(false)}
        lang={lang}
      />

      {/* Goals & Target Customizer Modal */}
      <GoalsModal
        isOpen={isGoalsModalOpen}
        onClose={() => setIsGoalsModalOpen(false)}
        goals={goals}
        onSave={handleSaveGoals}
        lang={lang}
      />

      {/* Google Sheets Sync & Backup Modal */}
      <GoogleSheetsModal
        isOpen={isGoogleSheetsModalOpen}
        onClose={() => setIsGoogleSheetsModalOpen(false)}
        currentLog={log}
        goals={goals}
        lang={lang}
      />

      {/* Brand Logo Showcase Modal */}
      <LogoModal
        isOpen={isLogoModalOpen}
        onClose={() => setIsLogoModalOpen(false)}
        lang={lang}
      />

      {/* Gemini AI Multi-Turn Chat Modal */}
      <GeminiChatModal
        isOpen={isGeminiChatOpen}
        onClose={() => setIsGeminiChatOpen(false)}
        currentLog={log}
        goals={goals}
        lang={lang}
        onOpenLiveVoice={() => setIsLiveVoiceOpen(true)}
      />

      {/* Gemini Live API Real-Time Voice Conversation Modal */}
      <GeminiLiveVoiceModal
        isOpen={isLiveVoiceOpen}
        onClose={() => setIsLiveVoiceOpen(false)}
        lang={lang}
        onSelectLanguage={(newLang) => {
          setLang(newLang);
          if (typeof window !== 'undefined') {
            localStorage.setItem('fittrack_lang', newLang);
          }
        }}
      />

      {/* Floating AI Assistant Quick Actions (Bottom Right) */}
      <div className="fixed bottom-6 right-6 z-30 flex flex-col items-end gap-3 pointer-events-none">
        {/* Floating Voice Live Button */}
        <motion.button
          id="floating-live-voice-btn"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsLiveVoiceOpen(true)}
          className="pointer-events-auto flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xl shadow-teal-900/30 border border-teal-400/40 cursor-pointer backdrop-blur-md"
          title={lang === 'ur' ? 'Live Voice Coach (gemini-3.1-flash-live-preview)' : 'Real-time Live Voice Coach (gemini-3.1-flash-live-preview)'}
        >
          <Mic className="w-4 h-4 text-teal-200 animate-pulse" />
          <span className="hidden sm:inline">{lang === 'ur' ? 'Voice Live' : 'Voice Live'}</span>
          <span className="w-2 h-2 rounded-full bg-teal-300 animate-ping" />
        </motion.button>

        {/* Floating AI Chatbot Button */}
        <motion.button
          id="floating-gemini-chat-btn"
          whileHover={{ scale: 1.06 }}
          whileTap={{ scale: 0.94 }}
          onClick={() => setIsGeminiChatOpen(true)}
          className="pointer-events-auto flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs sm:text-sm font-extrabold shadow-2xl shadow-emerald-900/40 border border-emerald-400/40 cursor-pointer"
          title={lang === 'ur' ? 'Gemini AI Coach se baat karein' : 'Chat with FitTrack AI Coach'}
        >
          <Bot className="w-5 h-5 text-white" />
          <span>{lang === 'ur' ? 'AI Fitness Coach' : 'AI Coach'}</span>
          <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded-full font-mono">Gemini</span>
        </motion.button>
      </div>

      {/* Simple Footer */}
      <footer className="border-t border-stone-200/80 dark:border-stone-800 bg-white dark:bg-stone-900 py-4 mt-auto transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-400 dark:text-stone-500 gap-2">
          <p>
            FitTrack • {lang === 'ur' ? 'Aapka Workout aur Diet Sathi' : 'Personal Workout & Diet Tracker'}
          </p>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsLogoModalOpen(true)}
              className="text-emerald-600 dark:text-emerald-400 font-semibold hover:underline transition-colors"
            >
              {lang === 'ur' ? 'App Logo' : 'App Logo'}
            </button>
            <span>•</span>
            <button
              onClick={() => setIsGoalsModalOpen(true)}
              className="hover:text-stone-700 dark:hover:text-stone-300 transition-colors"
            >
              {lang === 'ur' ? 'Ahdaaf (Goals)' : 'Targets & Goals'}
            </button>
            <span>•</span>
            <button
              onClick={() => setIsRestTimerOpen(true)}
              className="hover:text-stone-700 dark:hover:text-stone-300 transition-colors"
            >
              {lang === 'ur' ? 'Rest Timer' : 'Rest Timer'}
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
