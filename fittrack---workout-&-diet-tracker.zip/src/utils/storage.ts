import { DailyLog, UserGoals } from '../types';
import { DEFAULT_GOALS, getTodayDateString, getInitialDemoLog } from '../data/predefinedData';

const GOALS_KEY = 'fittrack_user_goals';
const LOG_PREFIX = 'fittrack_log_';
const ALL_DATES_KEY = 'fittrack_saved_dates';

export function getStoredGoals(): UserGoals {
  try {
    const raw = localStorage.getItem(GOALS_KEY);
    if (raw) {
      return { ...DEFAULT_GOALS, ...JSON.parse(raw) };
    }
  } catch (err) {
    console.error('Error loading goals from storage:', err);
  }
  return DEFAULT_GOALS;
}

export function saveStoredGoals(goals: UserGoals): void {
  try {
    localStorage.setItem(GOALS_KEY, JSON.stringify(goals));
  } catch (err) {
    console.error('Error saving goals to storage:', err);
  }
}

export function getStoredDailyLog(date: string): DailyLog {
  try {
    const raw = localStorage.getItem(`${LOG_PREFIX}${date}`);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error(`Error loading log for date ${date}:`, err);
  }

  // If loading today's date and nothing saved yet, seed with demo log
  const today = getTodayDateString();
  if (date === today) {
    const initialLog = getInitialDemoLog(today);
    saveDailyLog(initialLog);
    return initialLog;
  }

  // Return an empty log structure for other dates
  return {
    date,
    meals: {
      breakfast: [],
      lunch: [],
      dinner: [],
      snack: []
    },
    workouts: [],
    waterIntakeMl: 0,
    bodyWeightKg: undefined,
    notes: ''
  };
}

export function saveDailyLog(log: DailyLog): void {
  try {
    localStorage.setItem(`${LOG_PREFIX}${log.date}`, JSON.stringify(log));

    // Keep track of dates saved
    const datesRaw = localStorage.getItem(ALL_DATES_KEY);
    const dates: string[] = datesRaw ? JSON.parse(datesRaw) : [];
    if (!dates.includes(log.date)) {
      dates.push(log.date);
      dates.sort();
      localStorage.setItem(ALL_DATES_KEY, JSON.stringify(dates));
    }
  } catch (err) {
    console.error(`Error saving log for date ${log.date}:`, err);
  }
}

export function getRecentDailyLogs(days: number = 7): DailyLog[] {
  const result: DailyLog[] = [];
  const today = new Date();

  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const dateStr = `${yyyy}-${mm}-${dd}`;
    result.push(getStoredDailyLog(dateStr));
  }

  return result;
}

export function getAllStoredDailyLogs(): DailyLog[] {
  try {
    const datesRaw = localStorage.getItem(ALL_DATES_KEY);
    const dates: string[] = datesRaw ? JSON.parse(datesRaw) : [];
    if (dates.length === 0) {
      return [getStoredDailyLog(getTodayDateString())];
    }
    return dates.map((date) => getStoredDailyLog(date));
  } catch (err) {
    console.error('Error fetching all stored logs:', err);
    return [getStoredDailyLog(getTodayDateString())];
  }
}

export function resetToDemoData(): DailyLog {
  try {
    const today = getTodayDateString();
    localStorage.clear();
    const demo = getInitialDemoLog(today);
    saveDailyLog(demo);
    saveStoredGoals(DEFAULT_GOALS);
    return demo;
  } catch (err) {
    console.error('Error resetting demo data:', err);
    return getInitialDemoLog(getTodayDateString());
  }
}
