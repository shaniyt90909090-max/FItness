import React from 'react';
import { X, Download, Sparkles, Check, Palette, Smartphone, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import appLogo from '../assets/images/fittrack_app_logo_1789490319714.jpg';
import { Language } from '../types';

interface LogoModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export default function LogoModal({ isOpen, onClose, lang }: LogoModalProps) {
  if (!isOpen) return null;

  return (
    <div
      id="fittrack-logo-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm overflow-y-auto"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 16 }}
        className="relative w-full max-w-lg bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl p-6 sm:p-8 my-8 text-stone-900 dark:text-stone-100"
      >
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-stone-100 dark:border-stone-800 mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 rounded-2xl">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold tracking-tight">
                {lang === 'ur' ? 'FitTrack Official Logo' : 'FitTrack Official App Logo'}
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {lang === 'ur' ? 'Aapki fitness aur diet app ka makhsoos logo' : 'Brand identity, icon badge & visual assets'}
              </p>
            </div>
          </div>
          <button
            id="close-logo-modal"
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Big Logo Showcase */}
        <div className="flex flex-col items-center justify-center py-4">
          <div className="relative group">
            <div className="absolute -inset-2 bg-gradient-to-r from-emerald-500 to-teal-400 rounded-3xl blur-md opacity-40 group-hover:opacity-60 transition duration-300" />
            <img
              id="fittrack-logo-preview"
              src={appLogo}
              alt="FitTrack Logo"
              referrerPolicy="no-referrer"
              className="relative w-44 h-44 sm:w-52 sm:h-52 rounded-3xl object-cover shadow-2xl border-2 border-emerald-500/40"
            />
          </div>

          <div className="mt-4 text-center">
            <span className="font-extrabold text-lg text-stone-900 dark:text-white font-['Outfit',sans-serif]">
              FitTrack
            </span>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
              {lang === 'ur'
                ? 'Dynamic pulse, strength dumbbell aur energy flame ka shaandaar sangam'
                : 'Fusion of athletic pulse, strength dumbbell & vibrant energy flame'}
            </p>
          </div>
        </div>

        {/* App Icon Variations Preview */}
        <div className="mt-2 grid grid-cols-2 gap-3 p-3.5 bg-stone-50 dark:bg-stone-800/50 rounded-2xl border border-stone-200/80 dark:border-stone-700/60">
          <div className="flex items-center gap-3 p-2.5 rounded-xl bg-white dark:bg-stone-900 border border-stone-200/60 dark:border-stone-700">
            <img
              src={appLogo}
              alt="Mini App Icon"
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-xl object-cover shadow-xs border border-emerald-500/30 shrink-0"
            />
            <div className="truncate">
              <div className="text-xs font-bold text-stone-900 dark:text-white">App Icon</div>
              <div className="text-[10px] text-stone-400">Mobile / PWA</div>
            </div>
          </div>

          <div className="flex items-center gap-3 p-2.5 rounded-xl bg-white dark:bg-stone-900 border border-stone-200/60 dark:border-stone-700">
            <div className="w-9 h-9 rounded-full overflow-hidden border border-emerald-500/30 shrink-0">
              <img
                src={appLogo}
                alt="Avatar Icon"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="truncate">
              <div className="text-xs font-bold text-stone-900 dark:text-white">Avatar / Favicon</div>
              <div className="text-[10px] text-stone-400">Circular Badge</div>
            </div>
          </div>
        </div>

        {/* Brand Colors */}
        <div className="mt-4 flex items-center justify-between text-xs px-2 text-stone-500 dark:text-stone-400">
          <div className="flex items-center gap-1.5 font-medium">
            <Palette className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>Brand Colors:</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 font-mono text-[11px]">
              <span className="w-3 h-3 rounded-full bg-emerald-500 border border-emerald-600/30" /> #10B981
            </span>
            <span className="inline-flex items-center gap-1 font-mono text-[11px]">
              <span className="w-3 h-3 rounded-full bg-emerald-300 border border-emerald-400/30" /> #6EE7B7
            </span>
            <span className="inline-flex items-center gap-1 font-mono text-[11px]">
              <span className="w-3 h-3 rounded-full bg-stone-900 border border-stone-700" /> #18181B
            </span>
          </div>
        </div>

        {/* Actions Footer */}
        <div className="mt-6 pt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 text-xs font-bold cursor-pointer transition-colors"
          >
            {lang === 'ur' ? 'Band Karein' : 'Close'}
          </button>

          <a
            id="download-logo-btn"
            href={appLogo}
            download="FitTrack-Logo.jpg"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>{lang === 'ur' ? 'Logo Download Karein' : 'Download Logo'}</span>
          </a>
        </div>
      </motion.div>
    </div>
  );
}
