import React, { useState } from 'react';
import { X, Target, Flame, Dumbbell, Droplets, Scale, Check } from 'lucide-react';
import { UserGoals, Language } from '../types';
import { TRANSLATIONS } from '../utils/translations';

interface GoalsModalProps {
  isOpen: boolean;
  onClose: () => void;
  goals: UserGoals;
  onSave: (newGoals: UserGoals) => void;
  lang: Language;
}

export default function GoalsModal({ isOpen, onClose, goals, onSave, lang }: GoalsModalProps) {
  const [formData, setFormData] = useState<UserGoals>({ ...goals });
  const t = TRANSLATIONS[lang];

  if (!isOpen) return null;

  const handleGoalPreset = (preset: 'lose_weight' | 'build_muscle' | 'maintain' | 'endurance') => {
    let calories = 2000;
    let protein = 130;
    let carbs = 220;
    let fat = 60;

    if (preset === 'lose_weight') {
      calories = 1800;
      protein = 145;
      carbs = 160;
      fat = 50;
    } else if (preset === 'build_muscle') {
      calories = 2500;
      protein = 165;
      carbs = 290;
      fat = 75;
    } else if (preset === 'endurance') {
      calories = 2300;
      protein = 120;
      carbs = 320;
      fat = 60;
    }

    setFormData((prev) => ({
      ...prev,
      fitnessGoal: preset,
      dailyCalories: calories,
      dailyProteinG: protein,
      dailyCarbsG: carbs,
      dailyFatG: fat,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  return (
    <div
      id="goals-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        id="goals-modal-container"
        className="w-full max-w-lg bg-white dark:bg-stone-900 rounded-2xl shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col max-h-[90vh] transition-colors"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-100 dark:border-stone-800 bg-stone-50/80 dark:bg-stone-800/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400 rounded-xl">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-stone-900 dark:text-white text-lg">
                {t.goals}
              </h3>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {lang === 'ur' ? 'Rozana ke calories aur macros set karein' : 'Configure daily calories, macros, and targets'}
              </p>
            </div>
          </div>
          <button
            id="close-goals-modal-btn"
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6">
          {/* Quick Fitness Target Presets */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 uppercase tracking-wider mb-2">
              {lang === 'ur' ? 'Aapka Hadaf (Target Style)' : 'Fitness Goal Preset'}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'lose_weight', label: lang === 'ur' ? 'Wazan Kam' : 'Fat Loss', desc: '1800 kcal' },
                { id: 'maintain', label: lang === 'ur' ? 'Barabar' : 'Maintain', desc: '2000 kcal' },
                { id: 'build_muscle', label: lang === 'ur' ? 'Muscle Gain' : 'Muscle', desc: '2500 kcal' },
                { id: 'endurance', label: lang === 'ur' ? 'Endurance' : 'Athletic', desc: '2300 kcal' },
              ].map((p) => (
                <button
                  type="button"
                  key={p.id}
                  onClick={() => handleGoalPreset(p.id as any)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    formData.fitnessGoal === p.id
                      ? 'border-emerald-600 dark:border-emerald-500 bg-emerald-50/60 dark:bg-emerald-950/50 text-emerald-900 dark:text-emerald-300 shadow-sm'
                      : 'border-stone-200 dark:border-stone-700 hover:border-stone-300 dark:hover:border-stone-600 bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-200'
                  }`}
                >
                  <div className="text-xs font-bold">{p.label}</div>
                  <div className="text-[11px] text-stone-500 dark:text-stone-400 mt-0.5">{p.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Calorie Goal */}
          <div className="bg-amber-50/50 dark:bg-amber-950/20 p-4 rounded-xl border border-amber-200/60 dark:border-amber-800/40">
            <div className="flex items-center gap-2 mb-2">
              <Flame className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <label htmlFor="daily-calories-input" className="text-sm font-semibold text-stone-800 dark:text-stone-200">
                {lang === 'ur' ? 'Rozana Calories Target (kcal)' : 'Daily Calorie Target (kcal)'}
              </label>
            </div>
            <div className="flex items-center gap-3">
              <input
                id="daily-calories-input"
                type="number"
                min="800"
                max="6000"
                step="50"
                value={formData.dailyCalories}
                onChange={(e) => setFormData({ ...formData, dailyCalories: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-lg font-bold text-stone-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <span className="text-sm font-medium text-stone-500 dark:text-stone-400 whitespace-nowrap">kcal / day</span>
            </div>
          </div>

          {/* Macros: Protein, Carbs, Fat */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 uppercase tracking-wider mb-2">
              {lang === 'ur' ? 'Macronutrients Hadaf (Grams)' : 'Macronutrient Targets (Grams)'}
            </label>
            <div className="grid grid-cols-3 gap-3">
              {/* Protein */}
              <div className="p-3 bg-red-50/50 dark:bg-red-950/20 rounded-xl border border-red-100 dark:border-red-900/40">
                <span className="text-xs font-semibold text-red-700 dark:text-red-400 block mb-1">
                  {lang === 'ur' ? 'Protein' : 'Protein (g)'}
                </span>
                <input
                  id="protein-goal-input"
                  type="number"
                  min="20"
                  max="400"
                  value={formData.dailyProteinG}
                  onChange={(e) => setFormData({ ...formData, dailyProteinG: Number(e.target.value) })}
                  className="w-full px-2 py-1.5 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-md font-bold text-stone-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-400"
                />
                <span className="text-[10px] text-stone-500 dark:text-stone-400 mt-1 block">4 kcal/g</span>
              </div>

              {/* Carbs */}
              <div className="p-3 bg-blue-50/50 dark:bg-blue-950/20 rounded-xl border border-blue-100 dark:border-blue-900/40">
                <span className="text-xs font-semibold text-blue-700 dark:text-blue-400 block mb-1">
                  {lang === 'ur' ? 'Carbs' : 'Carbs (g)'}
                </span>
                <input
                  id="carbs-goal-input"
                  type="number"
                  min="20"
                  max="700"
                  value={formData.dailyCarbsG}
                  onChange={(e) => setFormData({ ...formData, dailyCarbsG: Number(e.target.value) })}
                  className="w-full px-2 py-1.5 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-md font-bold text-stone-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
                <span className="text-[10px] text-stone-500 dark:text-stone-400 mt-1 block">4 kcal/g</span>
              </div>

              {/* Fat */}
              <div className="p-3 bg-amber-50/50 dark:bg-amber-950/20 rounded-xl border border-amber-100 dark:border-amber-900/40">
                <span className="text-xs font-semibold text-amber-700 dark:text-amber-400 block mb-1">
                  {lang === 'ur' ? 'Fat (Charbi)' : 'Fat (g)'}
                </span>
                <input
                  id="fat-goal-input"
                  type="number"
                  min="10"
                  max="200"
                  value={formData.dailyFatG}
                  onChange={(e) => setFormData({ ...formData, dailyFatG: Number(e.target.value) })}
                  className="w-full px-2 py-1.5 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-md font-bold text-stone-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
                />
                <span className="text-[10px] text-stone-500 dark:text-stone-400 mt-1 block">9 kcal/g</span>
              </div>
            </div>
          </div>

          {/* Hydration & Bodyweight Targets */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Water Target */}
            <div className="p-3.5 bg-sky-50/40 dark:bg-sky-950/20 rounded-xl border border-sky-100 dark:border-sky-900/40">
              <div className="flex items-center gap-1.5 mb-1.5 text-sky-800 dark:text-sky-300">
                <Droplets className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                <span className="text-xs font-semibold">
                  {lang === 'ur' ? 'Paani ka Target' : 'Water Target'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  id="water-goal-input"
                  type="number"
                  min="1000"
                  max="6000"
                  step="250"
                  value={formData.dailyWaterMl}
                  onChange={(e) => setFormData({ ...formData, dailyWaterMl: Number(e.target.value) })}
                  className="w-full px-2 py-1.5 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-md font-bold text-sm text-stone-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-sky-400"
                />
                <span className="text-xs text-stone-500 dark:text-stone-400 whitespace-nowrap">ml ({Math.round(formData.dailyWaterMl / 250)} glasses)</span>
              </div>
            </div>

            {/* Current vs Target Weight */}
            <div className="p-3.5 bg-stone-50 dark:bg-stone-800/50 rounded-xl border border-stone-200 dark:border-stone-700">
              <div className="flex items-center gap-1.5 mb-1.5 text-stone-800 dark:text-stone-200">
                <Scale className="w-4 h-4 text-stone-600 dark:text-stone-400" />
                <span className="text-xs font-semibold">
                  {lang === 'ur' ? 'Hadaf Wazan (kg)' : 'Target Weight (kg)'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  id="target-weight-input"
                  type="number"
                  step="0.5"
                  min="30"
                  max="250"
                  value={formData.targetWeightKg}
                  onChange={(e) => setFormData({ ...formData, targetWeightKg: Number(e.target.value) })}
                  className="w-full px-2 py-1.5 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-md font-bold text-sm text-stone-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-stone-400"
                />
                <span className="text-xs text-stone-500 dark:text-stone-400 whitespace-nowrap">kg</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-100 dark:border-stone-800">
            <button
              id="cancel-goals-btn"
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors"
            >
              {t.cancel}
            </button>
            <button
              id="save-goals-btn"
              type="submit"
              className="flex items-center gap-2 px-5 py-2 text-sm font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-md transition-all"
            >
              <Check className="w-4 h-4" />
              {t.saveChanges}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
