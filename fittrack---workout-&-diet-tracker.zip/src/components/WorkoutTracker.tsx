import React, { useState } from 'react';
import {
  Dumbbell,
  Plus,
  Trash2,
  CheckCircle2,
  Circle,
  Timer,
  Search,
  X,
  Flame,
  Clock,
  Layers,
  Sparkles,
  Check,
  ChevronDown
} from 'lucide-react';
import {
  DailyLog,
  ExerciseEntry,
  ExerciseSet,
  ExerciseCategory,
  MuscleGroup,
  Language,
  ExercisePreset
} from '../types';
import { EXERCISE_PRESETS, WORKOUT_ROUTINE_PRESETS } from '../data/predefinedData';
import { TRANSLATIONS } from '../utils/translations';

interface WorkoutTrackerProps {
  log: DailyLog;
  onUpdateLog: (updatedLog: DailyLog) => void;
  lang: Language;
  onOpenRestTimer: () => void;
}

export default function WorkoutTracker({
  log,
  onUpdateLog,
  lang,
  onOpenRestTimer,
}: WorkoutTrackerProps) {
  const t = TRANSLATIONS[lang];
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMuscle, setSelectedMuscle] = useState<string>('all');
  const [isCustomMode, setIsCustomMode] = useState(false);

  // Custom exercise form
  const [customName, setCustomName] = useState('');
  const [customCategory, setCustomCategory] = useState<ExerciseCategory>('strength');
  const [customMuscle, setCustomMuscle] = useState<MuscleGroup>('chest');
  const [customSets, setCustomSets] = useState(3);
  const [customReps, setCustomReps] = useState(10);
  const [customWeight, setCustomWeight] = useState(20);
  const [customBurn, setCustomBurn] = useState(80);

  // Calculate workout summary totals
  const totalExercises = log.workouts.length;
  const totalSets = log.workouts.reduce((acc, w) => acc + w.sets.length, 0);
  const completedSets = log.workouts.reduce(
    (acc, w) => acc + w.sets.filter((s) => s.completed).length,
    0
  );
  const totalDurationMin = log.workouts.reduce((acc, w) => acc + (w.durationMinutes || 0), 0);
  const totalCaloriesBurned = log.workouts.reduce((acc, w) => acc + (w.caloriesBurned || 0), 0);

  const handleToggleSetCompleted = (exerciseId: string, setId: string) => {
    const updatedWorkouts = log.workouts.map((ex) => {
      if (ex.id !== exerciseId) return ex;
      return {
        ...ex,
        sets: ex.sets.map((s) => (s.id === setId ? { ...s, completed: !s.completed } : s)),
      };
    });
    onUpdateLog({ ...log, workouts: updatedWorkouts });
  };

  const handleUpdateSet = (
    exerciseId: string,
    setId: string,
    field: 'weightKg' | 'reps',
    value: number
  ) => {
    const updatedWorkouts = log.workouts.map((ex) => {
      if (ex.id !== exerciseId) return ex;
      return {
        ...ex,
        sets: ex.sets.map((s) => (s.id === setId ? { ...s, [field]: value } : s)),
      };
    });
    onUpdateLog({ ...log, workouts: updatedWorkouts });
  };

  const handleAddSetToExercise = (exerciseId: string) => {
    const updatedWorkouts = log.workouts.map((ex) => {
      if (ex.id !== exerciseId) return ex;
      const lastSet = ex.sets[ex.sets.length - 1];
      const newSet: ExerciseSet = {
        id: `set_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
        setNumber: ex.sets.length + 1,
        weightKg: lastSet ? lastSet.weightKg : 20,
        reps: lastSet ? lastSet.reps : 10,
        completed: false,
      };
      return {
        ...ex,
        sets: [...ex.sets, newSet],
        caloriesBurned: ex.caloriesBurned + 20,
      };
    });
    onUpdateLog({ ...log, workouts: updatedWorkouts });
  };

  const handleDeleteSet = (exerciseId: string, setId: string) => {
    const updatedWorkouts = log.workouts.map((ex) => {
      if (ex.id !== exerciseId) return ex;
      const filtered = ex.sets
        .filter((s) => s.id !== setId)
        .map((s, idx) => ({ ...s, setNumber: idx + 1 }));
      return {
        ...ex,
        sets: filtered,
      };
    });
    onUpdateLog({ ...log, workouts: updatedWorkouts });
  };

  const handleDeleteExercise = (exerciseId: string) => {
    onUpdateLog({
      ...log,
      workouts: log.workouts.filter((ex) => ex.id !== exerciseId),
    });
  };

  const handleAddPresetExercise = (preset: ExercisePreset) => {
    const sets: ExerciseSet[] = Array.from({ length: preset.defaultSets }, (_, i) => ({
      id: `set_${Date.now()}_${i}`,
      setNumber: i + 1,
      weightKg: preset.defaultWeightKg,
      reps: preset.defaultReps,
      completed: false,
    }));

    const duration = preset.category === 'cardio' ? 20 : preset.defaultSets * 4;
    const burned = Math.round(duration * preset.estCaloriesPerMinute);

    const newExercise: ExerciseEntry = {
      id: `ex_${Date.now()}`,
      name: preset.name,
      nameUrdu: preset.nameUrdu,
      category: preset.category,
      muscleGroup: preset.muscleGroup,
      sets,
      durationMinutes: duration,
      caloriesBurned: burned,
    };

    onUpdateLog({
      ...log,
      workouts: [...log.workouts, newExercise],
    });

    setIsAddModalOpen(false);
    setSearchQuery('');
  };

  const handleAddCustomExercise = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;

    const sets: ExerciseSet[] = Array.from({ length: Number(customSets) || 3 }, (_, i) => ({
      id: `c_set_${Date.now()}_${i}`,
      setNumber: i + 1,
      weightKg: Number(customWeight) || 0,
      reps: Number(customReps) || 10,
      completed: false,
    }));

    const newExercise: ExerciseEntry = {
      id: `custom_ex_${Date.now()}`,
      name: customName.trim(),
      category: customCategory,
      muscleGroup: customMuscle,
      sets,
      durationMinutes: 15,
      caloriesBurned: Number(customBurn) || 80,
    };

    onUpdateLog({
      ...log,
      workouts: [...log.workouts, newExercise],
    });

    setIsAddModalOpen(false);
    setIsCustomMode(false);
    setCustomName('');
  };

  const handleApplyRoutine = (routineId: string) => {
    const routine = WORKOUT_ROUTINE_PRESETS.find((r) => r.id === routineId);
    if (!routine) return;

    const newExercises: ExerciseEntry[] = [];
    routine.exercises.forEach((exName, index) => {
      const preset = EXERCISE_PRESETS.find((p) => p.name === exName);
      if (preset) {
        const sets: ExerciseSet[] = Array.from({ length: preset.defaultSets }, (_, i) => ({
          id: `r_set_${Date.now()}_${index}_${i}`,
          setNumber: i + 1,
          weightKg: preset.defaultWeightKg,
          reps: preset.defaultReps,
          completed: false,
        }));
        const duration = preset.category === 'cardio' ? 15 : preset.defaultSets * 3;
        newExercises.push({
          id: `r_ex_${Date.now()}_${index}`,
          name: preset.name,
          nameUrdu: preset.nameUrdu,
          category: preset.category,
          muscleGroup: preset.muscleGroup,
          sets,
          durationMinutes: duration,
          caloriesBurned: Math.round(duration * preset.estCaloriesPerMinute),
        });
      }
    });

    onUpdateLog({
      ...log,
      workouts: [...log.workouts, ...newExercises],
    });
  };

  const filteredExercises = EXERCISE_PRESETS.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.nameUrdu && p.nameUrdu.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesMuscle = selectedMuscle === 'all' || p.muscleGroup === selectedMuscle;
    return matchesSearch && matchesMuscle;
  });

  return (
    <div id="workout-tracker-section" className="space-y-6">
      {/* Top Workout Summary Header */}
      <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/80 dark:border-stone-800 p-5 shadow-sm transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-100 dark:border-stone-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-400 rounded-xl">
              <Dumbbell className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-stone-900 dark:text-white">
                {lang === 'ur' ? 'Warzish aur Workout Log' : 'Daily Workout Log'}
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {lang === 'ur'
                  ? 'Exercises, sets, wazan aur reps record karein'
                  : 'Track exercises, sets, weights, reps, and calories burned'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="open-rest-timer-trigger-btn"
              onClick={onOpenRestTimer}
              className="flex items-center gap-1.5 py-2 px-3 bg-stone-900 dark:bg-stone-800 hover:bg-stone-800 dark:hover:bg-stone-700 text-emerald-400 rounded-xl text-xs font-semibold shadow-sm transition-colors"
            >
              <Timer className="w-4 h-4" />
              <span>{t.activeTimer}</span>
            </button>

            <button
              id="open-add-exercise-modal-btn"
              onClick={() => {
                setIsAddModalOpen(true);
                setIsCustomMode(false);
                setSearchQuery('');
              }}
              className="flex items-center gap-1.5 py-2 px-4 bg-emerald-600 hover:bg-emerald-500 dark:bg-emerald-500 dark:hover:bg-emerald-400 text-white dark:text-stone-950 font-bold rounded-xl text-xs font-semibold shadow-sm transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>{t.logWorkout}</span>
            </button>
          </div>
        </div>

        {/* 4 Workout Metric Badges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4">
          <div className="bg-stone-50 dark:bg-stone-800/80 p-3 rounded-xl border border-stone-100 dark:border-stone-700">
            <div className="flex items-center gap-1.5 text-stone-500 dark:text-stone-400 text-xs mb-1">
              <Layers className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>{lang === 'ur' ? 'Exercises' : 'Exercises'}</span>
            </div>
            <div className="text-xl font-bold text-stone-900 dark:text-white font-mono">
              {totalExercises}
            </div>
          </div>

          <div className="bg-stone-50 dark:bg-stone-800/80 p-3 rounded-xl border border-stone-100 dark:border-stone-700">
            <div className="flex items-center gap-1.5 text-stone-500 dark:text-stone-400 text-xs mb-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>{lang === 'ur' ? 'Mukammal Sets' : 'Sets Done'}</span>
            </div>
            <div className="text-xl font-bold text-stone-900 dark:text-white font-mono">
              {completedSets} <span className="text-xs text-stone-400 font-sans">/ {totalSets}</span>
            </div>
          </div>

          <div className="bg-stone-50 dark:bg-stone-800/80 p-3 rounded-xl border border-stone-100 dark:border-stone-700">
            <div className="flex items-center gap-1.5 text-stone-500 dark:text-stone-400 text-xs mb-1">
              <Clock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span>{lang === 'ur' ? 'Kul Waqt' : 'Time'}</span>
            </div>
            <div className="text-xl font-bold text-stone-900 dark:text-white font-mono">
              {totalDurationMin} <span className="text-xs text-stone-400 font-sans">min</span>
            </div>
          </div>

          <div className="bg-stone-50 dark:bg-stone-800/80 p-3 rounded-xl border border-stone-100 dark:border-stone-700">
            <div className="flex items-center gap-1.5 text-stone-500 dark:text-stone-400 text-xs mb-1">
              <Flame className="w-3.5 h-3.5 text-orange-600 dark:text-orange-400" />
              <span>{lang === 'ur' ? 'Calories Jali' : 'Burned'}</span>
            </div>
            <div className="text-xl font-bold text-orange-600 dark:text-orange-400 font-mono">
              {totalCaloriesBurned} <span className="text-xs text-stone-400 font-sans">kcal</span>
            </div>
          </div>
        </div>
      </div>

      {/* Routine Quick Loader Banner */}
      <div className="bg-emerald-950 text-white rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 border border-emerald-900/60">
        <div className="flex items-center gap-2.5">
          <Sparkles className="w-5 h-5 text-emerald-400 shrink-0" />
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-300">
              {lang === 'ur' ? 'Quick Routines (1-Click Shuru)' : 'Quick Workout Splits'}
            </h4>
            <p className="text-xs text-stone-300">
              {lang === 'ur'
                ? 'Push Day, Pull Day ya Cardio session foran add karein'
                : 'Select pre-structured routines to instantly fill today\'s log'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {WORKOUT_ROUTINE_PRESETS.map((routine) => (
            <button
              key={routine.id}
              id={`quick-routine-${routine.id}`}
              onClick={() => handleApplyRoutine(routine.id)}
              className="py-1.5 px-3 bg-stone-800/90 dark:bg-stone-900/90 hover:bg-emerald-600 text-stone-100 hover:text-white text-xs font-semibold rounded-xl border border-stone-700/60 transition-colors"
            >
              + {lang === 'ur' ? routine.titleUrdu : routine.title.split(' (')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* Exercises Logged Today */}
      {log.workouts.length === 0 ? (
        <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/80 dark:border-stone-800 p-8 text-center transition-colors">
          <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-3">
            <Dumbbell className="w-6 h-6" />
          </div>
          <p className="text-sm text-stone-600 dark:text-stone-400 max-w-md mx-auto mb-4">{t.noWorkoutsToday}</p>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="py-2.5 px-5 bg-emerald-600 hover:bg-emerald-500 dark:bg-emerald-500 dark:hover:bg-emerald-400 text-white dark:text-stone-950 font-bold text-xs rounded-xl shadow-sm transition-all"
          >
            {t.logWorkout}
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {log.workouts.map((exercise) => {
            const completedCount = exercise.sets.filter((s) => s.completed).length;

            return (
              <div
                key={exercise.id}
                id={`exercise-card-${exercise.id}`}
                className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/80 dark:border-stone-800 overflow-hidden shadow-sm hover:border-stone-300 dark:hover:border-stone-700 transition-all"
              >
                {/* Exercise Card Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between px-5 py-4 bg-stone-50/70 dark:bg-stone-800/60 border-b border-stone-100 dark:border-stone-800 gap-2">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-stone-900 dark:text-white text-base">
                        {exercise.name}
                      </h3>
                      {exercise.nameUrdu && lang === 'ur' && (
                        <span className="text-xs text-stone-500 dark:text-stone-400">
                          ({exercise.nameUrdu})
                        </span>
                      )}
                      <span className="text-[11px] font-semibold uppercase px-2 py-0.5 rounded-md bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-300">
                        {exercise.muscleGroup}
                      </span>
                      <span className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                        {exercise.category}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 mt-1 text-xs text-stone-500 dark:text-stone-400">
                      <span>
                        {completedCount}/{exercise.sets.length} {lang === 'ur' ? 'sets mukammal' : 'sets done'}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1 text-orange-700 dark:text-orange-400 font-medium">
                        <Flame className="w-3 h-3 text-orange-500" />
                        ~{exercise.caloriesBurned} kcal
                      </span>
                      {exercise.durationMinutes && (
                        <>
                          <span>•</span>
                          <span>{exercise.durationMinutes} min</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <button
                      onClick={onOpenRestTimer}
                      className="p-1.5 text-stone-500 dark:text-stone-400 hover:text-emerald-700 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg text-xs flex items-center gap-1 font-medium transition-colors"
                      title={t.activeTimer}
                    >
                      <Timer className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                      <span className="hidden sm:inline">{lang === 'ur' ? 'Timer' : 'Rest'}</span>
                    </button>

                    <button
                      id={`delete-exercise-${exercise.id}`}
                      onClick={() => handleDeleteExercise(exercise.id)}
                      className="p-1.5 text-stone-400 dark:text-stone-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg transition-colors"
                      title={t.delete}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Sets & Reps Table */}
                <div className="p-4 overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-stone-400 dark:text-stone-500 uppercase text-[10px] tracking-wider border-b border-stone-100 dark:border-stone-800">
                        <th className="text-left pb-2 w-12">{t.set}</th>
                        <th className="text-left pb-2">{t.weight}</th>
                        <th className="text-left pb-2">{t.reps}</th>
                        <th className="text-center pb-2 w-16">{t.done}</th>
                        <th className="text-right pb-2 w-10"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                      {exercise.sets.map((s) => (
                        <tr
                          key={s.id}
                          className={`hover:bg-stone-50/50 dark:hover:bg-stone-800/40 transition-colors ${
                            s.completed ? 'bg-emerald-50/20 dark:bg-emerald-950/20' : ''
                          }`}
                        >
                          <td className="py-2.5 font-bold text-stone-600 dark:text-stone-400">
                            #{s.setNumber}
                          </td>
                          <td className="py-2.5">
                            <div className="flex items-center gap-1">
                              <input
                                id={`set-weight-${s.id}`}
                                type="number"
                                min="0"
                                step="0.5"
                                value={s.weightKg}
                                onChange={(e) =>
                                  handleUpdateSet(
                                    exercise.id,
                                    s.id,
                                    'weightKg',
                                    Number(e.target.value)
                                  )
                                }
                                className="w-16 px-2 py-1 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-md font-bold text-stone-800 dark:text-stone-200 text-xs focus:ring-1 focus:ring-emerald-500"
                              />
                              <span className="text-[10px] text-stone-400">kg</span>
                            </div>
                          </td>
                          <td className="py-2.5">
                            <div className="flex items-center gap-1">
                              <input
                                id={`set-reps-${s.id}`}
                                type="number"
                                min="1"
                                value={s.reps}
                                onChange={(e) =>
                                  handleUpdateSet(
                                    exercise.id,
                                    s.id,
                                    'reps',
                                    Number(e.target.value)
                                  )
                                }
                                className="w-16 px-2 py-1 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-md font-bold text-stone-800 dark:text-stone-200 text-xs focus:ring-1 focus:ring-emerald-500"
                              />
                              <span className="text-[10px] text-stone-400">reps</span>
                            </div>
                          </td>
                          <td className="py-2.5 text-center">
                            <button
                              id={`toggle-set-${s.id}`}
                              onClick={() => handleToggleSetCompleted(exercise.id, s.id)}
                              className={`p-1 rounded-full transition-transform active:scale-90 ${
                                s.completed
                                  ? 'text-emerald-600 hover:text-emerald-700 dark:text-emerald-400'
                                  : 'text-stone-300 dark:text-stone-600 hover:text-stone-500'
                              }`}
                              title="Toggle completed"
                            >
                              {s.completed ? (
                                <CheckCircle2 className="w-5 h-5 fill-emerald-100 dark:fill-emerald-950" />
                              ) : (
                                <Circle className="w-5 h-5" />
                              )}
                            </button>
                          </td>
                          <td className="py-2.5 text-right">
                            <button
                              id={`delete-set-${s.id}`}
                              onClick={() => handleDeleteSet(exercise.id, s.id)}
                              className="text-stone-300 dark:text-stone-600 hover:text-red-500 dark:hover:text-red-400 p-1 rounded transition-colors"
                              title="Delete set"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  {/* Add Set Button */}
                  <div className="pt-3 flex items-center justify-between border-t border-stone-100 dark:border-stone-800 mt-2">
                    <button
                      id={`add-set-to-${exercise.id}`}
                      onClick={() => handleAddSetToExercise(exercise.id)}
                      className="flex items-center gap-1 py-1.5 px-3 bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 text-xs font-semibold rounded-lg transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      {t.addSet}
                    </button>

                    {exercise.notes && (
                      <span className="text-[11px] text-stone-500 dark:text-stone-400 italic max-w-xs truncate">
                        "{exercise.notes}"
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Exercise Modal */}
      {isAddModalOpen && (
        <div
          id="add-exercise-modal-overlay"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm"
          onClick={() => setIsAddModalOpen(false)}
        >
          <div
            id="add-exercise-modal-container"
            className="w-full max-w-xl bg-white dark:bg-stone-900 rounded-2xl shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col max-h-[88vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-stone-100 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/60">
              <div>
                <h3 className="font-bold text-stone-900 dark:text-white text-base">
                  {lang === 'ur' ? 'Warzish Shamil Karein' : 'Add Exercise to Workout'}
                </h3>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  {lang === 'ur'
                    ? 'Library se select karein ya custom exercise likhein'
                    : 'Pick from library or create your own custom exercise'}
                </p>
              </div>
              <button
                id="close-add-exercise-modal"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mode Switcher */}
            <div className="flex border-b border-stone-200 dark:border-stone-800 px-6 pt-3 gap-4">
              <button
                type="button"
                id="tab-exercise-presets"
                onClick={() => setIsCustomMode(false)}
                className={`pb-3 text-sm font-semibold border-b-2 transition-all ${
                  !isCustomMode
                    ? 'border-emerald-600 dark:border-emerald-400 text-emerald-700 dark:text-emerald-400'
                    : 'border-transparent text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200'
                }`}
              >
                {lang === 'ur' ? 'Exercise Library' : 'Exercise Library'}
              </button>

              <button
                type="button"
                id="tab-custom-exercise"
                onClick={() => setIsCustomMode(true)}
                className={`pb-3 text-sm font-semibold border-b-2 transition-all ${
                  isCustomMode
                    ? 'border-emerald-600 dark:border-emerald-400 text-emerald-700 dark:text-emerald-400'
                    : 'border-transparent text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200'
                }`}
              >
                {lang === 'ur' ? 'Custom Exercise' : 'Custom Exercise'}
              </button>
            </div>

            {!isCustomMode ? (
              <div className="p-6 flex-1 overflow-y-auto space-y-4">
                {/* Search */}
                <div className="relative">
                  <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
                  <input
                    id="search-exercise-input"
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={t.searchExercise}
                    className="w-full pl-10 pr-4 py-2.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white placeholder-stone-400 dark:placeholder-stone-500 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Muscle Group Filters */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                  {[
                    { id: 'all', label: lang === 'ur' ? 'Tamam' : 'All' },
                    { id: 'chest', label: lang === 'ur' ? 'Seena (Chest)' : 'Chest' },
                    { id: 'back', label: lang === 'ur' ? 'Kamar (Back)' : 'Back' },
                    { id: 'legs', label: lang === 'ur' ? 'Taangain (Legs)' : 'Legs' },
                    { id: 'shoulders', label: lang === 'ur' ? 'Kandhey (Shoulders)' : 'Shoulders' },
                    { id: 'arms', label: lang === 'ur' ? 'Bazu (Arms)' : 'Arms' },
                    { id: 'core', label: lang === 'ur' ? 'Pet (Core/Abs)' : 'Core' },
                    { id: 'full_body', label: lang === 'ur' ? 'Cardio / Daur' : 'Cardio' },
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setSelectedMuscle(m.id)}
                      className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-colors ${
                        selectedMuscle === m.id
                          ? 'bg-emerald-600 dark:bg-emerald-500 text-white dark:text-stone-950 font-bold'
                          : 'bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>

                {/* Exercises List */}
                <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                  {filteredExercises.map((preset, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-stone-50/80 dark:bg-stone-800/80 hover:bg-emerald-50/50 dark:hover:bg-emerald-950/30 border border-stone-200/70 dark:border-stone-700 hover:border-emerald-300 dark:hover:border-emerald-700 rounded-xl flex items-center justify-between transition-all"
                    >
                      <div>
                        <div className="font-semibold text-sm text-stone-900 dark:text-white">
                          {preset.name}
                        </div>
                        {lang === 'ur' && preset.nameUrdu && (
                          <div className="text-xs text-stone-500 dark:text-stone-400">
                            {preset.nameUrdu}
                          </div>
                        )}
                        <div className="flex items-center gap-2 mt-1 text-xs text-stone-500 dark:text-stone-400">
                          <span className="capitalize font-medium text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded">
                            {preset.muscleGroup}
                          </span>
                          <span>•</span>
                          <span>
                            {preset.defaultSets} sets × {preset.defaultReps} reps
                          </span>
                          {preset.defaultWeightKg > 0 && (
                            <>
                              <span>•</span>
                              <span>{preset.defaultWeightKg} kg</span>
                            </>
                          )}
                        </div>
                      </div>

                      <button
                        type="button"
                        id={`select-exercise-preset-${idx}`}
                        onClick={() => handleAddPresetExercise(preset)}
                        className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 dark:bg-emerald-500 dark:hover:bg-emerald-400 text-white dark:text-stone-950 text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        {lang === 'ur' ? 'Shamil' : 'Add'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              /* Custom Exercise Form */
              <form onSubmit={handleAddCustomExercise} className="p-6 space-y-4 overflow-y-auto flex-1">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    {lang === 'ur' ? 'Warzish ka Naam' : 'Exercise Name *'}
                  </label>
                  <input
                    id="custom-exercise-name-input"
                    type="text"
                    required
                    placeholder="e.g. Incline Cable Flyes, Kettlebell Swings"
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white placeholder-stone-400 dark:placeholder-stone-500 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                      {lang === 'ur' ? 'Makhsoos Muscle' : 'Target Muscle'}
                    </label>
                    <select
                      id="custom-exercise-muscle-select"
                      value={customMuscle}
                      onChange={(e) => setCustomMuscle(e.target.value as MuscleGroup)}
                      className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white rounded-xl text-sm capitalize focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="chest">Chest (Seena)</option>
                      <option value="back">Back (Kamar)</option>
                      <option value="legs">Legs (Taangain)</option>
                      <option value="shoulders">Shoulders (Kandhey)</option>
                      <option value="arms">Arms (Bazu)</option>
                      <option value="core">Core (Abs)</option>
                      <option value="full_body">Full Body / Cardio</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                      {lang === 'ur' ? 'Qisam' : 'Category'}
                    </label>
                    <select
                      id="custom-exercise-category-select"
                      value={customCategory}
                      onChange={(e) => setCustomCategory(e.target.value as ExerciseCategory)}
                      className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white rounded-xl text-sm capitalize focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="strength">Strength / Weights</option>
                      <option value="cardio">Cardio</option>
                      <option value="hiit">HIIT / Calisthenics</option>
                      <option value="flexibility">Flexibility / Stretch</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-600 dark:text-stone-400 mb-1">
                      {lang === 'ur' ? 'Sets' : 'Sets'}
                    </label>
                    <input
                      id="custom-exercise-sets-input"
                      type="number"
                      min="1"
                      value={customSets}
                      onChange={(e) => setCustomSets(Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white rounded-lg text-sm font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-stone-600 dark:text-stone-400 mb-1">
                      {lang === 'ur' ? 'Reps' : 'Reps'}
                    </label>
                    <input
                      id="custom-exercise-reps-input"
                      type="number"
                      min="1"
                      value={customReps}
                      onChange={(e) => setCustomReps(Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white rounded-lg text-sm font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-stone-600 dark:text-stone-400 mb-1">
                      {lang === 'ur' ? 'Wazan (kg)' : 'Weight (kg)'}
                    </label>
                    <input
                      id="custom-exercise-weight-input"
                      type="number"
                      min="0"
                      value={customWeight}
                      onChange={(e) => setCustomWeight(Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white rounded-lg text-sm font-semibold"
                    />
                  </div>
                </div>

                <div className="pt-4 flex items-center justify-end gap-2 border-t border-stone-100 dark:border-stone-800">
                  <button
                    type="button"
                    onClick={() => setIsCustomMode(false)}
                    className="px-4 py-2 text-xs font-semibold text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl"
                  >
                    {t.cancel}
                  </button>
                  <button
                    id="submit-custom-exercise-btn"
                    type="submit"
                    className="px-5 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 dark:bg-emerald-500 dark:hover:bg-emerald-400 text-white dark:text-stone-950 font-bold rounded-xl shadow-sm flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    {lang === 'ur' ? 'Exercise Mehfooz Karein' : 'Add Exercise'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
