import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Send,
  Bot,
  User,
  Sparkles,
  RotateCcw,
  Copy,
  Check,
  Dumbbell,
  Flame,
  Apple,
  HeartPulse,
  ChevronDown,
  Volume2,
  VolumeX,
  Zap,
  Activity,
  Layers,
  HelpCircle,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ChatMessage,
  COACH_ROLES,
  GEMINI_CHAT_MODELS,
  sendChatMessage,
} from '../services/geminiService';
import { DailyLog, UserGoals, Language } from '../types';

interface GeminiChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLog: DailyLog;
  goals: UserGoals;
  lang: Language;
  onOpenLiveVoice?: () => void;
}

const STORAGE_KEY = 'fittrack_gemini_chat_history';

export default function GeminiChatModal({
  isOpen,
  onClose,
  currentLog,
  goals,
  lang,
  onOpenLiveVoice,
}: GeminiChatModalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch (e) {
          // ignore
        }
      }
    }
    return [
      {
        id: 'initial-welcome',
        role: 'model',
        text:
          lang === 'hi'
            ? 'नमस्ते! मैं आपका FitTrack AI कोच हूँ। आज के वर्कआउट, डाइट प्लान या फिटनेस लक्ष्य के बारे में कोई भी सवाल पूछें!'
            : lang === 'ur'
            ? 'Salam! Main aapka FitTrack AI Coach hoon. Aaj ki diet, workout ya fitness goals ke baare mein koi bhi sawal poochein!'
            : 'Hello! I am your FitTrack AI Coach. Ask me anything about your training splits, workout form, calories, macro balance, or daily recovery!',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: 'gemini-3.8-flash',
      },
    ];
  });

  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedRole, setSelectedRole] = useState<string>(COACH_ROLES[0].id);
  const [selectedModel, setSelectedModel] = useState<string>('gemini-3.8-flash');
  const [includeContext, setIncludeContext] = useState<boolean>(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Save conversation history to local storage
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
    }
  }, [messages]);

  // Scroll to bottom on new messages
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isLoading]);

  if (!isOpen) return null;

  const currentCoach = COACH_ROLES.find((r) => r.id === selectedRole) || COACH_ROLES[0];
  const activeModel = GEMINI_CHAT_MODELS.find((m) => m.id === selectedModel) || GEMINI_CHAT_MODELS[0];

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text || isLoading) return;

    const userMsg: ChatMessage = {
      id: 'msg-' + Date.now(),
      role: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInputMessage('');
    setIsLoading(true);

    // Prepare fitness context if enabled
    let userContext: any = null;
    if (includeContext) {
      const allFoodItems = [
        ...(currentLog.meals.breakfast || []),
        ...(currentLog.meals.lunch || []),
        ...(currentLog.meals.dinner || []),
        ...(currentLog.meals.snack || []),
      ];
      const consumedCalories = allFoodItems.reduce((sum, m) => sum + m.calories, 0);
      const protein = allFoodItems.reduce((sum, m) => sum + m.protein, 0);
      const carbs = allFoodItems.reduce((sum, m) => sum + m.carbs, 0);
      const fat = allFoodItems.reduce((sum, m) => sum + m.fat, 0);
      const exercisesLogged = (currentLog.workouts || []).map((e) => ({
        name: e.name,
        sets: e.sets.length,
        category: e.category,
      }));

      userContext = {
        date: currentLog.date,
        caloriesConsumed: consumedCalories,
        calorieGoal: goals.dailyCalories,
        macrosConsumed: { protein, carbs, fat },
        macroGoals: { protein: goals.dailyProteinG, carbs: goals.dailyCarbsG, fat: goals.dailyFatG },
        waterConsumedMl: currentLog.waterIntakeMl,
        waterGoalMl: goals.dailyWaterMl,
        exercisesLoggedToday: exercisesLogged,
        fitnessGoal: goals.fitnessGoal,
        preferredLanguage: lang === 'hi' ? 'Hindi' : lang === 'ur' ? 'Roman Urdu' : 'English',
      };
    }

    try {
      // Build messages payload for API (role: 'user' | 'model', text)
      const apiMessages = newHistory
        .filter((m) => !m.isError)
        .map((m) => ({
          role: m.role,
          text: m.text,
        }));

      const response = await sendChatMessage(
        apiMessages,
        selectedModel,
        currentCoach.systemInstruction,
        userContext
      );

      const botMsg: ChatMessage = {
        id: 'bot-' + Date.now(),
        role: 'model',
        text: response.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: response.modelUsed || selectedModel,
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (error: any) {
      const errorMsg: ChatMessage = {
        id: 'err-' + Date.now(),
        role: 'model',
        text:
          lang === 'hi'
            ? `क्षमा करें, उत्तर प्राप्त नहीं हो सका: ${error?.message || 'सर्वर त्रुटि'}। कृपया पुनः प्रयास करें।`
            : lang === 'ur'
            ? `Maazrat, jawab haasil nahi ho saka: ${error?.message || 'Server error'}. Baraye meherbani dobara koshish karein.`
            : `Sorry, unable to get response: ${error?.message || 'Server error'}. Please try again.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: true,
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
      textareaRef.current?.focus();
    }
  };

  const handleClearHistory = () => {
    const defaultWelcome: ChatMessage = {
      id: 'initial-welcome',
      role: 'model',
      text:
        lang === 'hi'
          ? 'चैट हिस्ट्री साफ़ हो गई है! मैं आपका FitTrack AI कोच हूँ। बताइए आज मैं आपकी क्या सहायता करूँ?'
          : lang === 'ur'
          ? 'Chat history saaf ho gayi hai! Main aapka FitTrack AI Coach hoon. Kahiye aaj main aapki kya madad karoon?'
          : 'Conversation cleared! I am your FitTrack AI Coach. How can I help you crush your fitness goals today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      modelUsed: selectedModel,
    };
    setMessages([defaultWelcome]);
    if (typeof window !== 'undefined') {
      localStorage.removeItem(STORAGE_KEY);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (text: string, id: string) => {
    if ('speechSynthesis' in window) {
      if (speakingId === id) {
        window.speechSynthesis.cancel();
        setSpeakingId(null);
        return;
      }
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      if (lang === 'hi') utterance.lang = 'hi-IN';
      else if (lang === 'ur') utterance.lang = 'ur-PK';
      else utterance.lang = 'en-US';

      utterance.onend = () => setSpeakingId(null);
      utterance.onerror = () => setSpeakingId(null);
      window.speechSynthesis.speak(utterance);
      setSpeakingId(id);
    }
  };

  const quickPrompts =
    lang === 'hi'
      ? [
          'मेरी आज की कैलोरी और प्रोटीन का विश्लेषण करें',
          'हाई प्रोटीन पोस्ट-वर्कआउट डाइट क्या होनी चाहिए?',
          'चेस्ट और ट्राइसेप्स का 30 मिनट का वर्कआउट प्लान',
          'फैट लॉस के लिए कैलोरिक डेफिसिट कैसे बनाएं?',
        ]
      : lang === 'ur'
      ? [
          'Meri aaj ki diet aur calories ka tajziya karein',
          'High protein post-workout snack kya hona chahiye?',
          'Chest aur triceps ka 30-minute workout plan',
          'Weight loss ke liye caloric deficit kaise banayein?',
        ]
      : [
          'Analyze my current daily calories & macro split',
          'Suggest a quick 35-min hypertrophy chest workout',
          'What high-protein meal should I eat post-workout?',
          'How much rest between heavy compound sets?',
        ];

  return (
    <div
      id="gemini-chat-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/70 backdrop-blur-xs overflow-hidden"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 16 }}
        className="relative w-full max-w-3xl h-[92vh] max-h-[850px] bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl flex flex-col overflow-hidden text-stone-900 dark:text-stone-100"
      >
        {/* Top Header */}
        <div className="px-5 py-4 border-b border-stone-200/80 dark:border-stone-800 flex items-center justify-between bg-stone-50/70 dark:bg-stone-900/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-tr from-emerald-600 to-teal-500 text-white rounded-2xl shadow-sm">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base tracking-tight font-['Outfit',sans-serif]">
                  FitTrack AI Chatbot
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-500/20">
                  {activeModel.name}
                </span>
              </div>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {lang === 'ur' ? currentCoach.nameUr : currentCoach.name} • {lang === 'ur' ? currentCoach.descriptionUr : currentCoach.description}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {onOpenLiveVoice && (
              <button
                id="chat-open-live-voice-btn"
                onClick={() => {
                  onClose();
                  onOpenLiveVoice();
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
                title={lang === 'ur' ? 'Live Voice Conversation shuru karein' : 'Start Live Voice Conversation'}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{lang === 'ur' ? 'Voice Live' : 'Live Voice'}</span>
              </button>
            )}

            <button
              id="clear-chat-history-btn"
              onClick={handleClearHistory}
              className="p-2 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors cursor-pointer"
              title={lang === 'ur' ? 'History saaf karein' : 'Clear Chat History'}
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              id="close-gemini-chat-btn"
              onClick={onClose}
              className="p-2 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Sub-header Controls: Coach Persona & Model Selector */}
        <div className="px-5 py-2.5 bg-stone-100/70 dark:bg-stone-800/40 border-b border-stone-200/80 dark:border-stone-800 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
          {/* Coach Persona Selector */}
          <div className="flex items-center gap-2">
            <span className="text-stone-500 dark:text-stone-400 font-medium">
              {lang === 'ur' ? 'Coach:' : 'Coach Role:'}
            </span>
            <div className="flex items-center gap-1 overflow-x-auto py-1">
              {COACH_ROLES.map((role) => (
                <button
                  key={role.id}
                  onClick={() => setSelectedRole(role.id)}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    selectedRole === role.id
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700'
                  }`}
                >
                  {lang === 'ur' ? role.nameUr : role.name}
                </button>
              ))}
            </div>
          </div>

          {/* Model Selector */}
          <div className="flex items-center gap-2">
            <span className="text-stone-500 dark:text-stone-400 font-medium">
              {lang === 'ur' ? 'Model:' : 'Model:'}
            </span>
            <div className="flex items-center gap-1">
              {GEMINI_CHAT_MODELS.map((model) => (
                <button
                  key={model.id}
                  onClick={() => setSelectedModel(model.id)}
                  className={`px-2 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer whitespace-nowrap ${
                    selectedModel === model.id
                      ? 'bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 shadow-xs'
                      : 'bg-white dark:bg-stone-800 text-stone-500 dark:text-stone-400 hover:bg-stone-200 dark:hover:bg-stone-700'
                  }`}
                  title={lang === 'ur' ? model.descriptionUr : model.description}
                >
                  {model.tag}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Scrollable Messages Thread */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/20 mt-1">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-sm leading-relaxed shadow-xs relative group ${
                    isUser
                      ? 'bg-emerald-600 text-white rounded-tr-xs'
                      : msg.isError
                      ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200 border border-rose-200 dark:border-rose-900 rounded-tl-xs'
                      : 'bg-stone-100 dark:bg-stone-800/80 text-stone-800 dark:text-stone-100 border border-stone-200/60 dark:border-stone-700/60 rounded-tl-xs'
                  }`}
                >
                  {/* Message Header Info */}
                  <div className="flex items-center justify-between gap-3 text-[11px] opacity-75 mb-1.5 pb-1 border-b border-black/5 dark:border-white/5">
                    <span className="font-semibold">
                      {isUser
                        ? lang === 'ur'
                          ? 'Aap'
                          : 'You'
                        : lang === 'ur'
                        ? currentCoach.nameUr
                        : currentCoach.name}
                    </span>
                    <div className="flex items-center gap-1.5">
                      {msg.modelUsed && (
                        <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-black/10 dark:bg-white/10">
                          {msg.modelUsed.replace('gemini-', '')}
                        </span>
                      )}
                      <span>{msg.timestamp}</span>
                    </div>
                  </div>

                  {/* Message Content */}
                  <div className="whitespace-pre-wrap select-text">{msg.text}</div>

                  {/* Message Action Footer (Copy, TTS) */}
                  {!isUser && !msg.isError && (
                    <div className="mt-2 pt-1 flex items-center justify-end gap-2 text-stone-400 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => handleCopy(msg.text, msg.id)}
                        className="p-1 hover:text-emerald-600 dark:hover:text-emerald-400 rounded transition-colors cursor-pointer"
                        title={lang === 'ur' ? 'Copy karein' : 'Copy message'}
                      >
                        {copiedId === msg.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-500" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                      <button
                        onClick={() => handleSpeak(msg.text, msg.id)}
                        className="p-1 hover:text-emerald-600 dark:hover:text-emerald-400 rounded transition-colors cursor-pointer"
                        title={lang === 'ur' ? 'Parh kar sunain' : 'Read aloud'}
                      >
                        {speakingId === msg.id ? (
                          <VolumeX className="w-3.5 h-3.5 text-emerald-500" />
                        ) : (
                          <Volume2 className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  )}
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-stone-200 dark:bg-stone-700 text-stone-700 dark:text-stone-300 flex items-center justify-center shrink-0 mt-1">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 justify-start">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 flex items-center justify-center shrink-0 mt-1">
                <Bot className="w-4 h-4 animate-pulse" />
              </div>
              <div className="bg-stone-100 dark:bg-stone-800 rounded-2xl rounded-tl-xs p-4 border border-stone-200/60 dark:border-stone-700/60 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce [animation-delay:-0.3s]" />
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce [animation-delay:-0.15s]" />
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" />
                <span className="text-xs text-stone-500 dark:text-stone-400 font-medium ml-1">
                  {lang === 'ur' ? 'Coach jawab tayyar kar raha hai...' : 'AI Coach is thinking...'}
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Prompts */}
        <div className="px-5 py-2 border-t border-stone-100 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50 shrink-0">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            <span className="text-[11px] font-bold text-stone-400 shrink-0 flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-500" />
              {lang === 'ur' ? 'Suggestions:' : 'Quick:'}
            </span>
            {quickPrompts.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(prompt)}
                disabled={isLoading}
                className="px-2.5 py-1 rounded-full text-[11px] bg-white dark:bg-stone-800 text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-stone-700 hover:border-emerald-500 dark:hover:border-emerald-500 hover:text-emerald-600 transition-colors whitespace-nowrap cursor-pointer shrink-0 disabled:opacity-50"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>

        {/* Bottom Input Area */}
        <div className="p-4 bg-white dark:bg-stone-900 border-t border-stone-200/80 dark:border-stone-800 shrink-0">
          <div className="flex items-center justify-between mb-2 text-xs text-stone-500 dark:text-stone-400 px-1">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={includeContext}
                onChange={(e) => setIncludeContext(e.target.checked)}
                className="rounded text-emerald-600 focus:ring-emerald-500"
              />
              <span className="text-[11px]">
                {lang === 'ur'
                  ? 'Meri aaj ki diet aur workout ka snapshot shamil karein'
                  : "Include today's fitness data & log snapshot"}
              </span>
            </label>
            <span className="text-[10px] text-stone-400 font-mono">
              Enter to send, Shift+Enter for newline
            </span>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-end gap-2"
          >
            <div className="relative flex-1">
              <textarea
                ref={textareaRef}
                id="gemini-chat-input"
                rows={2}
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder={
                  lang === 'ur'
                    ? 'Apna sawal likhein... (e.g. "Meri protein requirement kya hai?")'
                    : 'Ask your AI Coach... (e.g. "What should I eat tonight to hit my protein goal?")'
                }
                className="w-full resize-none rounded-2xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/60 p-3 text-sm focus:border-emerald-500 focus:bg-white dark:focus:bg-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 text-stone-900 dark:text-white"
              />
            </div>

            <button
              id="gemini-chat-send-btn"
              type="submit"
              disabled={!inputMessage.trim() || isLoading}
              className="p-3.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-2xl shadow-md shadow-emerald-600/20 transition-all cursor-pointer shrink-0"
              title={lang === 'ur' ? 'Bhejein' : 'Send message'}
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}
