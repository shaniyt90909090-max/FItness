import React from 'react';
import { Droplets, Plus, Minus } from 'lucide-react';
import { Language } from '../types';

interface WaterTrackerProps {
  waterIntakeMl: number;
  dailyWaterMl: number;
  onUpdateWater: (newAmountMl: number) => void;
  lang: Language;
}

export default function WaterTracker({
  waterIntakeMl,
  dailyWaterMl,
  onUpdateWater,
  lang
}: WaterTrackerProps) {
  const percent = Math.min(100, Math.round((waterIntakeMl / dailyWaterMl) * 100));
  const currentGlasses = Math.round(waterIntakeMl / 250);
  const targetGlasses = Math.round(dailyWaterMl / 250);

  const addWater = (amount: number) => {
    onUpdateWater(Math.max(0, waterIntakeMl + amount));
  };

  return (
    <div
      id="water-tracker-card"
      className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/80 dark:border-stone-800 p-5 shadow-sm hover:shadow-md transition-all"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-sky-100 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 rounded-xl">
            <Droplets className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-stone-900 dark:text-white text-sm sm:text-base">
              {lang === 'ur' ? 'Paani ka Tracker' : 'Daily Hydration'}
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              {waterIntakeMl} ml / {dailyWaterMl} ml ({currentGlasses} of {targetGlasses} {lang === 'ur' ? 'gilaas' : 'glasses'})
            </p>
          </div>
        </div>

        <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border border-sky-200/60 dark:border-sky-800">
          {percent}%
        </span>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-stone-100 dark:bg-stone-800 h-3 rounded-full overflow-hidden mb-4">
        <div
          className="bg-gradient-to-r from-sky-400 to-cyan-500 h-full rounded-full transition-all duration-500"
          style={{ width: `${percent}%` }}
        />
      </div>

      {/* Quick Action Buttons */}
      <div className="flex items-center gap-2">
        <button
          id="add-water-250-btn"
          onClick={() => addWater(250)}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-sky-50 dark:bg-sky-950/40 hover:bg-sky-100 dark:hover:bg-sky-900/40 text-sky-800 dark:text-sky-300 text-xs font-semibold rounded-xl border border-sky-200 dark:border-sky-800/80 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          +250ml ({lang === 'ur' ? '1 Gilaas' : '1 Glass'})
        </button>

        <button
          id="add-water-500-btn"
          onClick={() => addWater(500)}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-sky-50 dark:bg-sky-950/40 hover:bg-sky-100 dark:hover:bg-sky-900/40 text-sky-800 dark:text-sky-300 text-xs font-semibold rounded-xl border border-sky-200 dark:border-sky-800/80 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          +500ml ({lang === 'ur' ? 'Shaker Bottle' : 'Bottle'})
        </button>

        <button
          id="minus-water-250-btn"
          onClick={() => addWater(-250)}
          disabled={waterIntakeMl <= 0}
          className="p-2 text-stone-400 dark:text-stone-500 hover:text-stone-600 dark:hover:text-stone-300 disabled:opacity-30 rounded-xl hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
          title="Remove 250ml"
        >
          <Minus className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
