import { useState } from 'react';
import { BarChart3, TrendingUp, Calendar, Dumbbell, Flame, Trophy, FileSpreadsheet, ExternalLink } from 'lucide-react';
import { DailyLog, UserGoals, Language } from '../types';
import { getRecentDailyLogs } from '../utils/storage';
import { getStoredConnectedSpreadsheet } from '../services/googleSheetsService';

interface WeeklyAnalyticsProps {
  currentLog: DailyLog;
  goals: UserGoals;
  lang: Language;
  onOpenGoogleSheetsModal?: () => void;
}

export default function WeeklyAnalytics({ currentLog, goals, lang, onOpenGoogleSheetsModal }: WeeklyAnalyticsProps) {
  const [selectedBar, setSelectedBar] = useState<number | null>(null);

  // Retrieve past 7 days logs
  const pastLogs = getRecentDailyLogs(7);

  // Replace today's log in pastLogs with active currentLog to ensure real-time accuracy
  const logs = pastLogs.map((l) => (l.date === currentLog.date ? currentLog : l));

  // Compute daily metrics for each day
  const dailyStats = logs.map((item) => {
    const allMeals = [
      ...item.meals.breakfast,
      ...item.meals.lunch,
      ...item.meals.dinner,
      ...item.meals.snack,
    ];
    const totalEaten = allMeals.reduce((acc, f) => acc + (f.calories || 0), 0);
    const totalProtein = allMeals.reduce((acc, f) => acc + (f.protein || 0), 0);
    const totalBurned = item.workouts.reduce((acc, w) => acc + (w.caloriesBurned || 0), 0);
    const completedSets = item.workouts.reduce(
      (acc, w) => acc + w.sets.filter((s) => s.completed).length,
      0
    );

    // Format day label (e.g. Mon, Tue or date)
    const dateObj = new Date(item.date + 'T00:00:00');
    const dayName = dateObj.toLocaleDateString('en-US', { weekday: 'short' });
    const isToday = item.date === currentLog.date;

    return {
      date: item.date,
      dayName,
      isToday,
      totalEaten,
      totalBurned,
      totalProtein,
      completedSets,
      workoutCount: item.workouts.length,
      waterIntakeMl: item.waterIntakeMl,
    };
  });

  const maxCalorieValue = Math.max(
    goals.dailyCalories,
    ...dailyStats.map((s) => Math.max(s.totalEaten, s.totalBurned, 1500))
  );

  const weeklyAvgCalories = Math.round(
    dailyStats.reduce((acc, s) => acc + s.totalEaten, 0) / dailyStats.length
  );
  const weeklyTotalWorkouts = dailyStats.reduce((acc, s) => acc + s.workoutCount, 0);
  const weeklyTotalBurned = dailyStats.reduce((acc, s) => acc + s.totalBurned, 0);

  return (
    <div id="weekly-analytics-section" className="space-y-6">
      {/* Analytics Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-stone-900 p-5 rounded-2xl border border-stone-200/80 dark:border-stone-800 shadow-sm transition-colors">
          <div className="flex items-center gap-2 text-stone-400 dark:text-stone-400 text-xs mb-1">
            <Flame className="w-4 h-4 text-amber-500" />
            <span>{lang === 'ur' ? 'Hafta-war Ausat Calories' : 'Weekly Avg Calories'}</span>
          </div>
          <div className="text-2xl font-bold text-stone-900 dark:text-white font-mono">
            {weeklyAvgCalories}{' '}
            <span className="text-xs font-medium text-stone-400 font-sans">kcal / day</span>
          </div>
          <div className="text-[11px] text-stone-500 dark:text-stone-400 mt-1">
            Target: {goals.dailyCalories} kcal
          </div>
        </div>

        <div className="bg-white dark:bg-stone-900 p-5 rounded-2xl border border-stone-200/80 dark:border-stone-800 shadow-sm transition-colors">
          <div className="flex items-center gap-2 text-stone-400 dark:text-stone-400 text-xs mb-1">
            <Dumbbell className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>{lang === 'ur' ? 'Kul Workouts (7 Din)' : 'Total Workouts (7 Days)'}</span>
          </div>
          <div className="text-2xl font-bold text-stone-900 dark:text-white font-mono">
            {weeklyTotalWorkouts}{' '}
            <span className="text-xs font-medium text-stone-400 font-sans">sessions</span>
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 flex items-center gap-1 font-medium">
            <Trophy className="w-3.5 h-3.5" />
            {lang === 'ur' ? 'Workout streak barqarar hai' : 'Consistent routine'}
          </div>
        </div>

        <div className="bg-white dark:bg-stone-900 p-5 rounded-2xl border border-stone-200/80 dark:border-stone-800 shadow-sm transition-colors">
          <div className="flex items-center gap-2 text-stone-400 dark:text-stone-400 text-xs mb-1">
            <TrendingUp className="w-4 h-4 text-orange-500" />
            <span>{lang === 'ur' ? 'Kul Calories Jali' : 'Total Calories Burned'}</span>
          </div>
          <div className="text-2xl font-bold text-orange-600 dark:text-orange-400 font-mono">
            {weeklyTotalBurned}{' '}
            <span className="text-xs font-medium text-stone-400 font-sans">kcal</span>
          </div>
          <div className="text-[11px] text-stone-500 dark:text-stone-400 mt-1">
            {lang === 'ur' ? 'Warzish aur cardio se' : 'From resistance & cardio'}
          </div>
        </div>
      </div>

      {/* 7-Day Calorie Balance Bar Chart */}
      <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/80 dark:border-stone-800 p-6 shadow-sm transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
          <div>
            <h3 className="font-bold text-stone-900 dark:text-white text-base flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              {lang === 'ur' ? '7 Din ka Calorie Jaiza (Khurak vs Warzish)' : '7-Day Calorie Intake vs Burn'}
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              {lang === 'ur'
                ? 'Khayi hui calories aur warzish mein jali hui calories ka mawazna'
                : 'Comparison of daily food intake vs exercise calories burned'}
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-xs bg-amber-500" />
              <span className="text-stone-600 dark:text-stone-300">{lang === 'ur' ? 'Khayi hui' : 'Intake (Eaten)'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-xs bg-orange-500" />
              <span className="text-stone-600 dark:text-stone-300">{lang === 'ur' ? 'Jali hui' : 'Burned'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-0.5 bg-stone-400" />
              <span className="text-stone-600 dark:text-stone-300">{lang === 'ur' ? 'Hadaf' : 'Target'}</span>
            </div>
          </div>
        </div>

        {/* SVG / CSS Bar Chart */}
        <div className="h-64 flex items-end justify-between gap-2 sm:gap-4 pt-8 pb-2 px-2 border-b border-stone-100 dark:border-stone-800 relative">
          {/* Target line */}
          <div
            className="absolute left-0 right-0 border-b border-dashed border-stone-300 dark:border-stone-700 pointer-events-none z-10"
            style={{
              bottom: `${(goals.dailyCalories / maxCalorieValue) * 80 + 10}%`,
            }}
          >
            <span className="absolute right-2 -top-5 text-[10px] text-stone-400 dark:text-stone-400 bg-white dark:bg-stone-900 px-1 font-mono">
              Target: {goals.dailyCalories} kcal
            </span>
          </div>

          {dailyStats.map((d, index) => {
            const eatenHeight = Math.max(8, (d.totalEaten / maxCalorieValue) * 80);
            const burnedHeight = Math.max(4, (d.totalBurned / maxCalorieValue) * 80);

            return (
              <div
                key={d.date}
                className="flex-1 flex flex-col items-center h-full justify-end group relative cursor-pointer"
                onMouseEnter={() => setSelectedBar(index)}
                onMouseLeave={() => setSelectedBar(null)}
              >
                {/* Tooltip on Hover */}
                {selectedBar === index && (
                  <div className="absolute -top-16 bg-stone-900 dark:bg-stone-800 border border-stone-700 text-white text-[11px] py-1.5 px-3 rounded-xl shadow-xl z-20 whitespace-nowrap pointer-events-none">
                    <div className="font-bold text-stone-200">{d.date} ({d.dayName})</div>
                    <div className="text-amber-400">Eaten: {Math.round(d.totalEaten)} kcal</div>
                    <div className="text-orange-400">Burned: {Math.round(d.totalBurned)} kcal</div>
                  </div>
                )}

                {/* Bars Container */}
                <div className="w-full flex items-end justify-center gap-1 sm:gap-2 h-full">
                  {/* Intake Bar */}
                  <div
                    className={`w-3 sm:w-5 rounded-t-md transition-all duration-300 ${
                      d.isToday
                        ? 'bg-amber-500 ring-2 ring-amber-300 dark:ring-amber-600'
                        : 'bg-amber-400 dark:bg-amber-500 hover:bg-amber-500'
                    }`}
                    style={{ height: `${eatenHeight}%` }}
                  />

                  {/* Burned Bar */}
                  <div
                    className="w-2.5 sm:w-4 rounded-t-md bg-orange-500/80 hover:bg-orange-500 transition-all duration-300"
                    style={{ height: `${burnedHeight}%` }}
                  />
                </div>

                {/* Label */}
                <span
                  className={`mt-2 text-[11px] font-semibold tracking-tight ${
                    d.isToday ? 'text-emerald-700 dark:text-emerald-400 font-bold' : 'text-stone-500 dark:text-stone-400'
                  }`}
                >
                  {d.dayName}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Workout Frequency & Volume Breakdown */}
      <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/80 dark:border-stone-800 p-6 shadow-sm transition-colors">
        <h3 className="font-bold text-stone-900 dark:text-white text-base mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          {lang === 'ur' ? 'Rozana Workout Sets ka Record' : 'Workout Sets Completed This Week'}
        </h3>

        <div className="grid grid-cols-7 gap-2">
          {dailyStats.map((d) => (
            <div
              key={`sets-${d.date}`}
              className={`p-3 rounded-xl border text-center transition-all ${
                d.isToday
                  ? 'border-emerald-600 dark:border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/40'
                  : 'border-stone-100 dark:border-stone-800 bg-stone-50/60 dark:bg-stone-800/60'
              }`}
            >
              <span className="text-[11px] text-stone-500 dark:text-stone-400 font-medium block">
                {d.dayName}
              </span>
              <span className="text-lg font-bold text-stone-900 dark:text-white font-mono block mt-1">
                {d.completedSets}
              </span>
              <span className="text-[10px] text-stone-400">sets</span>
            </div>
          ))}
        </div>
      </div>

      {/* Google Sheets Weekly Data Export Card */}
      {onOpenGoogleSheetsModal && (
        <div className="bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-800/60 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="p-2.5 bg-emerald-600 text-white rounded-xl shadow-xs">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-stone-900 dark:text-white">
                {lang === 'ur' ? 'Hafta-war Data Google Sheets par Backup Karein' : 'Export Full Fitness Data to Google Sheets'}
              </h4>
              <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
                {lang === 'ur'
                  ? 'Apna mukammal record Google Sheets par save karein aur charts ya graphs ke zariye mazeed tajziya karein.'
                  : 'Backup all historical logs, calories, workouts, and macro distributions into your Google Drive spreadsheet.'}
              </p>
            </div>
          </div>

          <button
            id="analytics-export-sheets-btn"
            onClick={onOpenGoogleSheetsModal}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer shrink-0"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>
              {getStoredConnectedSpreadsheet()
                ? (lang === 'ur' ? 'Spreadsheet Sync Kholein' : 'Open Google Sheets Sync')
                : (lang === 'ur' ? 'Google Sheets Connect Karein' : 'Connect Google Sheets')}
            </span>
          </button>
        </div>
      )}
    </div>
  );
}
