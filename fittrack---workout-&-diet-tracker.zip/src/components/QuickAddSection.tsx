import React, { useState, useRef } from 'react';
import {
  Droplets,
  Zap,
  Egg,
  Apple,
  Coffee,
  Plus,
  Check,
  Undo2,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { DailyLog, UserGoals, Language, FoodItem } from '../types';
import { TRANSLATIONS } from '../utils/translations';

interface QuickAddSectionProps {
  log: DailyLog;
  goals: UserGoals;
  onUpdateLog: (updatedLog: DailyLog) => void;
  lang: Language;
}

interface QuickActionItem {
  id: string;
  type: 'water' | 'food';
  title: string;
  titleUrdu: string;
  badge: string;
  subtitle: string;
  subtitleUrdu: string;
  colorClass: {
    bg: string;
    text: string;
    border: string;
    badgeBg: string;
    badgeText: string;
  };
  icon: React.ElementType;
  waterAmountMl?: number;
  foodData?: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    servingSize: string;
    category: string;
  };
}

export default function QuickAddSection({
  log,
  goals,
  onUpdateLog,
  lang,
}: QuickAddSectionProps) {
  const t = TRANSLATIONS[lang];
  const [toast, setToast] = useState<{
    id: string;
    message: string;
    type: 'water' | 'food';
    addedItemName: string;
  } | null>(null);

  const [lastAction, setLastAction] = useState<{
    type: 'water' | 'food';
    foodId?: string;
    waterAmount?: number;
    name: string;
  } | null>(null);

  const [activeButtonId, setActiveButtonId] = useState<string | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  const triggerGoalConfetti = () => {
    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.65 },
      });
    } catch {
      // safe fallback
    }
  };

  const quickItems: QuickActionItem[] = [
    {
      id: 'quick-add-water-250',
      type: 'water',
      title: 'Glass of Water',
      titleUrdu: 'Paani ka Gilaas',
      badge: '+250 ml',
      subtitle: 'Hydration • 0 kcal',
      subtitleUrdu: 'Tazgi • 0 kcal',
      colorClass: {
        bg: 'bg-sky-50 dark:bg-sky-950/40 hover:bg-sky-100 dark:hover:bg-sky-950/70',
        text: 'text-sky-700 dark:text-sky-300',
        border: 'border-sky-200 dark:border-sky-800/60',
        badgeBg: 'bg-sky-100 dark:bg-sky-900/60',
        badgeText: 'text-sky-800 dark:text-sky-300',
      },
      icon: Droplets,
      waterAmountMl: 250,
    },
    {
      id: 'quick-add-protein-shake',
      type: 'food',
      title: 'Standard Protein Shake',
      titleUrdu: 'Whey Protein Shake',
      badge: '+25g Protein',
      subtitle: '130 kcal • 1 scoop in water',
      subtitleUrdu: '130 kcal • 1 scoop paani mein',
      colorClass: {
        bg: 'bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-950/70',
        text: 'text-emerald-700 dark:text-emerald-300',
        border: 'border-emerald-200 dark:border-emerald-800/60',
        badgeBg: 'bg-emerald-100 dark:bg-emerald-900/60',
        badgeText: 'text-emerald-800 dark:text-emerald-300',
      },
      icon: Zap,
      foodData: {
        calories: 130,
        protein: 25,
        carbs: 2,
        fat: 1.5,
        servingSize: '1 scoop (32g)',
        category: 'Beverages & Shakes',
      },
    },
    {
      id: 'quick-add-water-500',
      type: 'water',
      title: 'Water Bottle',
      titleUrdu: 'Paani ki Botal',
      badge: '+500 ml',
      subtitle: '2 Glasses • 0 kcal',
      subtitleUrdu: '2 Gilaas • 0 kcal',
      colorClass: {
        bg: 'bg-cyan-50 dark:bg-cyan-950/40 hover:bg-cyan-100 dark:hover:bg-cyan-950/70',
        text: 'text-cyan-700 dark:text-cyan-300',
        border: 'border-cyan-200 dark:border-cyan-800/60',
        badgeBg: 'bg-cyan-100 dark:bg-cyan-900/60',
        badgeText: 'text-cyan-800 dark:text-cyan-300',
      },
      icon: Droplets,
      waterAmountMl: 500,
    },
    {
      id: 'quick-add-boiled-eggs',
      type: 'food',
      title: '2 Boiled Eggs',
      titleUrdu: '2 Ublay Anday',
      badge: '+12g Protein',
      subtitle: '140 kcal • Clean snack',
      subtitleUrdu: '140 kcal • Protein nashta',
      colorClass: {
        bg: 'bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-950/70',
        text: 'text-amber-700 dark:text-amber-300',
        border: 'border-amber-200 dark:border-amber-800/60',
        badgeBg: 'bg-amber-100 dark:bg-amber-900/60',
        badgeText: 'text-amber-800 dark:text-amber-300',
      },
      icon: Egg,
      foodData: {
        calories: 140,
        protein: 12,
        carbs: 1,
        fat: 10,
        servingSize: '2 large eggs',
        category: 'Eggs & Dairy',
      },
    },
    {
      id: 'quick-add-banana',
      type: 'food',
      title: 'Fresh Banana',
      titleUrdu: 'Kela (Banana)',
      badge: '+27g Carbs',
      subtitle: '105 kcal • Workout fuel',
      subtitleUrdu: '105 kcal • Energy',
      colorClass: {
        bg: 'bg-yellow-50 dark:bg-yellow-950/40 hover:bg-yellow-100 dark:hover:bg-yellow-950/70',
        text: 'text-yellow-800 dark:text-yellow-300',
        border: 'border-yellow-200 dark:border-yellow-800/60',
        badgeBg: 'bg-yellow-100 dark:bg-yellow-900/60',
        badgeText: 'text-yellow-800 dark:text-yellow-300',
      },
      icon: Apple,
      foodData: {
        calories: 105,
        protein: 1.3,
        carbs: 27,
        fat: 0.3,
        servingSize: '1 medium (118g)',
        category: 'Fruits',
      },
    },
    {
      id: 'quick-add-black-coffee',
      type: 'food',
      title: 'Black Coffee',
      titleUrdu: 'Black Coffee',
      badge: 'Focus & Energy',
      subtitle: '5 kcal • Zero Sugar',
      subtitleUrdu: '5 kcal • Pre-Workout',
      colorClass: {
        bg: 'bg-stone-100 dark:bg-stone-800/70 hover:bg-stone-200/80 dark:hover:bg-stone-800',
        text: 'text-stone-800 dark:text-stone-200',
        border: 'border-stone-200 dark:border-stone-700',
        badgeBg: 'bg-stone-200 dark:bg-stone-700',
        badgeText: 'text-stone-800 dark:text-stone-200',
      },
      icon: Coffee,
      foodData: {
        calories: 5,
        protein: 0.3,
        carbs: 0,
        fat: 0,
        servingSize: '1 mug (240ml)',
        category: 'Beverages & Shakes',
      },
    },
  ];

  const handleQuickAdd = (item: QuickActionItem) => {
    setActiveButtonId(item.id);
    setTimeout(() => setActiveButtonId(null), 300);

    const displayName = lang === 'ur' ? item.titleUrdu : item.title;

    if (item.type === 'water' && item.waterAmountMl) {
      const prevWater = log.waterIntakeMl || 0;
      const newWater = prevWater + item.waterAmountMl;

      onUpdateLog({
        ...log,
        waterIntakeMl: newWater,
      });

      setLastAction({
        type: 'water',
        waterAmount: item.waterAmountMl,
        name: displayName,
      });

      setToast({
        id: String(Date.now()),
        message:
          lang === 'ur'
            ? `+${item.waterAmountMl}ml Paani shamil kiya gaya (${Math.round(newWater / 250)} gilaas kul)`
            : `Added ${item.waterAmountMl}ml water (${Math.round(newWater / 250)} glasses total)`,
        type: 'water',
        addedItemName: displayName,
      });

      if (newWater >= goals.dailyWaterMl && prevWater < goals.dailyWaterMl) {
        triggerGoalConfetti();
      }
    } else if (item.type === 'food' && item.foodData) {
      const newFoodId = `quick-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const newFood: FoodItem = {
        id: newFoodId,
        name: item.title,
        nameUrdu: item.titleUrdu,
        calories: item.foodData.calories,
        protein: item.foodData.protein,
        carbs: item.foodData.carbs,
        fat: item.foodData.fat,
        servingSize: item.foodData.servingSize,
        quantity: 1,
        category: item.foodData.category,
      };

      const updatedSnacks = [newFood, ...log.meals.snack];
      const updatedLog: DailyLog = {
        ...log,
        meals: {
          ...log.meals,
          snack: updatedSnacks,
        },
      };

      onUpdateLog(updatedLog);

      setLastAction({
        type: 'food',
        foodId: newFoodId,
        name: displayName,
      });

      setToast({
        id: String(Date.now()),
        message:
          lang === 'ur'
            ? `"${displayName}" Snacks mein shamil (+${item.foodData.protein}g protein, ${item.foodData.calories} kcal)`
            : `Added "${displayName}" to Snacks (+${item.foodData.protein}g protein, ${item.foodData.calories} kcal)`,
        type: 'food',
        addedItemName: displayName,
      });

      // Check if this push crossed the protein goal
      const allMeals = [
        ...updatedLog.meals.breakfast,
        ...updatedLog.meals.lunch,
        ...updatedLog.meals.dinner,
        ...updatedLog.meals.snack,
      ];
      const totalProtein = allMeals.reduce((acc, f) => acc + (f.protein || 0), 0);
      const prevProtein = totalProtein - item.foodData.protein;
      if (totalProtein >= goals.dailyProteinG && prevProtein < goals.dailyProteinG) {
        triggerGoalConfetti();
      }
    }

    if (toastTimerRef.current) {
      clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  const handleUndo = () => {
    if (!lastAction) return;

    if (lastAction.type === 'water' && lastAction.waterAmount) {
      const currentWater = log.waterIntakeMl || 0;
      const revertedWater = Math.max(0, currentWater - lastAction.waterAmount);
      onUpdateLog({
        ...log,
        waterIntakeMl: revertedWater,
      });
    } else if (lastAction.type === 'food' && lastAction.foodId) {
      const updatedSnacks = log.meals.snack.filter((i) => i.id !== lastAction.foodId);
      onUpdateLog({
        ...log,
        meals: {
          ...log.meals,
          snack: updatedSnacks,
        },
      });
    }

    setToast({
      id: String(Date.now()),
      message:
        lang === 'ur'
          ? `"${lastAction.name}" wapis hata diya gaya.`
          : `Removed "${lastAction.name}".`,
      type: lastAction.type,
      addedItemName: lastAction.name,
    });
    setLastAction(null);

    if (toastTimerRef.current) {
      clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(() => {
      setToast(null);
    }, 2500);
  };

  return (
    <div
      id="quick-add-essentials-section"
      className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/80 dark:border-stone-800 p-5 shadow-sm transition-colors"
    >
      {/* Header & Subtitle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-400 rounded-xl">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-stone-900 dark:text-white text-base">
              {t.quickAddTitle || 'Quick Add Essentials'}
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              {t.quickAddSubtitle || '1-click logging for daily drinks, snacks & hydration'}
            </p>
          </div>
        </div>

        {/* Live Feedback Toast Banner with Undo */}
        <AnimatePresence>
          {toast && (
            <motion.div
              initial={{ opacity: 0, y: -6, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.96 }}
              transition={{ duration: 0.18 }}
              className="flex items-center gap-2 bg-emerald-50 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 px-3 py-1.5 rounded-xl text-xs shadow-xs font-medium"
            >
              <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span className="truncate max-w-[200px] sm:max-w-xs">{toast.message}</span>
              {lastAction && (
                <button
                  id="quick-add-undo-button"
                  onClick={handleUndo}
                  className="ml-1 text-emerald-900 dark:text-emerald-200 hover:text-emerald-950 dark:hover:text-white underline font-bold flex items-center gap-0.5 cursor-pointer"
                >
                  <Undo2 className="w-3 h-3" />
                  {t.undo || 'Undo'}
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Grid of Quick Action Buttons */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {quickItems.map((item) => {
          const Icon = item.icon;
          const isPressed = activeButtonId === item.id;
          const displayTitle = lang === 'ur' ? item.titleUrdu : item.title;
          const displaySubtitle = lang === 'ur' ? item.subtitleUrdu : item.subtitle;

          return (
            <motion.button
              key={item.id}
              id={item.id}
              onClick={() => handleQuickAdd(item)}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.95 }}
              transition={{ duration: 0.12 }}
              className={`group flex flex-col justify-between text-left p-3.5 rounded-xl border transition-all cursor-pointer ${item.colorClass.bg} ${item.colorClass.border} shadow-2xs hover:shadow-sm`}
            >
              {/* Icon & Badge Row */}
              <div className="flex items-center justify-between w-full mb-2.5">
                <div className={`p-1.5 rounded-lg ${item.colorClass.badgeBg} ${item.colorClass.text}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-md font-mono ${item.colorClass.badgeBg} ${item.colorClass.badgeText}`}
                >
                  {item.badge}
                </span>
              </div>

              {/* Title & Subtitle */}
              <div className="space-y-0.5 w-full">
                <div className="font-bold text-xs text-stone-900 dark:text-white line-clamp-1 group-hover:text-emerald-700 dark:group-hover:text-emerald-400 transition-colors">
                  {displayTitle}
                </div>
                <div className="text-[10px] text-stone-500 dark:text-stone-400 line-clamp-1">
                  {displaySubtitle}
                </div>
              </div>

              {/* 1-Click Action Indicator */}
              <div className="mt-3 pt-2 border-t border-stone-200/60 dark:border-stone-700/60 flex items-center justify-between text-[11px] font-semibold text-stone-600 dark:text-stone-300 group-hover:text-stone-900 dark:group-hover:text-white">
                <span className="text-[10px] uppercase tracking-wider font-semibold text-stone-400 dark:text-stone-400">
                  {lang === 'ur' ? 'Fori' : '1-Click'}
                </span>
                <span className={`inline-flex items-center gap-0.5 text-xs font-bold transition-transform ${isPressed ? 'scale-125 text-emerald-600' : 'group-hover:translate-x-0.5'}`}>
                  <Plus className="w-3.5 h-3.5" />
                </span>
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
