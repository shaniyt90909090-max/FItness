import React, { useState } from 'react';
import { Plus, Trash2, Search, Utensils, Flame, Sparkles, X, Check } from 'lucide-react';
import { DailyLog, FoodItem, MealType, Language, FoodPreset } from '../types';
import { FOOD_PRESETS } from '../data/predefinedData';
import { TRANSLATIONS } from '../utils/translations';

interface DietTrackerProps {
  log: DailyLog;
  onUpdateLog: (updatedLog: DailyLog) => void;
  lang: Language;
}

export default function DietTracker({ log, onUpdateLog, lang }: DietTrackerProps) {
  const t = TRANSLATIONS[lang];
  const [activeMealType, setActiveMealType] = useState<MealType | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [portionMultiplier, setPortionMultiplier] = useState<number>(1);

  // Custom food form state
  const [isCustomMode, setIsCustomMode] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customCalories, setCustomCalories] = useState<number>(150);
  const [customProtein, setCustomProtein] = useState<number>(10);
  const [customCarbs, setCustomCarbs] = useState<number>(15);
  const [customFat, setCustomFat] = useState<number>(5);
  const [customServing, setCustomServing] = useState('1 serving');

  // Compute total calories & macros for the entire day
  const mealsList: MealType[] = ['breakfast', 'lunch', 'dinner', 'snack'];

  const getMealItems = (meal: MealType): FoodItem[] => log.meals[meal] || [];

  const getMealTotals = (meal: MealType) => {
    const items = getMealItems(meal);
    return items.reduce(
      (acc, item) => ({
        calories: acc.calories + (item.calories || 0),
        protein: acc.protein + (item.protein || 0),
        carbs: acc.carbs + (item.carbs || 0),
        fat: acc.fat + (item.fat || 0),
      }),
      { calories: 0, protein: 0, carbs: 0, fat: 0 }
    );
  };

  const dayTotals = mealsList.reduce(
    (acc, meal) => {
      const m = getMealTotals(meal);
      return {
        calories: acc.calories + m.calories,
        protein: acc.protein + m.protein,
        carbs: acc.carbs + m.carbs,
        fat: acc.fat + m.fat,
      };
    },
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  const handleDeleteItem = (meal: MealType, itemId: string) => {
    const updatedMeals = {
      ...log.meals,
      [meal]: log.meals[meal].filter((item) => item.id !== itemId),
    };
    onUpdateLog({ ...log, meals: updatedMeals });
  };

  const handleAddPresetFood = (preset: FoodPreset) => {
    if (!activeMealType) return;
    const newItem: FoodItem = {
      id: `food_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: preset.name,
      nameUrdu: preset.nameUrdu,
      calories: Math.round(preset.calories * portionMultiplier),
      protein: Number((preset.protein * portionMultiplier).toFixed(1)),
      carbs: Number((preset.carbs * portionMultiplier).toFixed(1)),
      fat: Number((preset.fat * portionMultiplier).toFixed(1)),
      servingSize: portionMultiplier === 1 ? preset.servingSize : `${portionMultiplier}x ${preset.servingSize}`,
      quantity: portionMultiplier,
      category: preset.category,
    };

    const updatedMeals = {
      ...log.meals,
      [activeMealType]: [...(log.meals[activeMealType] || []), newItem],
    };

    onUpdateLog({ ...log, meals: updatedMeals });
    setActiveMealType(null);
    setSearchQuery('');
    setPortionMultiplier(1);
  };

  const handleAddCustomFood = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeMealType || !customName.trim()) return;

    const newItem: FoodItem = {
      id: `custom_food_${Date.now()}`,
      name: customName.trim(),
      calories: Number(customCalories) || 0,
      protein: Number(customProtein) || 0,
      carbs: Number(customCarbs) || 0,
      fat: Number(customFat) || 0,
      servingSize: customServing || '1 serving',
      quantity: 1,
      category: 'custom',
    };

    const updatedMeals = {
      ...log.meals,
      [activeMealType]: [...(log.meals[activeMealType] || []), newItem],
    };

    onUpdateLog({ ...log, meals: updatedMeals });
    setActiveMealType(null);
    setIsCustomMode(false);
    setCustomName('');
    setCustomCalories(150);
    setCustomProtein(10);
    setCustomCarbs(15);
    setCustomFat(5);
  };

  const filteredPresets = FOOD_PRESETS.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.nameUrdu && item.nameUrdu.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const mealLabels: Record<MealType, string> = {
    breakfast: t.breakfast,
    lunch: t.lunch,
    dinner: t.dinner,
    snack: t.snack,
  };

  return (
    <div id="diet-tracker-section" className="space-y-6">
      {/* Daily Diet Macro Highlights */}
      <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/80 dark:border-stone-800 p-5 shadow-sm transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-100 dark:border-stone-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 rounded-xl">
              <Utensils className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-stone-900 dark:text-white">
                {lang === 'ur' ? 'Khurak aur Calories Tracker' : 'Daily Diet & Nutrition'}
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {lang === 'ur' ? 'Har waqt ka khana aur macros log karein' : 'Track individual meals, protein, carbs, and fats'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-stone-50 dark:bg-stone-800/80 px-4 py-2 rounded-xl border border-stone-100 dark:border-stone-700">
            <div>
              <div className="text-[11px] font-semibold text-stone-400 uppercase">
                {lang === 'ur' ? 'Kul Calories' : 'Total Calories'}
              </div>
              <div className="text-xl font-bold text-amber-600 dark:text-amber-400 font-mono">
                {Math.round(dayTotals.calories)}{' '}
                <span className="text-xs font-medium text-stone-500 dark:text-stone-400">kcal</span>
              </div>
            </div>
          </div>
        </div>

        {/* 3 Macro Cards */}
        <div className="grid grid-cols-3 gap-3 pt-4">
          <div className="bg-red-50/60 dark:bg-red-950/30 p-3 rounded-xl border border-red-100 dark:border-red-900/50 text-center">
            <span className="text-xs font-semibold text-red-700 dark:text-red-400 block">
              {lang === 'ur' ? 'Protein' : 'Protein'}
            </span>
            <span className="text-lg font-bold text-red-900 dark:text-red-200 font-mono">
              {dayTotals.protein.toFixed(1)}g
            </span>
          </div>

          <div className="bg-blue-50/60 dark:bg-blue-950/30 p-3 rounded-xl border border-blue-100 dark:border-blue-900/50 text-center">
            <span className="text-xs font-semibold text-blue-700 dark:text-blue-400 block">
              {lang === 'ur' ? 'Carbs' : 'Carbs'}
            </span>
            <span className="text-lg font-bold text-blue-900 dark:text-blue-200 font-mono">
              {dayTotals.carbs.toFixed(1)}g
            </span>
          </div>

          <div className="bg-amber-50/60 dark:bg-amber-950/30 p-3 rounded-xl border border-amber-100 dark:border-amber-900/50 text-center">
            <span className="text-xs font-semibold text-amber-700 dark:text-amber-400 block">
              {lang === 'ur' ? 'Fat' : 'Fat'}
            </span>
            <span className="text-lg font-bold text-amber-900 dark:text-amber-200 font-mono">
              {dayTotals.fat.toFixed(1)}g
            </span>
          </div>
        </div>
      </div>

      {/* Meals List (Breakfast, Lunch, Dinner, Snack) */}
      <div className="space-y-4">
        {mealsList.map((mealKey) => {
          const items = getMealItems(mealKey);
          const totals = getMealTotals(mealKey);

          return (
            <div
              key={mealKey}
              id={`meal-card-${mealKey}`}
              className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/80 dark:border-stone-800 overflow-hidden shadow-sm hover:border-stone-300 dark:hover:border-stone-700 transition-all"
            >
              {/* Meal Header */}
              <div className="flex items-center justify-between px-5 py-4 bg-stone-50/60 dark:bg-stone-800/60 border-b border-stone-100 dark:border-stone-800">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-stone-900 dark:text-white text-base">
                    {mealLabels[mealKey]}
                  </h3>
                  <span className="text-xs text-stone-400 dark:text-stone-500">({items.length} {items.length === 1 ? 'item' : 'items'})</span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-sm font-bold text-stone-800 dark:text-stone-200 font-mono">
                      {Math.round(totals.calories)} kcal
                    </span>
                    <span className="hidden sm:inline-block text-xs text-stone-400 dark:text-stone-500 ml-2">
                      (P: {totals.protein.toFixed(0)}g | C: {totals.carbs.toFixed(0)}g | F: {totals.fat.toFixed(0)}g)
                    </span>
                  </div>

                  <button
                    id={`add-food-btn-${mealKey}`}
                    onClick={() => {
                      setActiveMealType(mealKey);
                      setIsCustomMode(false);
                      setPortionMultiplier(1);
                      setSearchQuery('');
                    }}
                    className="flex items-center gap-1.5 py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 dark:bg-emerald-500 dark:hover:bg-emerald-400 text-white dark:text-stone-950 rounded-xl text-xs font-semibold shadow-sm transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{lang === 'ur' ? 'Food Add' : 'Add Food'}</span>
                  </button>
                </div>
              </div>

              {/* Meal Items */}
              {items.length === 0 ? (
                <div className="p-6 text-center text-stone-400 dark:text-stone-500 text-xs italic">
                  {t.noFoodsInMeal}
                </div>
              ) : (
                <div className="divide-y divide-stone-100 dark:divide-stone-800">
                  {items.map((item) => (
                    <div
                      key={item.id}
                      className="px-5 py-3.5 flex items-center justify-between hover:bg-stone-50/50 dark:hover:bg-stone-800/40 transition-colors group"
                    >
                      <div className="flex-1 pr-3">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-stone-800 dark:text-stone-200 text-sm">
                            {lang === 'ur' && item.nameUrdu ? item.nameUrdu : item.name}
                          </span>
                          <span className="text-xs text-stone-400 dark:text-stone-400 bg-stone-100 dark:bg-stone-800 px-2 py-0.5 rounded-md">
                            {item.servingSize}
                          </span>
                        </div>
                        <div className="flex items-center gap-2.5 mt-1 text-xs text-stone-500 dark:text-stone-400">
                          <span className="font-medium text-amber-700 dark:text-amber-400">
                            {item.calories} kcal
                          </span>
                          <span>•</span>
                          <span className="text-red-700 dark:text-red-400">P: {item.protein}g</span>
                          <span>•</span>
                          <span className="text-blue-700 dark:text-blue-400">C: {item.carbs}g</span>
                          <span>•</span>
                          <span className="text-amber-600 dark:text-amber-400">F: {item.fat}g</span>
                        </div>
                      </div>

                      <button
                        id={`delete-food-${item.id}`}
                        onClick={() => handleDeleteItem(mealKey, item.id)}
                        className="opacity-60 group-hover:opacity-100 text-stone-400 dark:text-stone-500 hover:text-red-600 dark:hover:text-red-400 p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                        title={t.delete}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Add Food Modal */}
      {activeMealType && (
        <div
          id="add-food-modal-overlay"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm"
          onClick={() => setActiveMealType(null)}
        >
          <div
            id="add-food-modal-container"
            className="w-full max-w-xl bg-white dark:bg-stone-900 rounded-2xl shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col max-h-[88vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-stone-100 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/60">
              <div>
                <h3 className="font-bold text-stone-900 dark:text-white text-base">
                  {lang === 'ur' ? 'Khana Shamil Karein:' : 'Add Food to:'}{' '}
                  <span className="text-emerald-600 dark:text-emerald-400 font-extrabold capitalize">
                    {mealLabels[activeMealType]}
                  </span>
                </h3>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  {lang === 'ur' ? 'List se chunein ya apna khana likhein' : 'Select from food presets or enter custom item'}
                </p>
              </div>
              <button
                id="close-add-food-modal"
                onClick={() => setActiveMealType(null)}
                className="p-1.5 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mode Switcher: Predefined Library vs Custom */}
            <div className="flex border-b border-stone-200 dark:border-stone-800 px-6 pt-3 gap-4">
              <button
                type="button"
                id="tab-food-presets"
                onClick={() => setIsCustomMode(false)}
                className={`pb-3 text-sm font-semibold border-b-2 transition-all ${
                  !isCustomMode
                    ? 'border-emerald-600 dark:border-emerald-400 text-emerald-700 dark:text-emerald-400'
                    : 'border-transparent text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200'
                }`}
              >
                {lang === 'ur' ? 'Khurak Library (Presets)' : 'Food Library'}
              </button>

              <button
                type="button"
                id="tab-custom-food"
                onClick={() => setIsCustomMode(true)}
                className={`pb-3 text-sm font-semibold border-b-2 transition-all ${
                  isCustomMode
                    ? 'border-emerald-600 dark:border-emerald-400 text-emerald-700 dark:text-emerald-400'
                    : 'border-transparent text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200'
                }`}
              >
                {lang === 'ur' ? 'Apna Khana Likhein (Custom)' : 'Custom Food'}
              </button>
            </div>

            {!isCustomMode ? (
              <div className="p-6 flex-1 overflow-y-auto space-y-4">
                {/* Search Bar */}
                <div className="relative">
                  <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
                  <input
                    id="search-food-input"
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={t.searchFood}
                    className="w-full pl-10 pr-4 py-2.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-sm text-stone-900 dark:text-white placeholder-stone-400 dark:placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {/* Categories filter pills */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                  {[
                    { id: 'all', label: lang === 'ur' ? 'Sab' : 'All' },
                    { id: 'desi_staple', label: lang === 'ur' ? 'Desi/Ghar ka Khana' : 'Desi Staples' },
                    { id: 'protein', label: lang === 'ur' ? 'High Protein' : 'Protein' },
                    { id: 'carbs', label: lang === 'ur' ? 'Carbs & Grain' : 'Carbs' },
                    { id: 'dairy_nuts', label: lang === 'ur' ? 'Doodh & Badam' : 'Dairy & Nuts' },
                    { id: 'fruits_veggies', label: lang === 'ur' ? 'Phal & Salad' : 'Fruits & Salad' },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-colors ${
                        selectedCategory === cat.id
                          ? 'bg-emerald-600 dark:bg-emerald-500 text-white dark:text-stone-950 shadow-xs font-bold'
                          : 'bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                {/* Portion Multiplier Selector */}
                <div className="flex items-center justify-between bg-stone-50 dark:bg-stone-800 p-2.5 rounded-xl border border-stone-200/80 dark:border-stone-700 text-xs">
                  <span className="font-semibold text-stone-700 dark:text-stone-300">
                    {lang === 'ur' ? 'Miqdar (Portion):' : 'Portion / Quantity:'}
                  </span>
                  <div className="flex items-center gap-1">
                    {[0.5, 1, 1.5, 2, 3].map((mul) => (
                      <button
                        key={mul}
                        type="button"
                        onClick={() => setPortionMultiplier(mul)}
                        className={`px-2.5 py-1 rounded-md font-bold transition-colors ${
                          portionMultiplier === mul
                            ? 'bg-emerald-600 dark:bg-emerald-500 text-white dark:text-stone-950'
                            : 'bg-white dark:bg-stone-700 text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-stone-600 hover:bg-stone-100 dark:hover:bg-stone-600'
                        }`}
                      >
                        {mul}x
                      </button>
                    ))}
                  </div>
                </div>

                {/* Presets List */}
                <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                  {filteredPresets.map((preset, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-stone-50/70 dark:bg-stone-800/70 hover:bg-emerald-50/50 dark:hover:bg-emerald-950/30 border border-stone-200/70 dark:border-stone-700 hover:border-emerald-300 dark:hover:border-emerald-700 rounded-xl flex items-center justify-between transition-all"
                    >
                      <div>
                        <div className="font-semibold text-sm text-stone-900 dark:text-white">
                          {preset.name}
                        </div>
                        {lang === 'ur' && preset.nameUrdu && (
                          <div className="text-xs text-stone-500 dark:text-stone-400">
                            {preset.nameUrdu}
                          </div>
                        )}
                        <div className="flex items-center gap-2 mt-1 text-xs text-stone-500 dark:text-stone-400">
                          <span className="font-semibold text-amber-700 dark:text-amber-400">
                            {Math.round(preset.calories * portionMultiplier)} kcal
                          </span>
                          <span>•</span>
                          <span className="text-red-700 dark:text-red-400">
                            {(preset.protein * portionMultiplier).toFixed(1)}g P
                          </span>
                          <span>•</span>
                          <span className="text-blue-700 dark:text-blue-400">
                            {(preset.carbs * portionMultiplier).toFixed(1)}g C
                          </span>
                          <span>•</span>
                          <span className="text-amber-600 dark:text-amber-400">
                            {(preset.fat * portionMultiplier).toFixed(1)}g F
                          </span>
                          <span className="text-stone-400 dark:text-stone-500">
                            ({preset.servingSize})
                          </span>
                        </div>
                      </div>

                      <button
                        type="button"
                        id={`select-food-preset-${idx}`}
                        onClick={() => handleAddPresetFood(preset)}
                        className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 dark:bg-emerald-500 dark:hover:bg-emerald-400 text-white dark:text-stone-950 text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        {lang === 'ur' ? 'Shamil' : 'Add'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              /* Custom Food Form */
              <form onSubmit={handleAddCustomFood} className="p-6 space-y-4 overflow-y-auto flex-1">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    {lang === 'ur' ? 'Khane ka Naam' : 'Food Name *'}
                  </label>
                  <input
                    id="custom-food-name-input"
                    type="text"
                    required
                    placeholder={lang === 'ur' ? 'e.g. Masala Chai, Daal Chawal, Protein Bar' : 'e.g. Greek Yogurt Bowl, Omelette'}
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white placeholder-stone-400 dark:placeholder-stone-500 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                      {lang === 'ur' ? 'Serving Size' : 'Serving Size'}
                    </label>
                    <input
                      id="custom-food-serving-input"
                      type="text"
                      placeholder="e.g. 1 plate, 150g, 1 cup"
                      value={customServing}
                      onChange={(e) => setCustomServing(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white placeholder-stone-400 dark:placeholder-stone-500 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                      {lang === 'ur' ? 'Calories (kcal)' : 'Calories (kcal) *'}
                    </label>
                    <input
                      id="custom-food-calories-input"
                      type="number"
                      required
                      min="0"
                      value={customCalories}
                      onChange={(e) => setCustomCalories(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-red-700 dark:text-red-400 mb-1">
                      Protein (g)
                    </label>
                    <input
                      id="custom-food-protein-input"
                      type="number"
                      min="0"
                      step="0.1"
                      value={customProtein}
                      onChange={(e) => setCustomProtein(Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white rounded-lg text-sm font-semibold focus:ring-2 focus:ring-red-400"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-blue-700 dark:text-blue-400 mb-1">
                      Carbs (g)
                    </label>
                    <input
                      id="custom-food-carbs-input"
                      type="number"
                      min="0"
                      step="0.1"
                      value={customCarbs}
                      onChange={(e) => setCustomCarbs(Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white rounded-lg text-sm font-semibold focus:ring-2 focus:ring-blue-400"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-amber-700 dark:text-amber-400 mb-1">
                      Fat (g)
                    </label>
                    <input
                      id="custom-food-fat-input"
                      type="number"
                      min="0"
                      step="0.1"
                      value={customFat}
                      onChange={(e) => setCustomFat(Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-white rounded-lg text-sm font-semibold focus:ring-2 focus:ring-amber-400"
                    />
                  </div>
                </div>

                <div className="pt-4 flex items-center justify-end gap-2 border-t border-stone-100 dark:border-stone-800">
                  <button
                    type="button"
                    onClick={() => setIsCustomMode(false)}
                    className="px-4 py-2 text-xs font-semibold text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl"
                  >
                    {t.cancel}
                  </button>
                  <button
                    id="submit-custom-food-btn"
                    type="submit"
                    className="px-5 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 dark:bg-emerald-500 dark:hover:bg-emerald-400 text-white dark:text-stone-950 font-bold rounded-xl shadow-sm flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    {lang === 'ur' ? 'Khana Mehfooz Karein' : 'Add Food'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
