import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  ExternalLink,
  Plus,
  RefreshCw,
  Check,
  AlertCircle,
  X,
  Database,
  Calendar,
  LogOut,
  FolderOpen,
  Send,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DailyLog, UserGoals, Language, ConnectedSpreadsheet, SheetFileSummary } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import {
  googleSignIn,
  logout,
  getAccessToken,
  initAuth
} from '../services/firebaseAuth';
import {
  getStoredConnectedSpreadsheet,
  saveConnectedSpreadsheet,
  fetchUserSpreadsheets,
  createFitnessTrackerSpreadsheet,
  appendDailyLogToSheet,
  syncAllHistoryToSheet,
  verifySpreadsheetTabs
} from '../services/googleSheetsService';
import { getAllStoredDailyLogs } from '../utils/storage';

interface GoogleSheetsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLog: DailyLog;
  goals: UserGoals;
  lang: Language;
}

export default function GoogleSheetsModal({
  isOpen,
  onClose,
  currentLog,
  goals,
  lang,
}: GoogleSheetsModalProps) {
  const t = TRANSLATIONS[lang];

  // Auth & Token States
  const [currentUser, setCurrentUser] = useState<any | null>(null);
  const [accessToken, setAccessTokenState] = useState<string | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Spreadsheet State
  const [connectedSheet, setConnectedSheet] = useState<ConnectedSpreadsheet | null>(() =>
    getStoredConnectedSpreadsheet()
  );
  const [driveSheets, setDriveSheets] = useState<SheetFileSummary[]>([]);
  const [isLoadingDriveSheets, setIsLoadingDriveSheets] = useState(false);
  const [showDriveList, setShowDriveList] = useState(false);
  const [customSheetUrl, setCustomSheetUrl] = useState('');

  // Syncing & Action states
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
    link?: string;
  } | null>(null);

  // Explicit User Confirmation Dialog state for mutating/exporting operations
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    itemCountDescription?: string;
    actionType: 'export_today' | 'export_all';
  } | null>(null);

  // Listen to Firebase Auth state on mount
  useEffect(() => {
    const unsubscribe = initAuth(
      async (user, token) => {
        setCurrentUser(user);
        if (token) {
          setAccessTokenState(token);
        } else {
          // Attempt to retrieve cached token
          const cached = await getAccessToken();
          if (cached) setAccessTokenState(cached);
        }
      },
      () => {
        setCurrentUser(null);
        setAccessTokenState(null);
      }
    );

    return () => {
      unsubscribe();
    };
  }, []);

  // Sync local storage on spreadsheet state change
  useEffect(() => {
    const stored = getStoredConnectedSpreadsheet();
    setConnectedSheet(stored);
  }, [isOpen]);

  if (!isOpen) return null;

  // Handle Google Sign-In with popup
  const handleSignIn = async () => {
    setIsAuthLoading(true);
    setAuthError(null);
    setStatusMessage(null);
    try {
      const result = await googleSignIn();
      setCurrentUser(result.user);
      setAccessTokenState(result.accessToken);
      setStatusMessage({
        type: 'success',
        text: lang === 'ur' ? 'Google account kamyabi se connect ho gaya!' : 'Google account connected successfully!',
      });
    } catch (err: any) {
      console.error('Sign-in error:', err);
      setAuthError(err.message || 'Failed to sign in with Google');
    } finally {
      setIsAuthLoading(false);
    }
  };

  // Handle Sign Out
  const handleSignOut = async () => {
    try {
      await logout();
      setCurrentUser(null);
      setAccessTokenState(null);
      setStatusMessage({
        type: 'info',
        text: lang === 'ur' ? 'Aap sign out ho chuke hain.' : 'You have signed out.',
      });
    } catch (err: any) {
      console.error('Sign out error:', err);
    }
  };

  // Helper to ensure valid access token exists or prompt user
  const ensureToken = async (): Promise<string> => {
    let token = accessToken || (await getAccessToken());
    if (!token) {
      const result = await googleSignIn();
      setCurrentUser(result.user);
      setAccessTokenState(result.accessToken);
      token = result.accessToken;
    }
    return token;
  };

  // 1. Create a new formatted FitTrack Spreadsheet
  const handleCreateNewSheet = async () => {
    setActionLoading('create');
    setStatusMessage(null);
    setAuthError(null);
    try {
      const token = await ensureToken();
      const newSheet = await createFitnessTrackerSpreadsheet(token);
      setConnectedSheet(newSheet);
      setStatusMessage({
        type: 'success',
        text: lang === 'ur' ? 'Nayi Google Sheet kamyabi se create aur connect ho gayi!' : 'Created new FitTrack Google Sheet with formatted tabs!',
        link: newSheet.url,
      });
    } catch (err: any) {
      console.error('Create sheet error:', err);
      setStatusMessage({
        type: 'error',
        text: err.message || 'Failed to create spreadsheet',
      });
    } finally {
      setActionLoading(null);
    }
  };

  // 2. Fetch spreadsheets from Google Drive
  const handleLoadDriveSheets = async () => {
    setIsLoadingDriveSheets(true);
    setStatusMessage(null);
    try {
      const token = await ensureToken();
      const files = await fetchUserSpreadsheets(token);
      setDriveSheets(files);
      setShowDriveList(true);
    } catch (err: any) {
      console.error('Load drive files error:', err);
      setStatusMessage({
        type: 'error',
        text: err.message || 'Failed to fetch spreadsheets from Google Drive',
      });
    } finally {
      setIsLoadingDriveSheets(false);
    }
  };

  // 3. Connect selected Drive spreadsheet
  const handleSelectDriveSheet = async (file: SheetFileSummary) => {
    setActionLoading(`select-${file.id}`);
    setStatusMessage(null);
    try {
      const token = await ensureToken();
      // Verify tabs
      const { title } = await verifySpreadsheetTabs(token, file.id);
      const connected: ConnectedSpreadsheet = {
        id: file.id,
        name: title || file.name,
        url: file.webViewLink || `https://docs.google.com/spreadsheets/d/${file.id}/edit`,
        webViewLink: file.webViewLink || `https://docs.google.com/spreadsheets/d/${file.id}/edit`,
        lastSynced: new Date().toISOString(),
      };
      saveConnectedSpreadsheet(connected);
      setConnectedSheet(connected);
      setShowDriveList(false);
      setStatusMessage({
        type: 'success',
        text: lang === 'ur' ? `Spreadsheet "${connected.name}" connect ho gayi!` : `Connected "${connected.name}" successfully!`,
        link: connected.url,
      });
    } catch (err: any) {
      console.error('Select sheet error:', err);
      setStatusMessage({
        type: 'error',
        text: err.message || 'Could not connect to this spreadsheet. Ensure you have edit access.',
      });
    } finally {
      setActionLoading(null);
    }
  };

  // 4. Connect via pasted Sheet URL or ID
  const handleConnectByUrl = async () => {
    if (!customSheetUrl.trim()) return;
    setActionLoading('custom-connect');
    setStatusMessage(null);
    try {
      // Extract spreadsheet ID from standard URL
      // https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}/edit...
      const match = customSheetUrl.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
      const sheetId = match ? match[1] : customSheetUrl.trim();

      const token = await ensureToken();
      const { title } = await verifySpreadsheetTabs(token, sheetId);
      const connected: ConnectedSpreadsheet = {
        id: sheetId,
        name: title,
        url: `https://docs.google.com/spreadsheets/d/${sheetId}/edit`,
        webViewLink: `https://docs.google.com/spreadsheets/d/${sheetId}/edit`,
        lastSynced: new Date().toISOString(),
      };
      saveConnectedSpreadsheet(connected);
      setConnectedSheet(connected);
      setCustomSheetUrl('');
      setStatusMessage({
        type: 'success',
        text: lang === 'ur' ? `Spreadsheet "${title}" connect ho gayi!` : `Connected "${title}"!`,
        link: connected.url,
      });
    } catch (err: any) {
      console.error('Connect URL error:', err);
      setStatusMessage({
        type: 'error',
        text: err.message || 'Could not verify spreadsheet. Check the URL or permissions.',
      });
    } finally {
      setActionLoading(null);
    }
  };

  // 5. Open Explicit User Confirmation before Mutating/Exporting Data
  const triggerExportTodayConfirmation = () => {
    if (!connectedSheet) return;
    const totalMeals =
      currentLog.meals.breakfast.length +
      currentLog.meals.lunch.length +
      currentLog.meals.dinner.length +
      currentLog.meals.snack.length;
    const totalWorkouts = currentLog.workouts.length;

    setConfirmDialog({
      isOpen: true,
      actionType: 'export_today',
      title: lang === 'ur' ? 'Aaj ka Data Google Sheets par Export Karein?' : "Export Today's Log to Google Sheets?",
      description:
        lang === 'ur'
          ? `Yeh aapki connected spreadsheet "${connectedSheet.name}" mein aaj (${currentLog.date}) ka record append karega.`
          : `This will append today's (${currentLog.date}) fitness log directly to "${connectedSheet.name}".`,
      itemCountDescription:
        lang === 'ur'
          ? `1 Daily Summary row • ${totalMeals} Meal rows • ${totalWorkouts} Workout rows • 1 Hydration row`
          : `1 Daily Summary row • ${totalMeals} Food rows • ${totalWorkouts} Workout rows • 1 Hydration row`,
    });
  };

  const triggerExportAllConfirmation = () => {
    if (!connectedSheet) return;
    const allLogs = getAllStoredDailyLogs();

    setConfirmDialog({
      isOpen: true,
      actionType: 'export_all',
      title: lang === 'ur' ? 'Tamam History Google Sheets par Export Karein?' : 'Export All Logged History to Google Sheets?',
      description:
        lang === 'ur'
          ? `FitTrack mein mehfooz tamam ${allLogs.length} dino ka data aapki spreadsheet "${connectedSheet.name}" mein shamil kar diya jayega.`
          : `All ${allLogs.length} saved daily logs in FitTrack will be exported and appended to "${connectedSheet.name}".`,
      itemCountDescription:
        lang === 'ur'
          ? `${allLogs.length} dino ka mukammal record (Summary, Khurak, Warzish aur Hydration)`
          : `${allLogs.length} days of records across all tabs (Daily Summary, Meals, Workouts, Hydration)`,
    });
  };

  // 6. Execute Export after Explicit Confirmation
  const handleConfirmedExport = async () => {
    if (!confirmDialog || !connectedSheet) return;
    const action = confirmDialog.actionType;
    setConfirmDialog(null);
    setActionLoading(action);
    setStatusMessage(null);

    try {
      const token = await ensureToken();

      if (action === 'export_today') {
        const { addedRowsCount } = await appendDailyLogToSheet(
          token,
          connectedSheet.id,
          currentLog,
          goals
        );
        const updatedSheet = {
          ...connectedSheet,
          lastSynced: new Date().toISOString(),
        };
        setConnectedSheet(updatedSheet);
        saveConnectedSpreadsheet(updatedSheet);

        setStatusMessage({
          type: 'success',
          text:
            lang === 'ur'
              ? `Aaj ka log kamyabi se export ho gaya! (${addedRowsCount} rows shamil kiye gaye)`
              : `Today's log exported successfully! (${addedRowsCount} rows appended to Google Sheets)`,
          link: connectedSheet.url,
        });
      } else if (action === 'export_all') {
        const allLogs = getAllStoredDailyLogs();
        const { totalSyncedDays, totalRows } = await syncAllHistoryToSheet(
          token,
          connectedSheet.id,
          allLogs,
          goals
        );
        const updatedSheet = {
          ...connectedSheet,
          lastSynced: new Date().toISOString(),
        };
        setConnectedSheet(updatedSheet);
        saveConnectedSpreadsheet(updatedSheet);

        setStatusMessage({
          type: 'success',
          text:
            lang === 'ur'
              ? `Tamam ${totalSyncedDays} dino ki history export ho gayi (${totalRows} kul rows)!`
              : `Full history for ${totalSyncedDays} days synced (${totalRows} total rows appended)!`,
          link: connectedSheet.url,
        });
      }
    } catch (err: any) {
      console.error('Export error:', err);
      setStatusMessage({
        type: 'error',
        text: err.message || 'Export failed. Please check permissions or re-connect.',
      });
    } finally {
      setActionLoading(null);
    }
  };

  const handleDisconnectSheet = () => {
    saveConnectedSpreadsheet(null);
    setConnectedSheet(null);
    setStatusMessage({
      type: 'info',
      text: lang === 'ur' ? 'Spreadsheet disconnect ho gayi.' : 'Spreadsheet disconnected.',
    });
  };

  return (
    <div
      id="google-sheets-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-sm overflow-y-auto"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 16 }}
        className="relative w-full max-w-2xl bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl p-6 sm:p-8 my-8 text-stone-900 dark:text-stone-100"
      >
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-stone-100 dark:border-stone-800 mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 rounded-2xl">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold tracking-tight">
                {t.googleSheets || 'Google Sheets Integration'}
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {t.googleSheetsDesc || 'Sync workouts, meals & hydration logs directly with Google Sheets'}
              </p>
            </div>
          </div>
          <button
            id="close-google-sheets-modal"
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Notification / Feedback Status Banner */}
        {statusMessage && (
          <div
            className={`mb-6 p-4 rounded-2xl flex items-start justify-between gap-3 text-sm ${
              statusMessage.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200 border border-emerald-200 dark:border-emerald-800'
                : statusMessage.type === 'error'
                ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-900 dark:text-rose-200 border border-rose-200 dark:border-rose-800'
                : 'bg-sky-50 dark:bg-sky-950/60 text-sky-900 dark:text-sky-200 border border-sky-200 dark:border-sky-800'
            }`}
          >
            <div className="flex items-center gap-2">
              {statusMessage.type === 'success' ? (
                <Check className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              ) : (
                <AlertCircle className="w-5 h-5 shrink-0" />
              )}
              <span className="font-medium">{statusMessage.text}</span>
            </div>
            {statusMessage.link && (
              <a
                href={statusMessage.link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs font-bold underline shrink-0 hover:opacity-80"
              >
                {t.openInGoogleSheets || 'Open in Sheets'}
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        )}

        {/* SECTION 1: Google Authentication State */}
        <div className="mb-6 bg-stone-50 dark:bg-stone-800/60 p-4 rounded-2xl border border-stone-200/80 dark:border-stone-700/60">
          {!currentUser ? (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h4 className="text-sm font-bold">Connect your Google Account</h4>
                <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
                  Sign in to create, browse, and export fitness logs directly into Google Sheets.
                </p>
                {authError && (
                  <p className="text-xs text-rose-600 dark:text-rose-400 mt-1 font-medium">{authError}</p>
                )}
              </div>

              {/* Official Google Identity Services Button Style */}
              <button
                id="gsi-signin-button"
                onClick={handleSignIn}
                disabled={isAuthLoading}
                className="relative inline-flex items-center justify-center h-10 px-4 rounded-xl border border-stone-300 dark:border-stone-600 bg-white dark:bg-stone-900 hover:bg-stone-50 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-200 text-xs font-semibold shadow-xs transition-all cursor-pointer disabled:opacity-50 shrink-0"
              >
                {isAuthLoading ? (
                  <RefreshCw className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <svg className="w-4 h-4 mr-2.5 shrink-0" viewBox="0 0 48 48">
                    <path
                      fill="#EA4335"
                      d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                    />
                    <path
                      fill="#4285F4"
                      d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                    />
                    <path
                      fill="#34A853"
                      d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                    />
                  </svg>
                )}
                <span>{t.signInWithGoogle || 'Sign in with Google'}</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {currentUser.photoURL ? (
                  <img
                    src={currentUser.photoURL}
                    alt={currentUser.displayName || 'Google User'}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full border border-emerald-500/50"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                    {currentUser.displayName ? currentUser.displayName[0] : 'G'}
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm">{currentUser.displayName || 'Google Account'}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 font-semibold">
                      Connected
                    </span>
                  </div>
                  <p className="text-xs text-stone-500 dark:text-stone-400">{currentUser.email}</p>
                </div>
              </div>

              <button
                id="sign-out-button"
                onClick={handleSignOut}
                className="flex items-center gap-1.5 text-xs text-stone-500 hover:text-stone-900 dark:hover:text-white px-2.5 py-1.5 rounded-lg hover:bg-stone-200/60 dark:hover:bg-stone-700/60 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{t.signOut || 'Sign Out'}</span>
              </button>
            </div>
          )}
        </div>

        {/* SECTION 2: Connected Spreadsheet Card OR Connection Options */}
        {connectedSheet ? (
          <div className="space-y-4 mb-6">
            <div className="p-5 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-800/70">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-600 text-white rounded-xl">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-emerald-800 dark:text-emerald-400 uppercase tracking-wider">
                      {t.connectedSheet || 'Connected Spreadsheet'}
                    </span>
                    <h3 className="font-bold text-base text-stone-900 dark:text-white">
                      {connectedSheet.name}
                    </h3>
                  </div>
                </div>

                <a
                  id="open-connected-sheet-link"
                  href={connectedSheet.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 shadow-2xs transition-all cursor-pointer self-start sm:self-auto"
                >
                  <span>{t.openInGoogleSheets || 'Open in Google Sheets'}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              {/* Formatted Tabs Included Overview */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 py-3 border-y border-emerald-200/60 dark:border-emerald-800/40 text-xs">
                <div className="bg-white/80 dark:bg-stone-900/60 p-2 rounded-lg">
                  <div className="text-[10px] text-stone-500 dark:text-stone-400">Tab 1</div>
                  <div className="font-bold text-stone-800 dark:text-stone-200">Daily Summary</div>
                </div>
                <div className="bg-white/80 dark:bg-stone-900/60 p-2 rounded-lg">
                  <div className="text-[10px] text-stone-500 dark:text-stone-400">Tab 2</div>
                  <div className="font-bold text-stone-800 dark:text-stone-200">Meals & Nutrition</div>
                </div>
                <div className="bg-white/80 dark:bg-stone-900/60 p-2 rounded-lg">
                  <div className="text-[10px] text-stone-500 dark:text-stone-400">Tab 3</div>
                  <div className="font-bold text-stone-800 dark:text-stone-200">Workouts & Sets</div>
                </div>
                <div className="bg-white/80 dark:bg-stone-900/60 p-2 rounded-lg">
                  <div className="text-[10px] text-stone-500 dark:text-stone-400">Tab 4</div>
                  <div className="font-bold text-stone-800 dark:text-stone-200">Hydration Log</div>
                </div>
              </div>

              {/* Sync Actions Row */}
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs text-stone-500 dark:text-stone-400 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>
                    {t.lastSynced || 'Last synced'}:{' '}
                    {connectedSheet.lastSynced
                      ? new Date(connectedSheet.lastSynced).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })
                      : 'Never'}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    id="export-today-sheet-btn"
                    onClick={triggerExportTodayConfirmation}
                    disabled={actionLoading !== null}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition-all cursor-pointer disabled:opacity-50"
                  >
                    {actionLoading === 'export_today' ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Send className="w-3.5 h-3.5" />
                    )}
                    <span>{t.syncTodayLog || "Export Today's Log"}</span>
                  </button>

                  <button
                    id="export-all-sheet-btn"
                    onClick={triggerExportAllConfirmation}
                    disabled={actionLoading !== null}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 hover:bg-stone-100 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 font-semibold text-xs transition-all cursor-pointer disabled:opacity-50"
                  >
                    {actionLoading === 'export_all' ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Database className="w-3.5 h-3.5" />
                    )}
                    <span>{t.syncAllHistory || 'Export All History'}</span>
                  </button>

                  <button
                    id="disconnect-sheet-btn"
                    onClick={handleDisconnectSheet}
                    className="p-2 text-stone-400 hover:text-rose-600 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                    title="Disconnect Spreadsheet"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* When no spreadsheet is connected yet: 3 easy setup options */
          <div className="space-y-4 mb-6">
            <h3 className="font-bold text-sm text-stone-900 dark:text-white">
              {t.connectSpreadsheet || 'Connect a Google Sheet'}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Option 1: Create New FitTrack Spreadsheet */}
              <button
                id="create-new-sheet-btn"
                onClick={handleCreateNewSheet}
                disabled={actionLoading === 'create'}
                className="flex flex-col items-start p-4 rounded-2xl border-2 border-dashed border-emerald-500/40 bg-emerald-50/40 dark:bg-emerald-950/20 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:border-emerald-500 transition-all text-left cursor-pointer group disabled:opacity-50"
              >
                <div className="p-2 bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 rounded-xl mb-2.5 group-hover:scale-105 transition-transform">
                  <Plus className="w-5 h-5" />
                </div>
                <div className="font-bold text-sm text-stone-900 dark:text-white">
                  {t.createNewSheet || 'Create New FitTrack Sheet'}
                </div>
                <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
                  Automatically formats tabs for Daily Summary, Meals, Workouts & Hydration.
                </p>
                {actionLoading === 'create' && (
                  <span className="mt-2 text-xs font-semibold text-emerald-600 flex items-center gap-1">
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    Creating sheet in your Drive...
                  </span>
                )}
              </button>

              {/* Option 2: Select Existing Spreadsheet from Drive */}
              <button
                id="select-from-drive-btn"
                onClick={handleLoadDriveSheets}
                disabled={isLoadingDriveSheets}
                className="flex flex-col items-start p-4 rounded-2xl border border-stone-200 dark:border-stone-700 bg-stone-50/60 dark:bg-stone-800/40 hover:bg-stone-100/80 dark:hover:bg-stone-800 transition-all text-left cursor-pointer group disabled:opacity-50"
              >
                <div className="p-2 bg-stone-200 dark:bg-stone-700 text-stone-700 dark:text-stone-300 rounded-xl mb-2.5 group-hover:scale-105 transition-transform">
                  <FolderOpen className="w-5 h-5" />
                </div>
                <div className="font-bold text-sm text-stone-900 dark:text-white">
                  {t.selectFromDrive || 'Select from Google Drive'}
                </div>
                <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
                  Choose an existing spreadsheet from your Google Drive account.
                </p>
                {isLoadingDriveSheets && (
                  <span className="mt-2 text-xs font-semibold text-stone-600 dark:text-stone-300 flex items-center gap-1">
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    Browsing your spreadsheets...
                  </span>
                )}
              </button>
            </div>

            {/* Drive Files Picker List Drawer */}
            <AnimatePresence>
              {showDriveList && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden border border-stone-200 dark:border-stone-700 rounded-2xl p-4 bg-stone-50 dark:bg-stone-800/40 space-y-2"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
                      Your Spreadsheets ({driveSheets.length})
                    </span>
                    <button
                      onClick={() => setShowDriveList(false)}
                      className="text-xs text-stone-400 hover:text-stone-600"
                    >
                      Close list
                    </button>
                  </div>

                  {driveSheets.length === 0 ? (
                    <p className="text-xs text-stone-400 py-3 text-center">
                      No spreadsheets found in your Google Drive. Click "Create New FitTrack Sheet" above!
                    </p>
                  ) : (
                    <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                      {driveSheets.map((file) => (
                        <div
                          key={file.id}
                          className="flex items-center justify-between p-2.5 rounded-xl bg-white dark:bg-stone-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 border border-stone-200/70 dark:border-stone-700 transition-colors"
                        >
                          <div className="truncate mr-2">
                            <div className="font-semibold text-xs text-stone-900 dark:text-white truncate">
                              {file.name}
                            </div>
                            <div className="text-[10px] text-stone-400">
                              {file.modifiedTime ? new Date(file.modifiedTime).toLocaleDateString() : ''}
                            </div>
                          </div>
                          <button
                            id={`connect-file-${file.id}`}
                            onClick={() => handleSelectDriveSheet(file)}
                            disabled={actionLoading === `select-${file.id}`}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold cursor-pointer disabled:opacity-50 shrink-0"
                          >
                            {actionLoading === `select-${file.id}` ? (
                              <RefreshCw className="w-3 h-3 animate-spin" />
                            ) : (
                              'Connect'
                            )}
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Option 3: Manual Sheet URL or ID paste */}
            <div className="pt-2">
              <label className="block text-xs font-semibold text-stone-600 dark:text-stone-300 mb-1.5">
                Or paste a Google Sheet URL or ID:
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="https://docs.google.com/spreadsheets/d/1BxiMVs0XR.../edit"
                  value={customSheetUrl}
                  onChange={(e) => setCustomSheetUrl(e.target.value)}
                  className="flex-1 bg-white dark:bg-stone-800 border border-stone-300 dark:border-stone-700 rounded-xl px-3 py-2 text-xs text-stone-900 dark:text-white focus:outline-emerald-500"
                />
                <button
                  id="connect-url-btn"
                  onClick={handleConnectByUrl}
                  disabled={!customSheetUrl.trim() || actionLoading === 'custom-connect'}
                  className="px-4 py-2 bg-stone-800 dark:bg-stone-200 hover:bg-stone-900 dark:hover:bg-white text-white dark:text-stone-900 rounded-xl text-xs font-bold cursor-pointer disabled:opacity-50"
                >
                  {actionLoading === 'custom-connect' ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    'Connect'
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Benefits Note */}
        <div className="p-4 rounded-2xl bg-stone-100 dark:bg-stone-800/40 border border-stone-200/80 dark:border-stone-800 text-xs text-stone-600 dark:text-stone-400 space-y-1">
          <div className="flex items-center gap-1.5 font-bold text-stone-800 dark:text-stone-200">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>Why connect Google Sheets?</span>
          </div>
          <p>
            Your workout logs, macronutrients, and hydration are stored securely in your own Google Drive.
            You can analyze your fitness data in Google Sheets, build pivot tables, or share charts with your personal trainer.
          </p>
        </div>

        {/* Close Button Footer */}
        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 text-xs font-bold cursor-pointer transition-colors"
          >
            Done
          </button>
        </div>
      </motion.div>

      {/* MANDATORY USER CONFIRMATION DIALOG FOR DATA EXPORT / MUTATION */}
      <AnimatePresence>
        {confirmDialog && confirmDialog.isOpen && (
          <div
            id="export-confirmation-backdrop"
            className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-xs"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: 12 }}
              className="w-full max-w-md bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 p-6 shadow-2xl space-y-4"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 rounded-2xl">
                  <FileSpreadsheet className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-stone-900 dark:text-white">
                    {confirmDialog.title}
                  </h3>
                  <p className="text-xs text-stone-500 dark:text-stone-400">
                    Explicit confirmation required
                  </p>
                </div>
              </div>

              <div className="text-xs text-stone-600 dark:text-stone-300 space-y-2 bg-stone-50 dark:bg-stone-800/60 p-3.5 rounded-2xl border border-stone-200 dark:border-stone-700">
                <p>{confirmDialog.description}</p>
                {confirmDialog.itemCountDescription && (
                  <div className="font-mono text-[11px] font-semibold text-emerald-700 dark:text-emerald-400">
                    {confirmDialog.itemCountDescription}
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  id="cancel-export-btn"
                  onClick={() => setConfirmDialog(null)}
                  className="px-4 py-2 text-xs font-semibold text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white cursor-pointer"
                >
                  {t.cancel || 'Cancel'}
                </button>
                <button
                  id="proceed-export-btn"
                  onClick={handleConfirmedExport}
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm cursor-pointer transition-all flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{t.proceedExport || 'Yes, Export Data'}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
