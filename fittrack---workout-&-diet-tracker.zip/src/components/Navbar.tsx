import React from 'react';
import {
  Dumbbell,
  Utensils,
  LayoutDashboard,
  BarChart3,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Target,
  Globe,
  RotateCcw,
  Timer,
  Sun,
  Moon,
  FileSpreadsheet,
  Bot,
  Mic,
  Sparkles
} from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import { getStoredConnectedSpreadsheet } from '../services/googleSheetsService';
import appLogo from '../assets/images/fittrack_app_logo_1789490319714.jpg';

interface NavbarProps {
  activeTab: 'overview' | 'diet' | 'workouts' | 'analytics';
  onSelectTab: (tab: 'overview' | 'diet' | 'workouts' | 'analytics') => void;
  currentDate: string;
  onChangeDate: (date: string) => void;
  lang: Language;
  onToggleLang: () => void;
  onChangeLang?: (lang: Language) => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenGoalsModal: () => void;
  onOpenRestTimer: () => void;
  onOpenGoogleSheetsModal: () => void;
  onOpenLogoModal: () => void;
  onOpenGeminiChat: () => void;
  onOpenLiveVoice: () => void;
  onResetDemo: () => void;
}

export default function Navbar({
  activeTab,
  onSelectTab,
  currentDate,
  onChangeDate,
  lang,
  onToggleLang,
  isDarkMode,
  onToggleDarkMode,
  onOpenGoalsModal,
  onOpenRestTimer,
  onOpenGoogleSheetsModal,
  onOpenLogoModal,
  onOpenGeminiChat,
  onOpenLiveVoice,
  onResetDemo,
}: NavbarProps) {
  const t = TRANSLATIONS[lang];

  // Helper for previous / next day
  const handleShiftDay = (delta: number) => {
    const d = new Date(currentDate + 'T00:00:00');
    d.setDate(d.getDate() + delta);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    onChangeDate(`${yyyy}-${mm}-${dd}`);
  };

  const isToday = () => {
    const now = new Date();
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
      now.getDate()
    ).padStart(2, '0')}`;
    return currentDate === todayStr;
  };

  // Format date display
  const formatDateDisplay = () => {
    if (isToday()) {
      return lang === 'ur' ? 'Aaj (Today)' : 'Today';
    }
    const d = new Date(currentDate + 'T00:00:00');
    return d.toLocaleDateString(lang === 'ur' ? 'en-PK' : 'en-US', {
      month: 'short',
      day: 'numeric',
      weekday: 'short',
    });
  };

  return (
    <header
      id="main-app-header"
      className="sticky top-0 z-40 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md border-b border-stone-200/80 dark:border-stone-800 shadow-xs transition-colors duration-200"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <button
              id="navbar-logo-btn"
              onClick={onOpenLogoModal}
              className="relative group cursor-pointer p-0.5 rounded-xl transition-transform hover:scale-105 focus:outline-none"
              title={lang === 'ur' ? 'Logo dekhne aur download karne ke liye click karein' : 'Click to view & download FitTrack logo'}
            >
              <img
                src={appLogo}
                alt="FitTrack Logo"
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-xl object-cover shadow-md shadow-emerald-600/20 border border-emerald-500/30"
              />
              <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 text-white rounded-full flex items-center justify-center text-[9px] font-bold shadow-xs">
                ★
              </span>
            </button>
            <div
              className="cursor-pointer select-none"
              onClick={onOpenLogoModal}
              title={lang === 'ur' ? 'FitTrack Logo' : 'View FitTrack Logo'}
            >
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-stone-900 dark:text-white text-lg tracking-tight font-['Outfit',sans-serif] hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors">
                  FitTrack
                </span>
                <span className="text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 dark:border dark:border-emerald-800">
                  {lang === 'ur' ? 'Fitness Log' : 'Fitness Pro'}
                </span>
              </div>
              <p className="text-[11px] text-stone-400 dark:text-stone-400 font-medium hidden sm:block">
                {lang === 'ur' ? 'Workout aur Diet Tracker' : 'Workout & Diet Tracker'}
              </p>
            </div>
          </div>

          {/* Date Picker Bar */}
          <div className="flex items-center bg-stone-100 dark:bg-stone-800 p-1 rounded-xl border border-stone-200/70 dark:border-stone-700">
            <button
              id="prev-date-btn"
              onClick={() => handleShiftDay(-1)}
              className="p-1.5 text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white hover:bg-white dark:hover:bg-stone-700 rounded-lg transition-colors"
              title="Previous Day"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1.5 px-3 py-1 font-semibold text-xs text-stone-800 dark:text-stone-200">
              <Calendar className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>{formatDateDisplay()}</span>
            </div>

            <button
              id="next-date-btn"
              onClick={() => handleShiftDay(1)}
              className="p-1.5 text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white hover:bg-white dark:hover:bg-stone-700 rounded-lg transition-colors"
              title="Next Day"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Right Header Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Dark Mode Toggle Button */}
            <button
              id="header-dark-mode-btn"
              onClick={onToggleDarkMode}
              className={`flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl text-xs font-semibold border transition-all ${
                isDarkMode
                  ? 'bg-amber-400/10 hover:bg-amber-400/20 text-amber-300 border-amber-500/30'
                  : 'bg-stone-50 hover:bg-stone-100 text-stone-700 hover:text-stone-900 border-stone-200/80'
              }`}
              title={isDarkMode ? (lang === 'ur' ? 'Light Mode On Karein' : 'Switch to Light Mode') : (lang === 'ur' ? 'Dark Mode On Karein' : 'Switch to Dark Mode')}
              aria-label="Toggle Dark Mode"
            >
              {isDarkMode ? (
                <>
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span className="hidden lg:inline">{t.lightMode}</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-stone-600" />
                  <span className="hidden lg:inline">{t.darkMode}</span>
                </>
              )}
            </button>

            {/* Live Voice API Button */}
            <button
              id="header-live-voice-btn"
              onClick={onOpenLiveVoice}
              className="flex items-center gap-1.5 py-1.5 px-2.5 text-xs font-bold text-teal-800 dark:text-teal-200 bg-teal-50 dark:bg-teal-950/70 hover:bg-teal-100 dark:hover:bg-teal-900/60 border border-teal-300/80 dark:border-teal-700/80 rounded-xl transition-all cursor-pointer shadow-xs"
              title={lang === 'ur' ? 'Live Voice Coach (gemini-3.1-flash-live-preview)' : 'Real-time Live Voice Coach (gemini-3.1-flash-live-preview)'}
            >
              <Mic className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 animate-pulse" />
              <span className="hidden sm:inline">{lang === 'ur' ? 'Voice Coach' : 'Voice Coach'}</span>
            </button>

            {/* Gemini AI Chatbot Button */}
            <button
              id="header-gemini-chat-btn"
              onClick={onOpenGeminiChat}
              className="flex items-center gap-1.5 py-1.5 px-2.5 text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 rounded-xl shadow-xs transition-all cursor-pointer"
              title={lang === 'ur' ? 'Gemini AI Chatbot Kholein' : 'Open Gemini AI Fitness Chatbot'}
            >
              <Bot className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{lang === 'ur' ? 'AI Coach' : 'AI Coach'}</span>
            </button>

            {/* Rest Timer Button */}
            <button
              id="header-rest-timer-btn"
              onClick={onOpenRestTimer}
              className="p-2 text-stone-600 dark:text-stone-300 hover:text-emerald-700 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-xl transition-colors"
              title={t.activeTimer}
            >
              <Timer className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            </button>

            {/* Google Sheets Sync Button */}
            <button
              id="header-google-sheets-btn"
              onClick={onOpenGoogleSheetsModal}
              className="relative flex items-center gap-1.5 py-1.5 px-2.5 text-xs font-semibold text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 border border-emerald-200/80 dark:border-emerald-800 rounded-xl transition-colors cursor-pointer"
              title={t.googleSheets || 'Google Sheets'}
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span className="hidden sm:inline">{t.googleSheets || 'Google Sheets'}</span>
              {getStoredConnectedSpreadsheet() && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              )}
            </button>

            {/* Goals Modal Button */}
            <button
              id="header-goals-btn"
              onClick={onOpenGoalsModal}
              className="flex items-center gap-1 py-1.5 px-2.5 text-xs font-semibold text-stone-700 dark:text-stone-200 hover:text-stone-900 dark:hover:text-white bg-stone-50 dark:bg-stone-800 hover:bg-stone-100 dark:hover:bg-stone-700 border border-stone-200/80 dark:border-stone-700 rounded-xl transition-colors"
            >
              <Target className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span className="hidden md:inline">{t.goals}</span>
            </button>

            {/* Language Switcher (Cycle: English -> Roman Urdu -> Hindi) */}
            <button
              id="header-lang-toggle-btn"
              onClick={onToggleLang}
              className="flex items-center gap-1.5 py-1.5 px-2.5 text-xs font-semibold text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 border border-emerald-200/80 dark:border-emerald-800 rounded-xl transition-colors cursor-pointer"
              title="Switch Language: English / Roman Urdu / हिन्दी"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>
                {lang === 'en' ? 'English' : lang === 'ur' ? 'Roman Urdu' : 'हिन्दी'}
              </span>
            </button>

            {/* Reset Demo Data Button */}
            <button
              id="header-reset-demo-btn"
              onClick={onResetDemo}
              className="p-2 text-stone-400 dark:text-stone-500 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors"
              title={t.resetDemo}
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Navigation Strip */}
        <nav className="flex space-x-1 sm:space-x-4 border-t border-stone-100 dark:border-stone-800 py-1 overflow-x-auto">
          {[
            { id: 'overview', label: t.overview, icon: LayoutDashboard },
            { id: 'diet', label: t.diet, icon: Utensils },
            { id: 'workouts', label: t.workouts, icon: Dumbbell },
            { id: 'analytics', label: t.analytics, icon: BarChart3 },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`nav-tab-${tab.id}`}
                onClick={() => onSelectTab(tab.id as any)}
                className={`flex items-center gap-2 py-2 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-600 dark:bg-emerald-500 text-white dark:text-stone-950 font-bold shadow-xs'
                    : 'text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100/70 dark:hover:bg-stone-800/80'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white dark:text-stone-950' : 'text-stone-400 dark:text-stone-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
