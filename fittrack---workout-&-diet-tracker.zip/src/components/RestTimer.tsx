import { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, X, Timer as TimerIcon } from 'lucide-react';

interface RestTimerProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'en' | 'ur';
}

export default function RestTimer({ isOpen, onClose, lang }: RestTimerProps) {
  const [totalSeconds, setTotalSeconds] = useState<number>(60);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const timerRef = useRef<number | null>(null);

  // Synthesize soft clean audio beep using Web Audio API
  const playBeep = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime); // 880Hz note A5
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.4);
    } catch {
      // Audio context might be restricted before interaction
    }
  };

  useEffect(() => {
    if (isRunning && secondsRemaining > 0) {
      timerRef.current = window.setInterval(() => {
        setSecondsRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setIsRunning(false);
            playBeep();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, secondsRemaining]);

  const setPreset = (sec: number) => {
    setIsRunning(false);
    setTotalSeconds(sec);
    setSecondsRemaining(sec);
  };

  const toggleRun = () => {
    if (secondsRemaining === 0) {
      setSecondsRemaining(totalSeconds);
      setIsRunning(true);
    } else {
      setIsRunning(!isRunning);
    }
  };

  const reset = () => {
    setIsRunning(false);
    setSecondsRemaining(totalSeconds);
  };

  if (!isOpen) return null;

  const progressPercent = totalSeconds > 0 ? ((totalSeconds - secondsRemaining) / totalSeconds) * 100 : 0;
  const minutes = Math.floor(secondsRemaining / 60);
  const seconds = secondsRemaining % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  return (
    <div
      id="rest-timer-widget"
      className="fixed bottom-6 right-6 z-50 w-80 bg-stone-900 text-white rounded-2xl shadow-2xl border border-stone-700/80 p-5 backdrop-blur-md"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-lg">
            <TimerIcon className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-semibold tracking-wide text-stone-100">
              {lang === 'ur' ? 'Waqfa / Rest Timer' : 'Workout Rest Timer'}
            </h4>
            <p className="text-xs text-stone-400">
              {lang === 'ur' ? 'Sets ke darmiyan aaram' : 'Rest between your sets'}
            </p>
          </div>
        </div>
        <button
          id="close-rest-timer-btn"
          onClick={onClose}
          className="text-stone-400 hover:text-stone-200 p-1 hover:bg-stone-800 rounded-lg transition-colors"
          aria-label="Close timer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Timer Display & Circular Bar */}
      <div className="flex flex-col items-center justify-center my-3">
        <div className="relative w-32 h-32 flex items-center justify-center">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="42"
              className="stroke-stone-800"
              strokeWidth="7"
              fill="transparent"
            />
            <circle
              cx="50"
              cy="50"
              r="42"
              className="stroke-emerald-400 transition-all duration-300"
              strokeWidth="7"
              strokeDasharray={264}
              strokeDashoffset={264 - (264 * progressPercent) / 100}
              strokeLinecap="round"
              fill="transparent"
            />
          </svg>
          <div className="absolute flex flex-col items-center justify-center">
            <span className="text-3xl font-bold font-mono tracking-wider text-emerald-300">
              {formattedTime}
            </span>
            <span className="text-[10px] text-stone-400 uppercase tracking-widest mt-0.5">
              {isRunning ? (lang === 'ur' ? 'Chalu hai' : 'Resting') : secondsRemaining === 0 ? (lang === 'ur' ? 'Waqt Khatam!' : 'Time Up!') : (lang === 'ur' ? 'Ruka hua' : 'Ready')}
            </span>
          </div>
        </div>
      </div>

      {/* Preset Quick Buttons */}
      <div className="grid grid-cols-4 gap-1.5 mb-4">
        {[30, 60, 90, 120].map((sec) => (
          <button
            key={sec}
            id={`timer-preset-${sec}`}
            onClick={() => setPreset(sec)}
            className={`py-1.5 text-xs font-medium rounded-lg transition-all ${
              totalSeconds === sec && !isRunning
                ? 'bg-emerald-500 text-stone-950 font-bold'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
            }`}
          >
            {sec}s
          </button>
        ))}
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-3">
        <button
          id="toggle-timer-run-btn"
          onClick={toggleRun}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-medium text-sm transition-all shadow-md ${
            isRunning
              ? 'bg-amber-500 hover:bg-amber-600 text-stone-950'
              : 'bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-semibold'
          }`}
        >
          {isRunning ? (
            <>
              <Pause className="w-4 h-4" /> {lang === 'ur' ? 'Rokein' : 'Pause'}
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-stone-950" />{' '}
              {secondsRemaining === 0
                ? lang === 'ur' ? 'Dobara Shuru' : 'Restart'
                : lang === 'ur' ? 'Shuru Karein' : 'Start Rest'}
            </>
          )}
        </button>

        <button
          id="reset-timer-btn"
          onClick={reset}
          className="p-2.5 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-xl transition-colors"
          title={lang === 'ur' ? 'Reset' : 'Reset'}
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
