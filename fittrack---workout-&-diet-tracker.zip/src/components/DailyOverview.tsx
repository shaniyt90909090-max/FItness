import React from 'react';
import {
  Flame,
  Dumbbell,
  Utensils,
  Droplets,
  Target,
  ArrowUpRight,
  TrendingUp,
  CheckCircle2,
  Timer,
  FileSpreadsheet
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { DailyLog, UserGoals, Language } from '../types';
import { TRANSLATIONS } from '../utils/translations';
import WaterTracker from './WaterTracker';
import QuickAddSection from './QuickAddSection';
import { getStoredConnectedSpreadsheet } from '../services/googleSheetsService';

interface DailyOverviewProps {
  log: DailyLog;
  goals: UserGoals;
  onUpdateLog: (updatedLog: DailyLog) => void;
  onNavigateTab: (tab: 'diet' | 'workouts' | 'analytics') => void;
  onOpenGoalsModal: () => void;
  onOpenRestTimer: () => void;
  onOpenGoogleSheetsModal?: () => void;
  lang: Language;
}

export default function DailyOverview({
  log,
  goals,
  onUpdateLog,
  onNavigateTab,
  onOpenGoalsModal,
  onOpenRestTimer,
  onOpenGoogleSheetsModal,
  lang,
}: DailyOverviewProps) {
  const t = TRANSLATIONS[lang];

  // Calculate total calories & macros eaten
  const allMeals = [
    ...log.meals.breakfast,
    ...log.meals.lunch,
    ...log.meals.dinner,
    ...log.meals.snack,
  ];

  const totalCaloriesEaten = allMeals.reduce((acc, item) => acc + (item.calories || 0), 0);
  const totalProteinG = allMeals.reduce((acc, item) => acc + (item.protein || 0), 0);
  const totalCarbsG = allMeals.reduce((acc, item) => acc + (item.carbs || 0), 0);
  const totalFatG = allMeals.reduce((acc, item) => acc + (item.fat || 0), 0);

  // Calculate workout burn
  const totalCaloriesBurned = log.workouts.reduce(
    (acc, w) => acc + (w.caloriesBurned || 0),
    0
  );
  const totalCompletedSets = log.workouts.reduce(
    (acc, w) => acc + w.sets.filter((s) => s.completed).length,
    0
  );

  const caloriesRemaining = Math.max(0, goals.dailyCalories - totalCaloriesEaten);
  const netCalories = totalCaloriesEaten - totalCaloriesBurned;

  // Calorie progress calculation
  const caloriePercent = Math.min(100, Math.round((totalCaloriesEaten / goals.dailyCalories) * 100));
  const proteinPercent = Math.min(100, Math.round((totalProteinG / goals.dailyProteinG) * 100));
  const carbsPercent = Math.min(100, Math.round((totalCarbsG / goals.dailyCarbsG) * 100));
  const fatPercent = Math.min(100, Math.round((totalFatG / goals.dailyFatG) * 100));

  const triggerCelebration = () => {
    try {
      confetti({
        particleCount: 75,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {
      // safe fallback
    }
  };

  const handleUpdateWater = (newAmountMl: number) => {
    onUpdateLog({ ...log, waterIntakeMl: newAmountMl });
  };

  return (
    <div id="daily-overview-section" className="space-y-6">
      {/* Top Banner: Main Calorie In vs Out Dashboard */}
      <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/80 dark:border-stone-800 p-6 shadow-sm transition-colors">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
          {/* Circular SVG Gauge for Calories */}
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="relative w-44 h-44 flex items-center justify-center shrink-0">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                {/* Background Ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  className="stroke-stone-100 dark:stroke-stone-800"
                  strokeWidth="8"
                  fill="transparent"
                />
                {/* Calories Eaten Ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  className="stroke-amber-500 dark:stroke-amber-400 transition-all duration-700"
                  strokeWidth="8"
                  strokeDasharray={251.2}
                  strokeDashoffset={251.2 - (251.2 * Math.min(100, caloriePercent)) / 100}
                  strokeLinecap="round"
                  fill="transparent"
                />
              </svg>
              <div className="absolute flex flex-col items-center justify-center text-center">
                <span className="text-3xl font-extrabold text-stone-900 dark:text-white font-mono tracking-tight">
                  {Math.round(caloriesRemaining)}
                </span>
                <span className="text-[11px] font-semibold text-stone-400 dark:text-stone-400 uppercase tracking-wider mt-0.5">
                  {t.remaining}
                </span>
                <span className="text-[10px] text-stone-400 dark:text-stone-500 font-mono mt-0.5">
                  / {goals.dailyCalories} kcal
                </span>
              </div>
            </div>

            {/* Quick Metrics Breakdown */}
            <div className="space-y-3 w-full sm:w-auto">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 rounded-xl">
                  <Utensils className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs text-stone-400 dark:text-stone-400 font-medium">
                    {lang === 'ur' ? 'Khana Khaya' : 'Food Consumed'}
                  </div>
                  <div className="text-base font-bold text-stone-800 dark:text-stone-100 font-mono">
                    {Math.round(totalCaloriesEaten)}{' '}
                    <span className="text-xs text-stone-400 dark:text-stone-500 font-sans">kcal</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="p-2 bg-orange-100 dark:bg-orange-950/60 text-orange-700 dark:text-orange-400 rounded-xl">
                  <Flame className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs text-stone-400 dark:text-stone-400 font-medium">
                    {lang === 'ur' ? 'Warzish mein Jali' : 'Burned in Workouts'}
                  </div>
                  <div className="text-base font-bold text-orange-600 dark:text-orange-400 font-mono">
                    -{Math.round(totalCaloriesBurned)}{' '}
                    <span className="text-xs text-stone-400 dark:text-stone-500 font-sans">kcal</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-400 rounded-xl">
                  <TrendingUp className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs text-stone-400 dark:text-stone-400 font-medium">
                    {t.netCalories}
                  </div>
                  <div className="text-base font-bold text-stone-900 dark:text-white font-mono">
                    {Math.round(netCalories)}{' '}
                    <span className="text-xs text-stone-400 dark:text-stone-500 font-sans">kcal</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Macronutrients Bars */}
          <div className="w-full lg:max-w-md bg-stone-50/70 dark:bg-stone-800/60 p-5 rounded-xl border border-stone-200/60 dark:border-stone-700/60 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
                {lang === 'ur' ? 'Rozana ke Macros' : 'Macronutrient Breakdown'}
              </h4>
              <button
                onClick={onOpenGoalsModal}
                className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:text-emerald-800 dark:hover:text-emerald-300 flex items-center gap-1"
              >
                <Target className="w-3.5 h-3.5" />
                {lang === 'ur' ? 'Targets Badlein' : 'Edit Goals'}
              </button>
            </div>

            {/* Protein Bar */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-stone-800 dark:text-stone-200">
                  {lang === 'ur' ? 'Protein' : 'Protein'}
                </span>
                <span className="text-stone-500 dark:text-stone-400 font-mono">
                  {Math.round(totalProteinG)}g / {goals.dailyProteinG}g ({proteinPercent}%)
                </span>
              </div>
              <div className="w-full bg-stone-200 dark:bg-stone-700 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-red-500 dark:bg-red-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${proteinPercent}%` }}
                />
              </div>
            </div>

            {/* Carbs Bar */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-stone-800 dark:text-stone-200">
                  {lang === 'ur' ? 'Carbs' : 'Carbs'}
                </span>
                <span className="text-stone-500 dark:text-stone-400 font-mono">
                  {Math.round(totalCarbsG)}g / {goals.dailyCarbsG}g ({carbsPercent}%)
                </span>
              </div>
              <div className="w-full bg-stone-200 dark:bg-stone-700 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-blue-500 dark:bg-blue-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${carbsPercent}%` }}
                />
              </div>
            </div>

            {/* Fat Bar */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-stone-800 dark:text-stone-200">
                  {lang === 'ur' ? 'Fat (Charbi)' : 'Fat'}
                </span>
                <span className="text-stone-500 dark:text-stone-400 font-mono">
                  {Math.round(totalFatG)}g / {goals.dailyFatG}g ({fatPercent}%)
                </span>
              </div>
              <div className="w-full bg-stone-200 dark:bg-stone-700 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-amber-500 dark:bg-amber-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${fatPercent}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 1-Click Quick Add Essentials Section */}
      <QuickAddSection
        log={log}
        goals={goals}
        onUpdateLog={onUpdateLog}
        lang={lang}
      />

      {/* Grid: Workouts Summary & Water Tracker */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Workout Activity Card */}
        <div
          id="overview-workouts-card"
          className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/80 dark:border-stone-800 p-5 shadow-sm flex flex-col justify-between transition-colors"
        >
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-400 rounded-xl">
                  <Dumbbell className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 dark:text-white text-base">
                    {lang === 'ur' ? 'Aaj ki Warzish' : "Today's Workouts"}
                  </h3>
                  <p className="text-xs text-stone-500 dark:text-stone-400">
                    {log.workouts.length} {lang === 'ur' ? 'exercises record huin' : 'exercises logged'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => onNavigateTab('workouts')}
                className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:text-emerald-800 dark:hover:text-emerald-300 flex items-center gap-1"
              >
                {lang === 'ur' ? 'Tafseelat' : 'View All'}
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {log.workouts.length === 0 ? (
              <div className="py-6 text-center text-xs text-stone-400 dark:text-stone-500 italic">
                {t.noWorkoutsToday}
              </div>
            ) : (
              <div className="space-y-2 mb-4">
                {log.workouts.slice(0, 3).map((w) => (
                  <div
                    key={w.id}
                    className="flex items-center justify-between p-2.5 bg-stone-50 dark:bg-stone-800/70 rounded-xl border border-stone-100 dark:border-stone-700/80 text-xs"
                  >
                    <div>
                      <span className="font-semibold text-stone-800 dark:text-stone-200 block">
                        {w.name}
                      </span>
                      <span className="text-[11px] text-stone-400 dark:text-stone-400">
                        {w.sets.length} sets • {w.sets.filter((s) => s.completed).length} completed
                      </span>
                    </div>
                    <span className="font-mono text-orange-600 dark:text-orange-400 font-bold">
                      {w.caloriesBurned} kcal
                    </span>
                  </div>
                ))}
                {log.workouts.length > 3 && (
                  <div className="text-[11px] text-stone-400 dark:text-stone-500 text-center">
                    +{log.workouts.length - 3} more exercises
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between gap-2">
            <button
              id="overview-quick-add-workout"
              onClick={() => onNavigateTab('workouts')}
              className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 dark:bg-emerald-500 dark:hover:bg-emerald-400 text-white dark:text-stone-950 rounded-xl text-xs font-semibold shadow-xs flex items-center justify-center gap-1.5 transition-colors"
            >
              <Dumbbell className="w-3.5 h-3.5" />
              {t.logWorkout}
            </button>

            <button
              onClick={onOpenRestTimer}
              className="py-2 px-3 bg-stone-900 hover:bg-stone-800 dark:bg-stone-800 dark:hover:bg-stone-700 text-emerald-400 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 border border-stone-800 dark:border-stone-700"
            >
              <Timer className="w-3.5 h-3.5" />
              {t.activeTimer}
            </button>
          </div>
        </div>

        {/* Water Tracker Card */}
        <WaterTracker
          waterIntakeMl={log.waterIntakeMl}
          dailyWaterMl={goals.dailyWaterMl}
          onUpdateWater={handleUpdateWater}
          lang={lang}
        />
      </div>

      {/* Google Sheets Sync Card */}
      {onOpenGoogleSheetsModal && (
        <div className="bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-800/60 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="p-2.5 bg-emerald-600 text-white rounded-xl shadow-xs">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-stone-900 dark:text-stone-100">
                  {lang === 'ur' ? 'Google Sheets Sync' : 'Google Sheets Sync'}
                </span>
                {getStoredConnectedSpreadsheet() ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300">
                    {lang === 'ur' ? 'Connected' : 'Connected'}
                  </span>
                ) : (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-stone-200 dark:bg-stone-800 text-stone-600 dark:text-stone-400">
                    {lang === 'ur' ? 'Setup Required' : 'Ready to Connect'}
                  </span>
                )}
              </div>
              <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
                {lang === 'ur'
                  ? 'Apne rozana ke khurak, warzish aur paani ke aadaad o shumar Google Sheets par export karein.'
                  : 'Export today’s meals, workouts, calories, and hydration logs directly into your Google Sheet.'}
              </p>
            </div>
          </div>

          <button
            id="overview-open-sheets-btn"
            onClick={onOpenGoogleSheetsModal}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer shrink-0"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>
              {getStoredConnectedSpreadsheet()
                ? (lang === 'ur' ? "Aaj ka Log Sync Karein" : "Export to Google Sheets")
                : (lang === 'ur' ? 'Google Sheets Connect Karein' : 'Connect Google Sheets')}
            </span>
          </button>
        </div>
      )}

      {/* Quick Action Navigation Strip */}
      <div className="bg-stone-900 dark:bg-stone-900/90 text-stone-200 rounded-2xl p-5 shadow-md flex flex-col sm:flex-row items-center justify-between gap-4 border border-stone-800">
        <div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span className="font-bold text-white text-sm">
              {lang === 'ur' ? 'Fitness Tracker Tayyar Hai!' : 'Track Workouts & Diet in Real-Time'}
            </span>
          </div>
          <p className="text-xs text-stone-400 mt-1">
            {lang === 'ur'
              ? 'Sets, weights, roti, biryani, protein shake sab aik jagah mehfooz hain.'
              : 'Effortlessly balance your energy in vs energy out with customized nutritional targets.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigateTab('diet')}
            className="py-2 px-4 bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-bold text-xs rounded-xl shadow transition-colors"
          >
            {lang === 'ur' ? 'Khurak Log Karein' : 'Track Diet'}
          </button>

          <button
            onClick={() => onNavigateTab('workouts')}
            className="py-2 px-4 bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold text-xs rounded-xl transition-colors border border-stone-700"
          >
            {lang === 'ur' ? 'Warzish Log Karein' : 'Track Workout'}
          </button>
        </div>
      </div>
    </div>
  );
}
