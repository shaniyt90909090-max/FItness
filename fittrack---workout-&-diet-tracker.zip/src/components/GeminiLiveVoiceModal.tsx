import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Mic,
  MicOff,
  Radio,
  Sparkles,
  Volume2,
  AlertCircle,
  MessageSquare,
  Check,
  RotateCcw,
  Globe,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { float32To16BitPCMBase64, LiveAudioPlayer } from '../services/audioStreaming';
import { Language } from '../types';

interface GeminiLiveVoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onSelectLanguage?: (lang: Language) => void;
}

interface TranscriptItem {
  id: string;
  sender: 'user' | 'model';
  text: string;
  timestamp: string;
}

export default function GeminiLiveVoiceModal({
  isOpen,
  onClose,
  lang,
  onSelectLanguage,
}: GeminiLiveVoiceModalProps) {
  const [activeVoiceLang, setActiveVoiceLang] = useState<Language>(lang);
  const [connectionStatus, setConnectionStatus] = useState<
    'connecting' | 'connected' | 'listening' | 'speaking' | 'interrupted' | 'error' | 'disconnected'
  >('connecting');
  const [isMuted, setIsMuted] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [transcripts, setTranscripts] = useState<TranscriptItem[]>([]);
  const [liveModelText, setLiveModelText] = useState<string>('');

  // Sync with prop when opened
  useEffect(() => {
    setActiveVoiceLang(lang);
  }, [lang, isOpen]);

  const wsRef = useRef<WebSocket | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const liveAudioPlayerRef = useRef<LiveAudioPlayer | null>(null);
  const isMutedRef = useRef(isMuted);

  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  // Clean shutdown of all media streams, WebSockets and audio contexts
  const cleanup = () => {
    if (processorRef.current) {
      try {
        processorRef.current.disconnect();
      } catch (e) {}
      processorRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }

    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try {
        audioContextRef.current.close();
      } catch (e) {}
      audioContextRef.current = null;
    }

    if (liveAudioPlayerRef.current) {
      liveAudioPlayerRef.current.close();
      liveAudioPlayerRef.current = null;
    }

    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch (e) {}
      wsRef.current = null;
    }
  };

  const startSession = async (targetLang: Language = activeVoiceLang) => {
    cleanup();
    setConnectionStatus('connecting');
    setErrorMessage(null);
    setLiveModelText('');

    try {
      // 1. Initialize 24kHz output player
      liveAudioPlayerRef.current = new LiveAudioPlayer();

      // 2. Establish WebSocket connection to backend /live with selected language
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live?lang=${targetLang}`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log(`[Live Voice] Connected to WS /live with lang: ${targetLang}`);
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);

          if (data.type === 'connected') {
            setConnectionStatus('connected');
          } else if (data.type === 'audio' && data.audio) {
            setConnectionStatus('speaking');
            liveAudioPlayerRef.current?.playChunk(data.audio);
          } else if (data.type === 'text' && data.text) {
            setLiveModelText((prev) => prev + data.text);
          } else if (data.type === 'transcript_model' && data.text) {
            setTranscripts((prev) => [
              ...prev,
              {
                id: 't-' + Date.now(),
                sender: 'model',
                text: data.text,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              },
            ]);
            setLiveModelText('');
          } else if (data.type === 'transcript_user' && data.text) {
            setTranscripts((prev) => [
              ...prev,
              {
                id: 'u-' + Date.now(),
                sender: 'user',
                text: data.text,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              },
            ]);
          } else if (data.type === 'interrupted') {
            setConnectionStatus('interrupted');
            liveAudioPlayerRef.current?.stopAll();
            setTimeout(() => {
              setConnectionStatus((curr) => (curr === 'interrupted' ? 'listening' : curr));
            }, 800);
          } else if (data.type === 'turnComplete') {
            setConnectionStatus('listening');
            if (liveModelText.trim()) {
              setTranscripts((prev) => [
                ...prev,
                {
                  id: 't-' + Date.now(),
                  sender: 'model',
                  text: liveModelText.trim(),
                  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                },
              ]);
              setLiveModelText('');
            }
          } else if (data.type === 'error') {
            setConnectionStatus('error');
            setErrorMessage(data.error || 'Live session error');
          }
        } catch (e) {
          console.error('[Live Voice] Error parsing ws message:', e);
        }
      };

      ws.onerror = (e) => {
        console.error('[Live Voice] WS error:', e);
        setConnectionStatus('error');
        setErrorMessage('Could not connect to voice server');
      };

      ws.onclose = () => {
        console.log('[Live Voice] WS closed');
        setConnectionStatus('disconnected');
      };

      // 3. Capture 16kHz audio from microphone
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          channelCount: 1,
        },
      });
      mediaStreamRef.current = stream;

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioCtx({ sampleRate: 16000 });
      audioContextRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);
      // Buffer size 4096 samples at 16kHz gives approx 256ms chunk
      const processor = audioCtx.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;

      processor.onaudioprocess = (e) => {
        if (isMutedRef.current) return;
        if (!wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;

        const channelData = e.inputBuffer.getChannelData(0);
        const base64Audio = float32To16BitPCMBase64(channelData);

        wsRef.current.send(
          JSON.stringify({
            audio: base64Audio,
          })
        );
      };

      source.connect(processor);
      processor.connect(audioCtx.destination);
      setConnectionStatus('listening');
    } catch (err: any) {
      console.error('[Live Voice] Microphone or connection setup failed:', err);
      setConnectionStatus('error');
      setErrorMessage(
        err?.name === 'NotAllowedError'
          ? 'Microphone permission was denied. Please allow microphone access in browser settings.'
          : err?.message || 'Failed to start microphone'
      );
    }
  };

  useEffect(() => {
    if (isOpen) {
      startSession();
    } else {
      cleanup();
    }
    return () => {
      cleanup();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div
      id="gemini-live-voice-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/80 backdrop-blur-md overflow-hidden"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 20 }}
        className="relative w-full max-w-xl bg-stone-900 rounded-3xl border border-stone-800 shadow-2xl flex flex-col overflow-hidden text-stone-100"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-stone-800/80 flex items-center justify-between bg-stone-900/90">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-2xl">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base tracking-tight text-white font-['Outfit',sans-serif]">
                  FitTrack Live Voice Coach
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                  gemini-3.1-flash-live-preview
                </span>
              </div>
              <p className="text-xs text-stone-400">
                {activeVoiceLang === 'hi'
                  ? 'रीयल-टाइम वॉयस बातचीत (हिंदी, उर्दू, English)'
                  : activeVoiceLang === 'ur'
                  ? 'Real-time low-latency fitness & workout baatchit (Urdu, Hindi, English)'
                  : 'Low-latency real-time voice streaming conversation'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* 3-Language Selector inside Voice Modal */}
            <div className="flex items-center bg-stone-950/80 border border-stone-800 p-1 rounded-xl gap-1">
              <Globe className="w-3.5 h-3.5 text-stone-400 ml-1 mr-0.5 hidden sm:block" />
              {(
                [
                  { code: 'en', label: 'EN', title: 'English' },
                  { code: 'ur', label: 'اردو', title: 'Roman Urdu' },
                  { code: 'hi', label: 'हिंदी', title: 'Hindi' },
                ] as const
              ).map((l) => (
                <button
                  key={l.code}
                  onClick={() => {
                    if (activeVoiceLang !== l.code) {
                      setActiveVoiceLang(l.code);
                      if (onSelectLanguage) onSelectLanguage(l.code);
                      startSession(l.code);
                    }
                  }}
                  className={`px-2 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeVoiceLang === l.code
                      ? 'bg-emerald-500 text-stone-950 shadow-sm'
                      : 'text-stone-400 hover:text-white hover:bg-stone-800/80'
                  }`}
                  title={`Switch voice language to ${l.title}`}
                >
                  {l.label}
                </button>
              ))}
            </div>

            <button
              id="close-live-voice-modal"
              onClick={onClose}
              className="p-2 text-stone-400 hover:text-white hover:bg-stone-800 rounded-xl transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Central Visualizer Area */}
        <div className="p-8 flex flex-col items-center justify-center relative overflow-hidden bg-gradient-to-b from-stone-900 via-stone-900 to-stone-950">
          {/* Animated Glow Rings */}
          <div className="relative flex items-center justify-center my-6">
            <div
              className={`absolute -inset-8 rounded-full blur-2xl transition-all duration-500 ${
                connectionStatus === 'speaking'
                  ? 'bg-emerald-500/30 scale-125'
                  : connectionStatus === 'listening'
                  ? 'bg-teal-500/20 scale-105'
                  : 'bg-stone-700/10 scale-90'
              }`}
            />

            <div
              className={`w-32 h-32 rounded-full flex items-center justify-center border-2 transition-all duration-300 relative shadow-2xl ${
                connectionStatus === 'speaking'
                  ? 'border-emerald-400 bg-emerald-950/60 shadow-emerald-500/30'
                  : connectionStatus === 'listening'
                  ? 'border-teal-500/60 bg-stone-800 shadow-teal-500/20'
                  : connectionStatus === 'error'
                  ? 'border-rose-500 bg-rose-950/40'
                  : 'border-stone-700 bg-stone-800'
              }`}
            >
              {connectionStatus === 'speaking' ? (
                <Volume2 className="w-12 h-12 text-emerald-400 animate-bounce" />
              ) : isMuted ? (
                <MicOff className="w-12 h-12 text-rose-400" />
              ) : (
                <Mic className="w-12 h-12 text-teal-300 animate-pulse" />
              )}
            </div>
          </div>

          {/* Dynamic Audio Bars Animation */}
          <div className="flex items-center gap-1.5 h-8 my-2">
            {[40, 70, 90, 60, 100, 75, 45, 80, 65, 30].map((height, i) => (
              <span
                key={i}
                style={{
                  height:
                    connectionStatus === 'speaking' || connectionStatus === 'listening'
                      ? `${Math.max(15, (height * (i % 2 === 0 ? 0.9 : 0.6)))}%`
                      : '20%',
                }}
                className={`w-1.5 rounded-full transition-all duration-150 ${
                  connectionStatus === 'speaking'
                    ? 'bg-emerald-400 animate-pulse'
                    : connectionStatus === 'listening'
                    ? 'bg-teal-400/80'
                    : 'bg-stone-700'
                }`}
              />
            ))}
          </div>

          {/* Status Label */}
          <div className="mt-3 text-center">
            <span
              className={`inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-bold ${
                connectionStatus === 'speaking'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : connectionStatus === 'listening'
                  ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                  : connectionStatus === 'connecting'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : connectionStatus === 'error'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  : 'bg-stone-800 text-stone-400'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-current animate-ping" />
              {connectionStatus === 'speaking' && (
                activeVoiceLang === 'hi' ? 'कोच बोल रहा है...' : activeVoiceLang === 'ur' ? 'Coach bol raha hai...' : 'AI Coach is speaking...'
              )}
              {connectionStatus === 'listening' && (
                activeVoiceLang === 'hi' ? 'आपकी आवाज़ सुन रहा है (बोलिए)' : activeVoiceLang === 'ur' ? 'Aapki aawaz sun raha hai (Speak now)' : 'Listening to you... (Speak anytime)'
              )}
              {connectionStatus === 'interrupted' && (
                activeVoiceLang === 'hi' ? 'रोक दिया गया - सुन रहा है...' : activeVoiceLang === 'ur' ? 'Interrupted - Sun raha hai...' : 'Interrupted - Listening...'
              )}
              {connectionStatus === 'connecting' && (
                activeVoiceLang === 'hi' ? 'वॉयस सेशन कनेक्ट हो रहा है...' : activeVoiceLang === 'ur' ? 'Live session connect ho raha hai...' : 'Connecting to Live API...'
              )}
              {connectionStatus === 'error' && (
                activeVoiceLang === 'hi' ? 'कनेक्शन त्रुटि' : activeVoiceLang === 'ur' ? 'Connection Error' : 'Connection Error'
              )}
              {connectionStatus === 'disconnected' && (
                activeVoiceLang === 'hi' ? 'सेशन समाप्त' : activeVoiceLang === 'ur' ? 'Disconnected' : 'Session Ended'
              )}
            </span>
          </div>

          {errorMessage && (
            <div className="mt-4 p-3 bg-rose-950/60 border border-rose-800/80 rounded-xl flex items-center gap-2 text-rose-200 text-xs max-w-md text-center">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Current live text streaming */}
          {liveModelText && (
            <div className="mt-4 max-w-md p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40 text-xs text-emerald-200 animate-pulse text-center">
              "{liveModelText}"
            </div>
          )}
        </div>

        {/* Live Conversation Transcript Feed */}
        <div className="px-6 py-3 border-t border-stone-800 bg-stone-950/60 max-h-40 overflow-y-auto space-y-2">
          <div className="flex items-center justify-between text-[11px] font-bold text-stone-400 mb-1">
            <span className="flex items-center gap-1">
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
              {activeVoiceLang === 'hi' ? 'लाइव बातचीत' : activeVoiceLang === 'ur' ? 'Live Baatchit' : 'Live Transcript'}
            </span>
            <span className="text-[10px] text-stone-500">
              {activeVoiceLang === 'hi' ? 'हैंड्स-फ्री वर्कआउट मोड' : activeVoiceLang === 'ur' ? 'Hands-free workout support' : 'Hands-free workout mode'}
            </span>
          </div>

          {transcripts.length === 0 ? (
            <div className="text-center py-3 text-xs text-stone-500 italic">
              {activeVoiceLang === 'hi'
                ? 'कोच से बोलकर पूछें: "100 ग्राम पनीर में कितना प्रोटीन है?" या "बेंच प्रेस के कितने सेट्स लगाने चाहिए?"'
                : activeVoiceLang === 'ur'
                ? 'Coach se baat karein: "How many calories in an apple?" ya "How much rest for bench press?"'
                : 'Say anything to your coach: "How many calories in 100g chicken breast?" or "How many sets for squats?"'}
            </div>
          ) : (
            transcripts.map((t) => (
              <div
                key={t.id}
                className={`p-2.5 rounded-xl text-xs ${
                  t.sender === 'user'
                    ? 'bg-teal-950/50 border border-teal-800/40 text-teal-200 ml-6'
                    : 'bg-stone-800/80 border border-stone-700/60 text-stone-200 mr-6'
                }`}
              >
                <div className="text-[10px] font-bold opacity-60 mb-0.5">
                  {t.sender === 'user'
                    ? activeVoiceLang === 'hi'
                      ? 'आप (आवाज़)'
                      : activeVoiceLang === 'ur'
                      ? 'Aap (Spoken)'
                      : 'You (Spoken)'
                    : 'FitTrack Coach'}
                </div>
                <div>{t.text}</div>
              </div>
            ))
          )}
        </div>

        {/* Bottom Control Bar */}
        <div className="p-4 border-t border-stone-800 bg-stone-900 flex items-center justify-between gap-4">
          <button
            onClick={() => setIsMuted((m) => !m)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-colors ${
              isMuted
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
            }`}
          >
            {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            <span>
              {isMuted
                ? activeVoiceLang === 'hi' ? 'माइक चालू करें' : activeVoiceLang === 'ur' ? 'Unmute' : 'Unmute Mic'
                : activeVoiceLang === 'hi' ? 'माइक म्यूट करें' : activeVoiceLang === 'ur' ? 'Mute' : 'Mute Mic'}
            </span>
          </button>

          <button
            onClick={() => startSession(activeVoiceLang)}
            className="p-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-bold transition-colors cursor-pointer"
            title={activeVoiceLang === 'hi' ? 'दोबारा कनेक्ट करें' : activeVoiceLang === 'ur' ? 'Dubara shuru karein' : 'Reconnect Live Session'}
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            id="end-live-voice-btn"
            onClick={() => {
              cleanup();
              onClose();
            }}
            className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md shadow-rose-600/20 transition-colors cursor-pointer"
          >
            {activeVoiceLang === 'hi' ? 'सेशन समाप्त करें' : activeVoiceLang === 'ur' ? 'Session Khatam Karein' : 'End Voice Session'}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
