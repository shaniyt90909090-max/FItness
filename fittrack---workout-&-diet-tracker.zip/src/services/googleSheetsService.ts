import { DailyLog, UserGoals, ConnectedSpreadsheet, SheetFileSummary } from '../types';

const SHEETS_API_BASE = 'https://sheets.googleapis.com/v4/spreadsheets';
const DRIVE_API_BASE = 'https://www.googleapis.com/drive/v3';

export const CONNECTED_SHEET_STORAGE_KEY = 'fittrack_connected_spreadsheet';

// Read saved spreadsheet metadata from local preferences
export const getStoredConnectedSpreadsheet = (): ConnectedSpreadsheet | null => {
  if (typeof window === 'undefined') return null;
  const raw = localStorage.getItem(CONNECTED_SHEET_STORAGE_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as ConnectedSpreadsheet;
  } catch {
    return null;
  }
};

export const saveConnectedSpreadsheet = (sheet: ConnectedSpreadsheet | null) => {
  if (typeof window === 'undefined') return;
  if (!sheet) {
    localStorage.removeItem(CONNECTED_SHEET_STORAGE_KEY);
  } else {
    localStorage.setItem(CONNECTED_SHEET_STORAGE_KEY, JSON.stringify(sheet));
  }
};

// Fetch user's Google Sheets from Google Drive
export const fetchUserSpreadsheets = async (
  accessToken: string
): Promise<SheetFileSummary[]> => {
  const query = encodeURIComponent("mimeType='application/vnd.google-apps.spreadsheet' and trashed=false");
  const url = `${DRIVE_API_BASE}/files?q=${query}&fields=files(id,name,modifiedTime,webViewLink)&orderBy=modifiedTime desc&pageSize=25`;

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to fetch spreadsheets (${res.status})`);
  }

  const data = await res.json();
  return (data.files || []).map((file: any) => ({
    id: file.id,
    name: file.name,
    modifiedTime: file.modifiedTime,
    webViewLink: file.webViewLink || `https://docs.google.com/spreadsheets/d/${file.id}/edit`,
  }));
};

// Create a formatted FitTrack Spreadsheet with structured tabs
export const createFitnessTrackerSpreadsheet = async (
  accessToken: string,
  customTitle?: string
): Promise<ConnectedSpreadsheet> => {
  const title = customTitle || `FitTrack Fitness & Diet Log - ${new Date().getFullYear()}`;

  // 1. Create Spreadsheet with required tabs
  const createRes = await fetch(SHEETS_API_BASE, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title,
      },
      sheets: [
        { properties: { title: 'Daily Summary' } },
        { properties: { title: 'Meals & Nutrition' } },
        { properties: { title: 'Workouts & Exercises' } },
        { properties: { title: 'Hydration Log' } },
      ],
    }),
  });

  if (!createRes.ok) {
    const err = await createRes.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to create Google Sheet (${createRes.status})`);
  }

  const sheetData = await createRes.json();
  const spreadsheetId = sheetData.spreadsheetId;
  const webViewLink = sheetData.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

  // 2. Initialize Headers for each sheet
  const headersPayload = {
    valueInputOption: 'USER_ENTERED',
    data: [
      {
        range: "'Daily Summary'!A1:I1",
        values: [
          [
            'Date',
            'Calories (kcal)',
            'Calorie Target',
            'Protein (g)',
            'Carbs (g)',
            'Fat (g)',
            'Water Intake (ml)',
            'Exercises Completed',
            'Notes',
          ],
        ],
      },
      {
        range: "'Meals & Nutrition'!A1:J1",
        values: [
          [
            'Date',
            'Meal Type',
            'Food Item',
            'Calories (kcal)',
            'Protein (g)',
            'Carbs (g)',
            'Fat (g)',
            'Quantity',
            'Serving Size',
            'Category',
          ],
        ],
      },
      {
        range: "'Workouts & Exercises'!A1:I1",
        values: [
          [
            'Date',
            'Exercise Name',
            'Category',
            'Target Muscle',
            'Sets Completed',
            'Total Reps',
            'Max Weight (kg)',
            'Est. Calories Burned',
            'Notes',
          ],
        ],
      },
      {
        range: "'Hydration Log'!A1:E1",
        values: [
          [
            'Date',
            'Water Intake (ml)',
            'Target (ml)',
            'Glasses (250ml)',
            'Goal Status',
          ],
        ],
      },
    ],
  };

  await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values:batchUpdate`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(headersPayload),
  });

  const connected: ConnectedSpreadsheet = {
    id: spreadsheetId,
    name: title,
    url: webViewLink,
    webViewLink,
    lastSynced: new Date().toISOString(),
  };

  saveConnectedSpreadsheet(connected);
  return connected;
};

// Check and verify spreadsheet access and tabs
export const verifySpreadsheetTabs = async (
  accessToken: string,
  spreadsheetId: string
): Promise<{ title: string; sheets: string[] }> => {
  const res = await fetch(`${SHEETS_API_BASE}/${spreadsheetId}?fields=properties.title,sheets.properties.title`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Cannot access spreadsheet (${res.status})`);
  }

  const data = await res.json();
  const sheets = (data.sheets || []).map((s: any) => s.properties?.title as string);
  return {
    title: data.properties?.title || 'Google Sheet',
    sheets,
  };
};

// Ensure required tabs exist or create them if missing
export const ensureRequiredTabs = async (
  accessToken: string,
  spreadsheetId: string,
  existingSheets: string[]
) => {
  const required = ['Daily Summary', 'Meals & Nutrition', 'Workouts & Exercises', 'Hydration Log'];
  const missing = required.filter((tab) => !existingSheets.includes(tab));

  if (missing.length === 0) return;

  const requests = missing.map((title) => ({
    addSheet: {
      properties: { title },
    },
  }));

  await fetch(`${SHEETS_API_BASE}/${spreadsheetId}:batchUpdate`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ requests }),
  });

  // Add headers for created sheets
  const headerData: any[] = [];
  if (missing.includes('Daily Summary')) {
    headerData.push({
      range: "'Daily Summary'!A1:I1",
      values: [
        [
          'Date',
          'Calories (kcal)',
          'Calorie Target',
          'Protein (g)',
          'Carbs (g)',
          'Fat (g)',
          'Water Intake (ml)',
          'Exercises Completed',
          'Notes',
        ],
      ],
    });
  }
  if (missing.includes('Meals & Nutrition')) {
    headerData.push({
      range: "'Meals & Nutrition'!A1:J1",
      values: [
        [
          'Date',
          'Meal Type',
          'Food Item',
          'Calories (kcal)',
          'Protein (g)',
          'Carbs (g)',
          'Fat (g)',
          'Quantity',
          'Serving Size',
          'Category',
        ],
      ],
    });
  }
  if (missing.includes('Workouts & Exercises')) {
    headerData.push({
      range: "'Workouts & Exercises'!A1:I1",
      values: [
        [
          'Date',
          'Exercise Name',
          'Category',
          'Target Muscle',
          'Sets Completed',
          'Total Reps',
          'Max Weight (kg)',
          'Est. Calories Burned',
          'Notes',
        ],
      ],
    });
  }
  if (missing.includes('Hydration Log')) {
    headerData.push({
      range: "'Hydration Log'!A1:E1",
      values: [
        [
          'Date',
          'Water Intake (ml)',
          'Target (ml)',
          'Glasses (250ml)',
          'Goal Status',
        ],
      ],
    });
  }

  if (headerData.length > 0) {
    await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values:batchUpdate`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        valueInputOption: 'USER_ENTERED',
        data: headerData,
      }),
    });
  }
};

// Append a daily log to the connected spreadsheet
export const appendDailyLogToSheet = async (
  accessToken: string,
  spreadsheetId: string,
  log: DailyLog,
  goals: UserGoals
): Promise<{ addedRowsCount: number }> => {
  // Check and prepare tabs
  const { sheets } = await verifySpreadsheetTabs(accessToken, spreadsheetId);
  await ensureRequiredTabs(accessToken, spreadsheetId, sheets);

  // Calculate daily totals
  const allFoods = [
    ...log.meals.breakfast,
    ...log.meals.lunch,
    ...log.meals.dinner,
    ...log.meals.snack,
  ];
  const totalCalories = allFoods.reduce((acc, f) => acc + (f.calories || 0) * (f.quantity || 1), 0);
  const totalProtein = allFoods.reduce((acc, f) => acc + (f.protein || 0) * (f.quantity || 1), 0);
  const totalCarbs = allFoods.reduce((acc, f) => acc + (f.carbs || 0) * (f.quantity || 1), 0);
  const totalFat = allFoods.reduce((acc, f) => acc + (f.fat || 0) * (f.quantity || 1), 0);

  let rowsCount = 0;

  // 1. Daily Summary Row
  const summaryRow = [
    log.date,
    Math.round(totalCalories),
    goals.dailyCalories,
    Math.round(totalProtein),
    Math.round(totalCarbs),
    Math.round(totalFat),
    log.waterIntakeMl || 0,
    log.workouts.length,
    log.notes || '',
  ];

  await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Daily Summary'!A:I:append?valueInputOption=USER_ENTERED`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ values: [summaryRow] }),
  });
  rowsCount += 1;

  // 2. Meal Rows
  const mealRows: any[][] = [];
  const mealTypes: ('breakfast' | 'lunch' | 'dinner' | 'snack')[] = ['breakfast', 'lunch', 'dinner', 'snack'];
  mealTypes.forEach((type) => {
    log.meals[type].forEach((food) => {
      mealRows.push([
        log.date,
        type.charAt(0).toUpperCase() + type.slice(1),
        food.name,
        food.calories * (food.quantity || 1),
        food.protein * (food.quantity || 1),
        food.carbs * (food.quantity || 1),
        food.fat * (food.quantity || 1),
        food.quantity || 1,
        food.servingSize || '',
        food.category || 'General',
      ]);
    });
  });

  if (mealRows.length > 0) {
    await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Meals & Nutrition'!A:J:append?valueInputOption=USER_ENTERED`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ values: mealRows }),
    });
    rowsCount += mealRows.length;
  }

  // 3. Workouts Rows
  const workoutRows: any[][] = [];
  log.workouts.forEach((workout) => {
    const completedSets = workout.sets.filter((s) => s.completed).length;
    const totalReps = workout.sets.reduce((sum, s) => sum + (s.completed ? s.reps : 0), 0);
    const maxWeight = Math.max(0, ...workout.sets.map((s) => s.weightKg || 0));

    workoutRows.push([
      log.date,
      workout.name,
      workout.category,
      workout.muscleGroup,
      completedSets,
      totalReps,
      maxWeight,
      workout.caloriesBurned || 0,
      workout.notes || '',
    ]);
  });

  if (workoutRows.length > 0) {
    await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Workouts & Exercises'!A:I:append?valueInputOption=USER_ENTERED`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ values: workoutRows }),
    });
    rowsCount += workoutRows.length;
  }

  // 4. Hydration Row
  const hydrationStatus = (log.waterIntakeMl || 0) >= goals.dailyWaterMl ? 'Goal Met' : 'In Progress';
  const hydrationRow = [
    log.date,
    log.waterIntakeMl || 0,
    goals.dailyWaterMl,
    Math.round((log.waterIntakeMl || 0) / 250),
    hydrationStatus,
  ];

  await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Hydration Log'!A:E:append?valueInputOption=USER_ENTERED`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ values: [hydrationRow] }),
  });
  rowsCount += 1;

  // Update stored last synced timestamp
  const stored = getStoredConnectedSpreadsheet();
  if (stored && stored.id === spreadsheetId) {
    saveConnectedSpreadsheet({
      ...stored,
      lastSynced: new Date().toISOString(),
    });
  }

  return { addedRowsCount: rowsCount };
};

// Sync all recorded daily logs from localStorage to the spreadsheet
export const syncAllHistoryToSheet = async (
  accessToken: string,
  spreadsheetId: string,
  logs: DailyLog[],
  goals: UserGoals
): Promise<{ totalSyncedDays: number; totalRows: number }> => {
  let totalRows = 0;
  for (const log of logs) {
    const { addedRowsCount } = await appendDailyLogToSheet(accessToken, spreadsheetId, log, goals);
    totalRows += addedRowsCount;
  }
  return { totalSyncedDays: logs.length, totalRows };
};
