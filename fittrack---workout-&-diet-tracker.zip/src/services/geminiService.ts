export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  modelUsed?: string;
  isError?: boolean;
}

export interface CoachRole {
  id: string;
  name: string;
  nameUr: string;
  description: string;
  descriptionUr: string;
  systemInstruction: string;
  avatarIcon: string;
}

export const COACH_ROLES: CoachRole[] = [
  {
    id: 'general-coach',
    name: 'FitTrack Master Coach',
    nameUr: 'FitTrack Master Coach',
    description: 'All-around fitness mentor, workout guidance & personalized nutrition.',
    descriptionUr: 'Har qisam ki fitness, exercises aur balanced khuraak ka mashwara.',
    systemInstruction:
      'You are the FitTrack Master Coach, a warm, motivating, and highly knowledgeable personal trainer and sports nutritionist. Give concise, actionable, and scientifically sound advice on exercises, training form, and daily nutrition.',
    avatarIcon: 'Dumbbell',
  },
  {
    id: 'strength-coach',
    name: 'Strength & Hypertrophy',
    nameUr: 'Strength & Muscle Specialist',
    description: 'Progressive overload, workout splits, sets, reps & compound lifts.',
    descriptionUr: 'Heavy lifting, muscle growth, sets aur reps ki planning.',
    systemInstruction:
      'You are a certified Strength and Conditioning Specialist. Focus on progressive overload, optimal lifting technique, RPE/RIR, compound movements (squat, bench, deadlift, overhead press), and intelligent workout split programming.',
    avatarIcon: 'Flame',
  },
  {
    id: 'dietitian-coach',
    name: 'Sports Nutritionist',
    nameUr: 'Diet & Macros Expert',
    description: 'Protein targets, calorie deficit/surplus, meal prep & hydration.',
    descriptionUr: 'Calorie deficit, protein intake, meal timing aur hydration.',
    systemInstruction:
      'You are a Sports Dietitian and Performance Nutritionist. Provide accurate guidance on macronutrients (protein, carbs, fats), daily caloric balance for fat loss or lean bulking, pre/post workout meals, and hydration science.',
    avatarIcon: 'Apple',
  },
  {
    id: 'recovery-coach',
    name: 'Recovery & Mobility',
    nameUr: 'Recovery & Form Guide',
    description: 'Rest intervals, stretching, injury prevention & soreness management.',
    descriptionUr: 'Stretching, rest timing, chot se bachao aur body recovery.',
    systemInstruction:
      'You are a Physical Therapist and Athletic Recovery Coach. Focus on mobility drills, dynamic warmups, active recovery, optimal sleep/rest, dealing with DOMS (muscle soreness), and preventing injury.',
    avatarIcon: 'HeartPulse',
  },
];

export interface GeminiModelOption {
  id: string;
  name: string;
  tag: string;
  description: string;
  descriptionUr: string;
  isDefault?: boolean;
}

export const GEMINI_CHAT_MODELS: GeminiModelOption[] = [
  {
    id: 'gemini-3.8-flash',
    name: 'Gemini 3.8 Flash',
    tag: 'General Tasks',
    description: 'High speed, enhanced reliability and intelligence. Recommended for everyday fitness and diet advice.',
    descriptionUr: 'Roz-marrah fitness aur diet mashwaray ke liye behtareen, tez aur reliable model.',
    isDefault: true,
  },
  {
    id: 'gemini-3.1-flash-lite',
    name: 'Gemini 3.1 Flash Lite',
    tag: 'Fast',
    description: 'Ultra-fast responses. Best for quick calorie estimates, rep lookups, and swift tips.',
    descriptionUr: 'Fori jawab aur fast calculations (calories, reps aur quick facts).',
  },
  {
    id: 'gemini-3.1-pro-preview',
    name: 'Gemini 3.1 Pro Preview',
    tag: 'Complex Tasks',
    description: 'Deep reasoning model. Best for periodization, complex biomechanics, and nutrition science.',
    descriptionUr: 'Gehra tajziya, advanced scientific periodization aur complex bodybuilding plans.',
  },
];

export async function sendChatMessage(
  messages: Array<{ role: 'user' | 'model'; text: string }>,
  model: string = 'gemini-3.8-flash',
  systemInstruction?: string,
  userContext?: any
): Promise<{ text: string; modelUsed: string }> {
  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      messages,
      model,
      systemInstruction,
      userContext,
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || `Request failed with status ${response.status}`);
  }

  return response.json();
}
